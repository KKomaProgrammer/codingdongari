(function (global) {
    const API_BASE = 'https://supabase-settings-fetch.pages.dev/api';
    const API_URL = `${API_BASE}/current/settings-live.js`;
    const STATUS_URL = `${API_BASE}/current/status`;
    const UPDATE_PACKAGE_URL = `${API_BASE}/current/update-package`;
    const CHAT_BACKUP_URL = `${API_BASE}/current/chat-backup`;
    const ACCOUNT_URL = `${API_BASE}/current/account`;
    const BACKUP_URL = `${API_BASE}/backup`;

    async function requestJson(url, options = {}, timeout = 12000) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), timeout);
        let response;
        try {
            response = await fetch(url, { cache: 'no-store', credentials: 'omit', ...options, signal: controller.signal });
        } catch (error) {
            if (error?.name === 'AbortError') throw new Error('설정 서버 응답 시간이 초과되었습니다.');
            throw new Error('설정 서버에 연결할 수 없습니다.');
        } finally { clearTimeout(timer); }
        let body = null;
        try { body = await response.json(); } catch (_) {}
        if (!response.ok || !body?.ok) {
            const error = new Error(body?.error || `설정 서버 오류(HTTP ${response.status})`);
            error.accessMode = Number(body?.accessMode || 0);
            error.status = body?.status || '';
            throw error;
        }
        return body;
    }

    function normalizeMeta(body) {
        const mode = Number(body?.accessMode || 0);
        return {
            accessMode: mode === 1 || mode === 2 ? mode : 0,
            status: mode === 1 ? 'maintenance' : mode === 2 ? 'disabled' : 'normal',
            mandatoryUpdate: Boolean(body?.mandatoryUpdate),
            passwordRequired: body?.passwordRequired !== false,
            notice: body?.notice && typeof body.notice === 'object' ? {
                title: String(body.notice.title || '공지').slice(0, 80),
                body: String(body.notice.body || '').slice(0, 2000),
            } : null,
        };
    }

    async function fetchStatus({ timeout = 8000 } = {}) {
        return normalizeMeta(await requestJson(STATUS_URL, { method: 'GET' }, timeout));
    }

    async function fetchSettings(password = '', { timeout = 12000 } = {}) {
        password = String(password || '').toLowerCase();
        if (password.length > 256) throw new Error('연결 비밀번호가 너무 깁니다.');
        const body = await requestJson(API_URL, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password }),
        }, timeout);
        const serverUrl = String(body.serverUrl || '').trim().replace(/\/$/, '');
        const anonKey = String(body.anonKey || '').trim();
        if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(serverUrl)) throw new Error('설정 서버의 Supabase URL이 올바르지 않습니다.');
        if (!anonKey || anonKey.startsWith('sb_secret_')) throw new Error('브라우저용 Supabase 키가 아닙니다.');
        return { serverUrl, anonKey, ...normalizeMeta(body) };
    }

    async function fetchUpdatePackage(version, { timeout = 45000 } = {}) {
        version = String(version || '').trim();
        if (!/^\d+\.\d+\.\d+$/.test(version)) throw new Error('업데이트 버전 정보가 올바르지 않습니다.');
        const body = await requestJson(`${UPDATE_PACKAGE_URL}?version=${encodeURIComponent(version)}`, { method: 'GET' }, timeout);
        if (String(body.version || '') !== version || String(body.filename || '') !== `message_V${version}.zip`)
            throw new Error('업데이트 서버의 버전 정보가 일치하지 않습니다.');
        if (!/^[a-f0-9]{64}$/i.test(String(body.sha256 || '')) || typeof body.packageBase64 !== 'string' || !body.packageBase64.length)
            throw new Error('업데이트 서버의 패키지 정보가 올바르지 않습니다.');
        if (body.packageBase64.length > 12 * 1024 * 1024) throw new Error('업데이트 패키지가 너무 큽니다.');
        return {
            version,
            filename: body.filename,
            sha256: String(body.sha256).toLowerCase(),
            size: Number(body.size || 0),
            packageBase64: body.packageBase64,
            serverCached: Boolean(body.cached),
            fetchedAt: Number(body.fetchedAt || Date.now()),
        };
    }

    async function backupMessages(clientId, messages, { timeout = 12000 } = {}) {
        if (!clientId || !Array.isArray(messages) || !messages.length) return { ok: true, saved: 0 };
        return requestJson(CHAT_BACKUP_URL, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ clientId: String(clientId), messages: messages.slice(0, 40) }),
        }, timeout);
    }

    async function accountRequest(action, payload = {}, { timeout = 15000 } = {}) {
        action = String(action || '').trim();
        if (!action) throw new Error('계정 요청 종류가 비어 있습니다.');
        return requestJson(ACCOUNT_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action, ...(payload && typeof payload === 'object' ? payload : {}) }),
        }, timeout);
    }

    global.EntrySettingsFetch = { API_BASE, API_URL, STATUS_URL, UPDATE_PACKAGE_URL, BACKUP_URL, CHAT_BACKUP_URL, ACCOUNT_URL, fetchStatus, fetchSettings, fetchUpdatePackage, backupMessages, accountRequest };
})(globalThis);
