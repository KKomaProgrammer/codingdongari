(function (_0x0001) {
    const _0x0002 = 'junwoo-comprehensive-chat-v1';
    const _0x0003 = 1;
    const _0x0004 = 'records';
    const _0x0005 = 'kv';
    const _0x0006 = 'entryChatArchiveIndexV1';
    const _0x0007 = 'entryChatArchiveRecordV1:';
    const _0x0008 = 'entryChatArchiveKvV1:';
    class _0x0009 {
        constructor() {
            this.dbPromise = null;
            this.queue = Promise.resolve();
            this.index = null;
        }
        openDb() {
            if (this.dbPromise)
                return this.dbPromise;
            this.dbPromise = new Promise((_0x000a, _0x000b) => {
                const _0x000c = indexedDB.open(_0x0002, _0x0003);
                _0x000c.onupgradeneeded = () => {
                    const _0x000d = _0x000c.result;
                    if (!_0x000d.objectStoreNames.contains(_0x0004))
                        _0x000d.createObjectStore(_0x0004, { keyPath: 'id' });
                    if (!_0x000d.objectStoreNames.contains(_0x0005))
                        _0x000d.createObjectStore(_0x0005, { keyPath: 'key' });
                };
                _0x000c.onsuccess = () => _0x000a(_0x000c.result);
                _0x000c.onerror = () => _0x000b(_0x000c.error || new Error('채팅 IndexedDB를 열 수 없습니다.'));
            });
            return this.dbPromise;
        }
        async idbPut(_0x000e, _0x000f) {
            const _0x0010 = await this.openDb();
            return new Promise((_0x0011, _0x0012) => {
                const _0x0013 = _0x0010.transaction(_0x000e, 'readwrite');
                _0x0013.objectStore(_0x000e).put(_0x000f);
                _0x0013.oncomplete = () => _0x0011(true);
                _0x0013.onerror = () => _0x0012(_0x0013.error || new Error('IndexedDB 저장 실패'));
                _0x0013.onabort = () => _0x0012(_0x0013.error || new Error('IndexedDB 저장 중단'));
            });
        }
        async idbGetAll(_0x0014) {
            const _0x0015 = await this.openDb();
            return new Promise((_0x0016, _0x0017) => {
                const _0x0018 = _0x0015.transaction(_0x0014, 'readonly');
                const _0x0019 = _0x0018.objectStore(_0x0014).getAll();
                _0x0019.onsuccess = () => _0x0016(_0x0019.result || []);
                _0x0019.onerror = () => _0x0017(_0x0019.error || new Error('IndexedDB 읽기 실패'));
            });
        }
        async ensureIndex() {
            if (this.index)
                return this.index;
            const _0x001a = await chrome.storage.local.get(_0x0006);
            const _0x001b = Array.isArray(_0x001a[_0x0006]) ? _0x001a[_0x0006] : [];
            this.index = [...new Set(_0x001b.filter((_0x001c) => typeof _0x001c === 'string' && _0x001c))];
            return this.index;
        }
        putRecord(_0x001d) {
            const _0x001e = structuredClone(_0x001d);
            if (!_0x001e?.id)
                return Promise.reject(new Error('백업 레코드 ID가 없습니다.'));
            this.queue = this.queue.catch(() => { }).then(async () => {
                const _0x001f = await this.ensureIndex();
                if (!_0x001f.includes(_0x001e.id))
                    _0x001f.push(_0x001e.id);
                const _0x0020 = `${_0x0007}${_0x001e.id}`;
                await Promise.all([
                    this.idbPut(_0x0004, _0x001e),
                    chrome.storage.local.set({ [_0x0020]: _0x001e, [_0x0006]: _0x001f.slice() }),
                ]);
            });
            return this.queue;
        }
        setKv(_0x0021, _0x0022) {
            const _0x0023 = String(_0x0021 || '');
            const _0x0024 = { key: _0x0023, value: structuredClone(_0x0022), updatedAt: Date.now() };
            this.queue = this.queue.catch(() => { }).then(() => Promise.all([
                this.idbPut(_0x0005, _0x0024),
                chrome.storage.local.set({ [`${_0x0008}${_0x0023}`]: _0x0024 }),
            ]));
            return this.queue;
        }
        async loadAllRecords() {
            const _0x0025 = await this.ensureIndex();
            const _0x0026 = _0x0025.map((_0x0027) => `${_0x0007}${_0x0027}`);
            let _0x0028 = [];
            for (let _0x0029 = 0; _0x0029 < _0x0026.length; _0x0029 += 200) {
                const _0x002a = _0x0026.slice(_0x0029, _0x0029 + 200);
                const _0x002b = await chrome.storage.local.get(_0x002a);
                _0x0028.push(..._0x002a.map((_0x002c) => _0x002b[_0x002c]).filter((_0x002d) => _0x002d?.id));
            }
            let _0x002e = [];
            try {
                _0x002e = await this.idbGetAll(_0x0004);
            }
            catch (_0x002f) { }
            const _0x0030 = new Map();
            for (const _0x0031 of [..._0x002e, ..._0x0028]) {
                if (!_0x0031?.id)
                    continue;
                const _0x0032 = _0x0030.get(_0x0031.id);
                if (!_0x0032 || Number(_0x0031.at || _0x0031.savedAt || 0) >= Number(_0x0032.at || _0x0032.savedAt || 0))
                    _0x0030.set(_0x0031.id, _0x0031);
            }
            return [..._0x0030.values()].sort((_0x0033, _0x0034) => Number(_0x0033.at || 0) - Number(_0x0034.at || 0));
        }
        async getKv(_0x0035) {
            const _0x0036 = `${_0x0008}${String(_0x0035 || '')}`;
            const _0x0037 = await chrome.storage.local.get(_0x0036);
            if (_0x0037[_0x0036])
                return _0x0037[_0x0036].value;
            try {
                const _0x0038 = await this.idbGetAll(_0x0005);
                return _0x0038.find((_0x0039) => _0x0039.key === _0x0035)?.value;
            }
            catch (_0x003a) {
                return undefined;
            }
        }
        async exportSnapshot(_0x003b = {}) {
            const _0x003c = await this.loadAllRecords();
            return {
                format: 'junwoo-comprehensive-chat-backup',
                version: 1,
                exportedAt: new Date().toISOString(),
                records: _0x003c,
                ...structuredClone(_0x003b),
            };
        }
        async importRecords(_0x003d) {
            if (!Array.isArray(_0x003d))
                throw new Error('백업 records 형식이 올바르지 않습니다.');
            let _0x003e = 0;
            for (const _0x003f of _0x003d) {
                if (!_0x003f?.id || !['room', 'self'].includes(_0x003f.scope))
                    continue;
                await this.putRecord(_0x003f);
                _0x003e += 1;
            }
            return _0x003e;
        }
    }
    _0x0001.EntryChatDurableStore = _0x0009;
})(globalThis);
