(function (_0x0001) {
    class _0x0002 {
        constructor({ url: _0x0003, key: _0x0004, onBroadcast: _0x0005, onStatus: _0x0006 }) {
            this.url = String(_0x0003 || '').replace(/\/$/, '');
            this.key = String(_0x0004 || '');
            this.onBroadcast = _0x0005 || (() => { });
            this.onStatus = _0x0006 || (() => { });
            this.socket = null;
            this.ref = 0;
            this.channels = new Map();
            this.closed = false;
            this.reconnectCount = 0;
            this.heartbeatTimer = null;
            this.reconnectTimer = null;
            this.openPromise = null;
        }
        connect() {
            if (this.closed)
                return Promise.reject(new Error('연결이 종료되었습니다.'));
            if (this.socket?.readyState === WebSocket.OPEN)
                return Promise.resolve();
            if (this.openPromise)
                return this.openPromise;
            this.openPromise = new Promise((_0x0007, _0x0008) => {
                const _0x0009 = this.url.replace(/^http:/, 'ws:').replace(/^https:/, 'wss:');
                const _0x000a = `${_0x0009}/realtime/v1/websocket?apikey=${encodeURIComponent(this.key)}&vsn=1.0.0`;
                try {
                    this.socket = new WebSocket(_0x000a);
                }
                catch (_0x000b) {
                    this.openPromise = null;
                    _0x0008(_0x000b);
                    return;
                }
                this.onStatus('connecting');
                const _0x000c = () => {
                    if (this.openPromise)
                        _0x0008(new Error('실시간 서버에 연결할 수 없습니다.'));
                    this.openPromise = null;
                };
                this.socket.addEventListener('open', () => {
                    this.reconnectCount = 0;
                    this.onStatus('online');
                    clearInterval(this.heartbeatTimer);
                    this.heartbeatTimer = setInterval(() => this.heartbeat(), 25000);
                    const _0x000d = [...this.channels.keys()];
                    for (const _0x000e of _0x000d)
                        this.join(_0x000e, true);
                    this.openPromise = null;
                    _0x0007();
                }, { once: true });
                this.socket.addEventListener('message', (_0x000f) => this.handleMessage(_0x000f.data));
                this.socket.addEventListener('error', _0x000c, { once: true });
                this.socket.addEventListener('close', () => {
                    clearInterval(this.heartbeatTimer);
                    for (const _0x0010 of this.channels.values()) {
                        _0x0010.joined = false;
                        _0x0010.joinRef = null;
                        _0x0010.joining = null;
                        _0x0010.resolveJoin = null;
                        _0x0010.rejectJoin = null;
                    }
                    this.onStatus('offline');
                    if (this.openPromise)
                        _0x000c();
                    this.scheduleReconnect();
                });
            });
            return this.openPromise;
        }
        async ensureChannel(_0x0011) {
            _0x0011 = this.normalizeTopic(_0x0011);
            let _0x0012 = this.channels.get(_0x0011);
            if (!_0x0012) {
                _0x0012 = { topic: _0x0011, joined: false, joining: null, joinRef: null, queue: [] };
                this.channels.set(_0x0011, _0x0012);
            }
            await this.connect();
            if (!_0x0012.joined)
                await this.join(_0x0011);
            return _0x0012;
        }
        join(_0x0013, _0x0014 = false) {
            _0x0013 = this.normalizeTopic(_0x0013);
            const _0x0015 = this.channels.get(_0x0013) || { topic: _0x0013, joined: false, joining: null, joinRef: null, queue: [] };
            this.channels.set(_0x0013, _0x0015);
            if (_0x0015.joined)
                return Promise.resolve();
            if (_0x0015.joining && !_0x0014)
                return _0x0015.joining;
            if (this.socket?.readyState !== WebSocket.OPEN)
                return this.connect().then(() => this.join(_0x0013));
            _0x0015.joining = new Promise((_0x0016, _0x0017) => {
                const _0x0018 = String(++this.ref);
                _0x0015.joinRef = _0x0018;
                _0x0015.resolveJoin = _0x0016;
                _0x0015.rejectJoin = _0x0017;
                const _0x0019 = {
                    config: {
                        broadcast: { ack: false, self: false },
                        presence: { enabled: false },
                        postgres_changes: [],
                        private: false,
                    },
                };
                if (this.key.split('.').length === 3)
                    _0x0019.access_token = this.key;
                this.socket.send(JSON.stringify({ topic: _0x0013, event: 'phx_join', payload: _0x0019, ref: _0x0018 }));
                setTimeout(() => {
                    if (!_0x0015.joined && _0x0015.joinRef === _0x0018) {
                        _0x0015.joining = null;
                        _0x0015.rejectJoin = null;
                        _0x0015.resolveJoin = null;
                        _0x0017(new Error('채팅방 연결 시간이 초과되었습니다.'));
                    }
                }, 7000);
            });
            return _0x0015.joining;
        }
        handleMessage(_0x001a) {
            let _0x001b;
            try {
                _0x001b = JSON.parse(_0x001a);
            }
            catch (_0x001c) {
                return;
            }
            const _0x001d = this.channels.get(_0x001b.topic);
            if (_0x001b.event === 'phx_reply' && _0x001d && _0x001b.ref === _0x001d.joinRef) {
                if (_0x001b.payload?.status === 'ok') {
                    _0x001d.joined = true;
                    _0x001d.joining = null;
                    _0x001d.resolveJoin?.();
                    _0x001d.resolveJoin = null;
                    _0x001d.rejectJoin = null;
                    this.flush(_0x001d);
                }
                else {
                    _0x001d.joined = false;
                    _0x001d.joining = null;
                    _0x001d.rejectJoin?.(new Error('Realtime 채널에 연결할 수 없습니다.'));
                    _0x001d.resolveJoin = null;
                    _0x001d.rejectJoin = null;
                }
                return;
            }
            if (_0x001b.event !== 'broadcast')
                return;
            const _0x001e = _0x001b.payload || {};
            const _0x001f = _0x001e.event || _0x001e.payload?.event;
            const _0x0020 = _0x001e.payload?.payload ?? _0x001e.payload;
            if (!_0x001f)
                return;
            this.onBroadcast(_0x001b.topic, _0x001f, _0x0020 || {});
        }
        async send(_0x0021, _0x0022, _0x0023 = {}) {
            _0x0021 = this.normalizeTopic(_0x0021);
            const _0x0024 = await this.ensureChannel(_0x0021);
            const _0x0025 = {
                topic: _0x0021,
                event: 'broadcast',
                payload: { type: 'broadcast', event: _0x0022, payload: _0x0023 },
                ref: null,
            };
            if (!_0x0024.joined || this.socket?.readyState !== WebSocket.OPEN) {
                _0x0024.queue.push(_0x0025);
                if (_0x0024.queue.length > 200)
                    _0x0024.queue.shift();
                return false;
            }
            this.socket.send(JSON.stringify(_0x0025));
            return true;
        }
        leave(_0x0026) {
            _0x0026 = this.normalizeTopic(_0x0026);
            const _0x0027 = this.channels.get(_0x0026);
            if (!_0x0027)
                return;
            if (this.socket?.readyState === WebSocket.OPEN && _0x0027.joined) {
                this.socket.send(JSON.stringify({ topic: _0x0026, event: 'phx_leave', payload: {}, ref: String(++this.ref) }));
            }
            this.channels.delete(_0x0026);
        }
        flush(_0x0028) {
            while (_0x0028.joined && _0x0028.queue.length && this.socket?.readyState === WebSocket.OPEN) {
                this.socket.send(JSON.stringify(_0x0028.queue.shift()));
            }
        }
        heartbeat() {
            if (this.socket?.readyState !== WebSocket.OPEN)
                return;
            this.socket.send(JSON.stringify({ topic: 'phoenix', event: 'heartbeat', payload: {}, ref: String(++this.ref) }));
        }
        scheduleReconnect() {
            if (this.closed || this.reconnectTimer)
                return;
            const _0x0029 = Math.min(12000, 700 * 2 ** this.reconnectCount++);
            this.reconnectTimer = setTimeout(async () => {
                this.reconnectTimer = null;
                try {
                    await this.connect();
                }
                catch (_0x002a) {
                    this.scheduleReconnect();
                }
            }, _0x0029);
        }
        close() {
            this.closed = true;
            clearInterval(this.heartbeatTimer);
            clearTimeout(this.reconnectTimer);
            try {
                this.socket?.close();
            }
            catch (_0x002b) { }
            this.channels.clear();
        }
        normalizeTopic(_0x002c) {
            const _0x002d = String(_0x002c || '').replace(/[^a-zA-Z0-9:_-]/g, '').slice(0, 180);
            if (!_0x002d)
                throw new Error('잘못된 채널입니다.');
            return _0x002d.startsWith('realtime:') ? _0x002d : `realtime:${_0x002d}`;
        }
    }
    _0x0001.EntryChatRealtimeHub = _0x0002;
})(globalThis);
