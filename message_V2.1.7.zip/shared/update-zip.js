(function (_0x0001) {
    const _0x0002 = 1200;
    const _0x0003 = 200 * 1024 * 1024;
    const _0x0004 = 0x06054b50;
    const _0x0005 = 0x02014b50;
    const _0x0006 = 0x04034b50;
    function _0x0007(_0x0008) {
        let _0x0009 = String(_0x0008 || '').replace(/\\/g, '/');
        while (_0x0009.startsWith('./'))
            _0x0009 = _0x0009.slice(2);
        if (!_0x0009 || _0x0009.startsWith('/') || _0x0009.includes('\0'))
            throw new Error('ZIP에 잘못된 파일 경로가 있습니다.');
        const _0x000a = _0x0009.split('/').filter(Boolean);
        if (_0x000a.some((_0x000b) => _0x000b === '..'))
            throw new Error('ZIP 경로 이동(..)은 허용되지 않습니다.');
        return _0x000a.join('/');
    }
    function _0x000c(_0x000d) {
        const _0x000e = Math.max(0, _0x000d.byteLength - 65557);
        for (let _0x000f = _0x000d.byteLength - 22; _0x000f >= _0x000e; _0x000f -= 1) {
            if (_0x000d.getUint32(_0x000f, true) === _0x0004)
                return _0x000f;
        }
        throw new Error('올바른 ZIP 파일이 아닙니다(EOCD 없음).');
    }
    async function _0x0010(_0x0011) {
        if (typeof DecompressionStream !== 'function')
            throw new Error('이 Chrome 버전에서는 ZIP 압축 해제를 지원하지 않습니다.');
        let _0x0012;
        try {
            _0x0012 = new Blob([_0x0011]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
        }
        catch (_0x0013) {
            throw new Error('ZIP Deflate 압축을 열 수 없습니다.');
        }
        return new Uint8Array(await new Response(_0x0012).arrayBuffer());
    }
    async function _0x0014(_0x0015) {
        const _0x0016 = new Uint8Array(_0x0015);
        const _0x0017 = new DataView(_0x0015);
        const _0x0018 = _0x000c(_0x0017);
        const _0x0019 = _0x0017.getUint16(_0x0018 + 4, true);
        const _0x001a = _0x0017.getUint16(_0x0018 + 6, true);
        const _0x001b = _0x0017.getUint16(_0x0018 + 8, true);
        const _0x001c = _0x0017.getUint16(_0x0018 + 10, true);
        const _0x001d = _0x0017.getUint32(_0x0018 + 12, true);
        const _0x001e = _0x0017.getUint32(_0x0018 + 16, true);
        if (_0x0019 !== 0 || _0x001a !== 0 || _0x001b !== _0x001c)
            throw new Error('분할 ZIP은 지원하지 않습니다.');
        if (_0x001c === 0xffff || _0x001e === 0xffffffff || _0x001d === 0xffffffff)
            throw new Error('ZIP64 형식은 지원하지 않습니다.');
        if (_0x001c > _0x0002)
            throw new Error('업데이트 ZIP의 파일 수가 너무 많습니다.');
        if (_0x001e + _0x001d > _0x0016.length)
            throw new Error('ZIP 중앙 디렉터리가 손상되었습니다.');
        const _0x001f = new TextDecoder('utf-8');
        const _0x0020 = [];
        let _0x0021 = 0;
        let _0x0022 = _0x001e;
        for (let _0x0023 = 0; _0x0023 < _0x001c; _0x0023 += 1) {
            if (_0x0017.getUint32(_0x0022, true) !== _0x0005)
                throw new Error('ZIP 중앙 디렉터리가 손상되었습니다.');
            const _0x0024 = _0x0017.getUint16(_0x0022 + 8, true);
            const _0x0025 = _0x0017.getUint16(_0x0022 + 10, true);
            const _0x0026 = _0x0017.getUint32(_0x0022 + 20, true);
            const _0x0027 = _0x0017.getUint32(_0x0022 + 24, true);
            const _0x0028 = _0x0017.getUint16(_0x0022 + 28, true);
            const _0x0029 = _0x0017.getUint16(_0x0022 + 30, true);
            const _0x002a = _0x0017.getUint16(_0x0022 + 32, true);
            const _0x002b = _0x0017.getUint32(_0x0022 + 42, true);
            if (_0x0024 & 1)
                throw new Error('암호화된 ZIP 패키지는 업데이트에 사용할 수 없습니다.');
            if (![0, 8].includes(_0x0025))
                throw new Error(`지원하지 않는 ZIP 압축 방식입니다: ${_0x0025}`);
            if ([_0x0026, _0x0027, _0x002b].includes(0xffffffff))
                throw new Error('ZIP64 항목은 지원하지 않습니다.');
            const _0x002c = _0x001f.decode(_0x0016.slice(_0x0022 + 46, _0x0022 + 46 + _0x0028));
            const _0x002d = /\/$/.test(_0x002c);
            const _0x002e = _0x0007(_0x002c);
            _0x0022 += 46 + _0x0028 + _0x0029 + _0x002a;
            if (_0x002d || _0x002e.startsWith('__MACOSX/'))
                continue;
            _0x0021 += _0x0027;
            if (_0x0021 > _0x0003)
                throw new Error('업데이트 ZIP의 압축 해제 크기가 너무 큽니다.');
            if (_0x0017.getUint32(_0x002b, true) !== _0x0006)
                throw new Error(`ZIP 로컬 헤더가 손상되었습니다: ${_0x002e}`);
            const _0x002f = _0x0017.getUint16(_0x002b + 26, true);
            const _0x0030 = _0x0017.getUint16(_0x002b + 28, true);
            const _0x0031 = _0x002b + 30 + _0x002f + _0x0030;
            if (_0x0031 + _0x0026 > _0x0016.length)
                throw new Error(`ZIP 데이터가 손상되었습니다: ${_0x002e}`);
            const _0x0032 = _0x0016.slice(_0x0031, _0x0031 + _0x0026);
            const _0x0033 = _0x0025 === 0 ? _0x0032 : await _0x0010(_0x0032);
            if (_0x0033.byteLength !== _0x0027)
                throw new Error(`ZIP 파일 크기 검증에 실패했습니다: ${_0x002e}`);
            _0x0020.push({ path: _0x002e, data: _0x0033 });
        }
        let _0x0034 = '';
        if (!_0x0020.some((_0x0035) => _0x0035.path === 'manifest.json')) {
            const _0x0036 = _0x0020.filter((_0x0037) => _0x0037.path.endsWith('/manifest.json'));
            if (_0x0036.length !== 1)
                throw new Error('업데이트 ZIP에서 manifest.json을 찾을 수 없습니다.');
            _0x0034 = _0x0036[0].path.slice(0, -'manifest.json'.length);
        }
        const _0x0038 = _0x0020.filter((_0x0039) => !_0x0034 || _0x0039.path.startsWith(_0x0034))
            .map((_0x003a) => ({ path: _0x0034 ? _0x003a.path.slice(_0x0034.length) : _0x003a.path, data: _0x003a.data }))
            .filter((_0x003b) => _0x003b.path && !_0x003b.path.startsWith('__MACOSX/'));
        if (!_0x0038.some((_0x003c) => _0x003c.path === 'manifest.json'))
            throw new Error('업데이트 ZIP에 루트 manifest.json이 없습니다.');
        return _0x0038;
    }
    _0x0001.EntryChatZipUpdate = { readZip: _0x0014, normalizePath: _0x0007 };
})(globalThis);
