# Entry Live Studio v2.1.6

- Chrome 123+ BFCache에서 장기 메시지 포트가 닫힐 때 발생하던 `runtime.lastError` 경고를 수정했습니다.
  - 명령 요청은 `chrome.runtime.sendMessage()`의 Promise 방식으로 분리했습니다.
  - 상태/이벤트 포트는 `pagehide`에서 정리하고 `pageshow`에서 다시 연결합니다.
  - `onDisconnect`에서 오류 상태를 소비해 Unchecked runtime.lastError를 남기지 않습니다.
- `https://supabase-settings-fetch.pages.dev/api/backup` 선택적 서버 백업 의존성을 제거했습니다.
  - 채팅 증거 백업은 원래 요구사항대로 `chrome.storage.sync` 암호화 백업을 계속 사용합니다.
  - 서버 R2 바인딩/엔드포인트 장애가 메시지 저장이나 전송에 영향을 주지 않습니다.
- 자동 업데이트를 복구 가능한 방식으로 수정했습니다.
  - 이전 업데이트에서 파일만 새 버전으로 바뀌고 런타임 재로드가 실패한 상태를 감지합니다.
  - 디스크 버전이 실행 버전보다 높은 경우 저장된 확장 폴더 표식을 검증한 뒤 재로드합니다.
  - 업데이트 적용 후 런타임 표식도 새 버전/buildId로 갱신합니다.
  - GitHub API 동시 업데이트 검사를 하나로 합치고 짧은 캐시를 사용합니다.
  - API 호출이 실패하거나 제한되면 GitHub 저장소 HTML에서 `message_Vx.x.x.zip` 파일명을 보조 탐색합니다.
