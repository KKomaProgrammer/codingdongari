(function () {
    const _0x0001 = chrome.runtime.getManifest();
    const _0x0002 = _0x0001.version;
    const _0x0003 = _0x0001.name;
    const _0x0004 = 'entry-live-studio-updater';
    const _0x0005 = 'handles';
    const _0x0006 = 'extensionSourceDirectory';
    let _0x0007 = null;
    let _0x0008 = false;
    const _0x0009 = (_0x000a) => document.getElementById(_0x000a);
    const _0x000b = _0x0009('currentVersion');
    const _0x000c = _0x0009('latestVersion');
    const _0x000d = _0x0009('status');
    const _0x000e = _0x0009('updateNow');
    const _0x000f = _0x0009('downloadOnly');
    _0x000b.textContent = `v${_0x0002}`;
    function _0x0010(_0x0011, _0x0012 = '') {
        _0x000d.textContent = _0x0011;
        _0x000d.className = `status${_0x0012 ? ` ${_0x0012}` : ''}`;
    }
    function _0x0013(_0x0014, _0x0015 = {}) {
        return new Promise((_0x0016, _0x0017) => {
            chrome.runtime.sendMessage({ type: 'ENTRY_CHAT_COMMAND', command: _0x0014, payload: _0x0015 }, (_0x0018) => {
                const _0x0019 = chrome.runtime.lastError;
                if (_0x0019) {
                    _0x0017(new Error(_0x0019.message));
                    return;
                }
                if (!_0x0018?.ok) {
                    _0x0017(new Error(_0x0018?.error || '확장 프로그램 명령에 실패했습니다.'));
                    return;
                }
                _0x0016(_0x0018.result);
            });
        });
    }
    function _0x001a() {
        return new Promise((_0x001b, _0x001c) => {
            const _0x001d = indexedDB.open(_0x0004, 1);
            _0x001d.onupgradeneeded = () => {
                if (!_0x001d.result.objectStoreNames.contains(_0x0005))
                    _0x001d.result.createObjectStore(_0x0005);
            };
            _0x001d.onsuccess = () => _0x001b(_0x001d.result);
            _0x001d.onerror = () => _0x001c(_0x001d.error || new Error('업데이트 설정 저장소를 열 수 없습니다.'));
        });
    }
    async function _0x001e() {
        try {
            const _0x001f = await _0x001a();
            return await new Promise((_0x0020, _0x0021) => {
                const _0x0022 = _0x001f.transaction(_0x0005, 'readonly');
                const _0x0023 = _0x0022.objectStore(_0x0005).get(_0x0006);
                _0x0023.onsuccess = () => _0x0020(_0x0023.result || null);
                _0x0023.onerror = () => _0x0021(_0x0023.error);
            });
        }
        catch (_0x0024) {
            return null;
        }
    }
    async function _0x0025(_0x0026) {
        const _0x0027 = await _0x001a();
        await new Promise((_0x0028, _0x0029) => {
            const _0x002a = _0x0027.transaction(_0x0005, 'readwrite');
            _0x002a.objectStore(_0x0005).put(_0x0026, _0x0006);
            _0x002a.oncomplete = _0x0028;
            _0x002a.onerror = () => _0x0029(_0x002a.error || new Error('폴더 권한 정보를 저장하지 못했습니다.'));
        });
    }
    async function _0x002b(_0x002c, _0x002d = false) {
        if (!_0x002c)
            return false;
        const _0x002e = { mode: 'readwrite' };
        try {
            if (await _0x002c.queryPermission(_0x002e) === 'granted')
                return true;
            if (_0x002d && await _0x002c.requestPermission(_0x002e) === 'granted')
                return true;
        }
        catch (_0x002f) { }
        return false;
    }
    async function _0x0030(_0x0031) {
        const _0x0032 = await _0x0031.getFileHandle('manifest.json');
        const _0x0033 = await _0x0032.getFile();
        return JSON.parse(await _0x0033.text());
    }
    async function _0x0034(_0x0035) {
        let _0x0036;
        try {
            _0x0036 = await _0x0030(_0x0035);
        }
        catch (_0x0037) {
            throw new Error('선택한 폴더에서 manifest.json을 읽을 수 없습니다. 현재 확장 프로그램의 압축해제 폴더를 선택하세요.');
        }
        if (_0x0036?.name !== _0x0003)
            throw new Error('선택한 폴더가 현재 메신저 확장 프로그램 폴더가 아닙니다.');
        if (Number(_0x0036?.manifest_version) !== 3)
            throw new Error('선택한 폴더의 manifest 형식이 현재 확장과 다릅니다.');
        return _0x0036;
    }
    function _0x0038(_0x0039) {
        const _0x003a = new URL(String(_0x0039 || ''));
        if (_0x003a.protocol !== 'https:' || _0x003a.hostname !== 'raw.githubusercontent.com')
            throw new Error('업데이트 다운로드 주소가 허용된 GitHub 주소가 아닙니다.');
        if (!_0x003a.pathname.startsWith('/KKomaProgrammer/codingdongari/'))
            throw new Error('허용되지 않은 업데이트 저장소입니다.');
        return _0x003a.href;
    }
    async function _0x003b(_0x003c) {
        const _0x003d = _0x0038(_0x003c.downloadUrl);
        _0x0010(`v${_0x003c.version} 패키지를 다운로드하고 있습니다…`);
        const _0x003e = await fetch(`${_0x003d}?t=${Date.now()}`, { cache: 'no-store' });
        if (!_0x003e.ok)
            throw new Error(`업데이트 ZIP 다운로드 실패 (${_0x003e.status})`);
        const _0x003f = await _0x003e.arrayBuffer();
        if (!_0x003f.byteLength || _0x003f.byteLength > 200 * 1024 * 1024)
            throw new Error('업데이트 ZIP 크기가 올바르지 않습니다.');
        _0x0010('업데이트 ZIP의 파일 구조를 검사하고 있습니다…');
        const _0x0040 = await globalThis.EntryChatZipUpdate.readZip(_0x003f);
        const _0x0041 = _0x0040.find((_0x0042) => _0x0042.path === 'manifest.json');
        const _0x0043 = JSON.parse(new TextDecoder().decode(_0x0041.data));
        if (_0x0043?.name !== _0x0003)
            throw new Error('업데이트 ZIP이 현재 메신저 확장 프로그램과 일치하지 않습니다.');
        if (Number(_0x0043?.manifest_version) !== 3)
            throw new Error('업데이트 ZIP의 manifest_version이 올바르지 않습니다.');
        if (String(_0x0043?.version || '') !== String(_0x003c.version || ''))
            throw new Error('ZIP 파일명 버전과 manifest.json 버전이 일치하지 않습니다.');
        return _0x0040;
    }
    async function _0x0044(_0x0045, _0x0046) {
        let _0x0047 = _0x0045;
        for (const _0x0048 of _0x0046)
            _0x0047 = await _0x0047.getDirectoryHandle(_0x0048, { create: true });
        return _0x0047;
    }
    async function _0x0049(_0x004a, _0x004b) {
        let _0x004c = 0;
        for (const _0x004d of _0x004b) {
            const _0x004e = _0x004d.path.split('/').filter(Boolean);
            const _0x004f = _0x004e.pop();
            if (!_0x004f)
                continue;
            const _0x0050 = await _0x0044(_0x004a, _0x004e);
            const _0x0051 = await _0x0050.getFileHandle(_0x004f, { create: true });
            const _0x0052 = await _0x0051.createWritable();
            try {
                await _0x0052.write(_0x004d.data);
            }
            finally {
                await _0x0052.close();
            }
            _0x004c += 1;
            if (_0x004c === 1 || _0x004c === _0x004b.length || _0x004c % 8 === 0)
                _0x0010(`확장 프로그램 파일을 갱신하고 있습니다… ${_0x004c}/${_0x004b.length}`);
        }
    }
    async function _0x0053(_0x0054) {
        if (_0x0008 || !_0x0007?.available)
            return;
        _0x0008 = true;
        _0x000e.disabled = true;
        _0x000f.disabled = true;
        try {
            await _0x0034(_0x0054);
            const _0x0055 = await _0x003b(_0x0007);
            await _0x0049(_0x0054, _0x0055);
            const _0x0056 = await _0x0030(_0x0054);
            if (String(_0x0056?.version || '') !== _0x0007.version)
                throw new Error('파일 쓰기 후 버전 검증에 실패했습니다.');
            _0x0010(`v${_0x0007.version} 업데이트가 완료되었습니다.\n확장 프로그램을 새 버전으로 다시 시작합니다…`, 'success');
            setTimeout(() => { _0x0013('RELOAD_EXTENSION').catch(() => { }); }, 900);
        }
        catch (_0x0057) {
            _0x0010(_0x0057?.message || String(_0x0057), 'error');
            _0x000e.disabled = false;
            _0x000f.disabled = false;
            _0x0008 = false;
        }
    }
    async function _0x0058() {
        if (_0x0008)
            return;
        let _0x0059 = await _0x001e();
        if (_0x0059 && await _0x002b(_0x0059, true)) {
            await _0x0053(_0x0059);
            return;
        }
        if (typeof window.showDirectoryPicker !== 'function') {
            _0x0010('이 환경에서는 폴더 직접 갱신 기능을 사용할 수 없습니다. ZIP을 받은 뒤 압축을 풀어 기존 확장 폴더를 교체하고 chrome://extensions에서 다시 로드하세요.', 'error');
            return;
        }
        try {
            _0x0059 = await window.showDirectoryPicker({ mode: 'readwrite', id: 'entry-live-studio-source' });
            await _0x0034(_0x0059);
            await _0x0025(_0x0059);
            await _0x0053(_0x0059);
        }
        catch (_0x005a) {
            if (_0x005a?.name === 'AbortError')
                return;
            _0x0010(_0x005a?.message || String(_0x005a), 'error');
        }
    }
    async function _0x005b() {
        try {
            _0x0007 = await _0x0013('CHECK_UPDATE');
            if (!_0x0007?.available) {
                _0x000c.textContent = '최신 버전';
                _0x0010(`현재 v${_0x0002}이 최신 버전입니다.`, 'success');
                return;
            }
            _0x000c.textContent = `v${_0x0007.version}`;
            _0x000e.disabled = false;
            _0x000f.disabled = false;
            _0x0010(`message_V${_0x0007.version}.zip 업데이트를 사용할 수 있습니다.`);
            const _0x005c = await _0x001e();
            if (_0x005c && await _0x002b(_0x005c, false)) {
                _0x0010(`v${_0x0007.version} 업데이트를 확인했습니다. 저장된 확장 폴더 권한으로 자동 갱신합니다…`);
                await _0x0053(_0x005c);
            }
        }
        catch (_0x005d) {
            _0x000c.textContent = '확인 실패';
            _0x0010(_0x005d?.message || String(_0x005d), 'error');
        }
    }
    _0x000e.addEventListener('click', _0x0058);
    _0x000f.addEventListener('click', () => {
        if (!_0x0007?.downloadUrl)
            return;
        chrome.tabs.create({ url: _0x0038(_0x0007.downloadUrl) }).catch((_0x005e) => _0x0010(_0x005e?.message || String(_0x005e), 'error'));
    });
    _0x005b();
})();
