chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(message?.type!=='ENTRY_OFFSCREEN_CLIPBOARD_READ'||message?.target!=='offscreen')return;
  navigator.clipboard.readText().then(text=>sendResponse({ok:true,text:String(text||'')})).catch(error=>sendResponse({ok:false,error:error?.message||String(error)}));
  return true;
});
