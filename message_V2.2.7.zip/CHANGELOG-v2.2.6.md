# Entry Live Studio v2.2.6

- 이전에 선택한 확장 폴더의 `FileSystemDirectoryHandle`을 IndexedDB에서 먼저 복원합니다. 쓰기 권한이 유지되어 있으면 폴더 선택창 없이 즉시 업데이트합니다.
- 저장된 핸들의 권한만 만료된 경우 폴더 선택창을 다시 열지 않고 `requestPermission()`으로 이전 폴더 접근 권한만 다시 요청합니다.
- `showDirectoryPicker()`를 자동 실행하던 3초 카운트다운을 제거했습니다. 디렉터리 선택기는 반드시 사용자가 `폴더 접근 허용` 버튼을 직접 누른 동기 사용자 제스처에서만 호출합니다.
- 최초 폴더 연결 시 `chrome://extensions/?id=ciakccaaaajgmhljahjhpocgphlhcjbe` 출처 안내 흐름을 추가했습니다. `로드 위치` 경로 복사를 감지하면 출처 탭을 닫고 updater 탭으로 돌아옵니다.
- 클립보드 감지는 `chrome.offscreen`의 `CLIPBOARD` 문서로 한시적으로 수행하며, 다른 클립보드 내용은 저장하지 않습니다. 읽기 실패 시에만 경로 입력 상자를 표시합니다.
- manifest에 고정 `key`를 추가해 v2.2.6 이후 unpacked 확장 ID를 `ciakccaaaajgmhljahjhpocgphlhcjbe`로 고정합니다.
- 보안상 경로 문자열만으로 `FileSystemDirectoryHandle`을 생성할 수 없으므로 최초 한 번은 사용자 클릭으로 폴더 선택기를 열어 해당 폴더를 승인해야 합니다.
