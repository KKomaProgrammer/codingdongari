# Supabase 설정 — v2.2.7

## 1. SQL Editor

`KKomaProgrammer/supabase-settings-fetch` 저장소의 `SUPABASE_V227.sql` 전체를 Supabase Dashboard → SQL Editor에서 한 번 실행합니다.

생성되는 테이블:

- `entry_chat_accounts` — 계정/고유 닉네임/계정 코드 해시
- `entry_chat_account_devices` — 기기 fingerprint SHA-256 → 계정 매핑, 보조 IP 해시
- `entry_chat_room_recommendations` — `(room_code, target_account_id)`를 PK로 하여 중복 추천 차단
- `entry_chat_room_recommendation_blocks` — 사용자의 방별 추천 차단

모든 테이블은 RLS를 켜고 anon/authenticated 권한을 제거합니다. 브라우저는 이 테이블에 직접 접근하지 않고 Cloudflare Pages 함수만 service-role로 접근합니다.

## 2. Cloudflare Pages 환경변수

기존 값에 아래 두 개를 추가합니다.

- `SUPABASE_SERVICE_ROLE_KEY` — Supabase Project Settings → API의 service role/secret key. **확장 프로그램에 넣지 말고 Cloudflare secret으로만 저장합니다.**
- `DEVICE_IP_HASH_SALT` — 충분히 긴 임의 문자열. 예: 32바이트 이상 랜덤값. 원 IP 대신 `SHA-256(salt + IP)` 보조 해시를 만들 때만 사용합니다.

기존 `SUPABASE_URL`, `SUPABASE_ANON_KEY`는 그대로 유지합니다.

`ALLOWED_ORIGINS`를 사용 중이면 고정 확장 ID의 origin `chrome-extension://ciakccaaaajgmhljahjhpocgphlhcjbe`도 허용 목록에 추가하세요.

## 3. 보안 구조

- 원본 fingerprint 구성값은 서버로 보내지 않고 브라우저에서 SHA-256한 값만 보냅니다.
- 원본 IP는 Supabase에 저장하지 않습니다. Cloudflare가 본 IP는 `DEVICE_IP_HASH_SALT`와 함께 SHA-256한 보조값으로만 기록합니다.
- 동일 IP만으로 계정 생성을 막지 않습니다.
- `fingerprint_hash`는 PK라 같은 fingerprint가 다른 계정에 동시에 연결될 수 없습니다.
- `nickname_normalized`는 UNIQUE라 대소문자/정규화 후 같은 닉네임을 중복 사용할 수 없습니다.
