# v2.2.9

- 업데이트 출처 경로 감지를 updater 탭 타이머에서 offscreen 지속 감시 방식으로 변경했습니다.
- 로드 위치 경로 복사 감지 시 `chrome://extensions` 탭을 자동으로 닫고 updater 탭으로 복귀합니다.
- 감지한 경로를 updater 입력 상태에 실제 반영합니다.
- 이미 저장된 FileSystemDirectoryHandle이 있으면 폴더 선택창 없이 재사용하며, 권한 만료 시 기존 핸들의 권한만 다시 요청합니다.
- 최초 연결에만 `showDirectoryPicker()`를 사용하며 동일 picker id로 Chrome의 최근 위치 기억을 재사용합니다.
