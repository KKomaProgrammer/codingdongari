let watchTimer=null;
let watchLast='';
let watchFailures=0;
function stopWatch(){if(watchTimer)clearInterval(watchTimer);watchTimer=null;watchFailures=0;}
function plausiblePath(value){const v=String(value||'').trim();if(v.length<3||/^https?:/i.test(v)||/^chrome:/i.test(v))return '';if(/^[A-Za-z]:[\\/]/.test(v)||/^\\\\[^\\]+\\/.test(v)||/^\/(Users|home|Volumes|mnt|media)\//.test(v))return v;return '';}
async function readClipboard(){return String(await navigator.clipboard.readText()||'');}
async function sampleClipboard(){try{const text=await readClipboard();watchFailures=0;if(text!==watchLast){watchLast=text;const path=plausiblePath(text);if(path){stopWatch();chrome.runtime.sendMessage({type:'ENTRY_OFFSCREEN_CLIPBOARD_CHANGED',target:'background',text:path}).catch(()=>{});}}}catch(error){watchFailures++;if(watchFailures===8){chrome.runtime.sendMessage({type:'ENTRY_OFFSCREEN_CLIPBOARD_WATCH_ERROR',target:'background',error:error?.message||String(error)}).catch(()=>{});}}}
function startWatch(initial){stopWatch();watchLast=String(initial||'');watchFailures=0;watchTimer=setInterval(sampleClipboard,400);sampleClipboard();}
chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{
  if(message?.target!=='offscreen')return;
  if(message?.type==='ENTRY_OFFSCREEN_CLIPBOARD_READ'){readClipboard().then(text=>sendResponse({ok:true,text})).catch(error=>sendResponse({ok:false,error:error?.message||String(error)}));return true;}
  if(message?.type==='ENTRY_OFFSCREEN_CLIPBOARD_WATCH_START'){startWatch(message.initialClipboard);sendResponse({ok:true});return;}
  if(message?.type==='ENTRY_OFFSCREEN_CLIPBOARD_WATCH_STOP'){stopWatch();sendResponse({ok:true});return;}
});
