# Entry Live Studio v2.1.9

- 업데이트 화면을 ZIP 중심 흐름으로 변경했습니다.
- 새 버전을 찾으면 `message_Vx.x.x.zip`을 기본 다운로드합니다.
- 다운로드한 ZIP을 `ZIP 불러오기`로 직접 선택할 수 있습니다.
- 선택한 ZIP의 파일명, manifest 버전, build-info 버전/buildId를 검증한 뒤 자동 압축 해제하여 실제 확장 폴더에 적용합니다.
- ZIP은 사용자가 직접 압축 해제할 필요가 없습니다.
- Chrome downloads 권한을 사용하여 업데이트 ZIP 다운로드를 안정적으로 시작합니다.
