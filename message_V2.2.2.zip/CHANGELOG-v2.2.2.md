# Entry Live Studio v2.2.2

- 업데이트 필요 여부는 페이지 새로고침 시 확장 프로그램이 GitHub 버전 목록만 확인합니다.
- 실제 업데이트 패키지는 업데이트를 시작할 때 Cloudflare Pages `/api/current/update-package`에서 받습니다.
- Pages는 `UPDATE_PACKAGE_KV`에 버전별 ZIP을 캐시하므로 같은 버전은 GitHub에서 다시 가져오지 않습니다.
- 확장 프로그램도 받은 ZIP을 `chrome.storage.local`에 버전/SHA-256과 함께 캐시해 updater를 다시 열어도 재요청하지 않습니다.
- 필수 업데이트 정책은 `MANDATORY_UPDATE=1`이면 발견된 최신 버전을 필수, `0`/미설정이면 선택 업데이트로 처리합니다.
