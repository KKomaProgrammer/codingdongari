# Entry Live Studio v2.2.0

- 최신 버전 전용 서버 요청 경로를 적용했습니다.
- 상태 확인: `/api/current/status`
- Supabase 서버 설정: `/api/current/settings`
- 기존 `/api/status`, `/api/settings`는 구버전 차단용으로 분리했습니다.
- `/api/backup` 경로는 변경하지 않았습니다.
- 나머지 채팅/업데이트 기능은 v2.1.9와 동일하게 유지합니다.
