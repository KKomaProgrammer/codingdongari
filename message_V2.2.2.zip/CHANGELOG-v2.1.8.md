# Entry Live Studio v2.1.8

- 업데이트 ZIP의 파일명, manifest.json, build-info.json 버전을 모두 2.1.8로 통일했습니다.
- productId와 buildId를 기존 updater 검증 규격에 맞게 재생성했습니다.
- 저장소의 잘못된 v2.1.7 패키지를 건너뛰고 v2.1.8을 최신 업데이트로 사용합니다.
