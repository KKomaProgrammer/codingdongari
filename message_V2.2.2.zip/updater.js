(function(){
const manifest=chrome.runtime.getManifest(),current=manifest.version,DB='entry-live-studio-updater-v2',STORE='handles',KEY='extensionSourceDirectory',CACHE='entryChatUpdatePackageCacheV2';
const $=id=>document.getElementById(id);let info=null,pkg=null,busy=false;
$('currentVersion').textContent=`v${current}`;
function progress(value,text){$('progressBar').style.width=`${Math.max(0,Math.min(100,value))}%`;if(text)$('status').textContent=text;}
function compare(a,b){const x=String(a||'').split('.').map(Number),y=String(b||'').split('.').map(Number);if(x.length!==3||y.length!==3||x.some(Number.isNaN)||y.some(Number.isNaN))return 0;for(let i=0;i<3;i++)if(x[i]!==y[i])return x[i]>y[i]?1:-1;return 0;}
function base64Bytes(value){const s=atob(String(value||'')),out=new Uint8Array(s.length);for(let i=0;i<s.length;i++)out[i]=s.charCodeAt(i);return out;}
async function sha256(bytes){const d=await crypto.subtle.digest('SHA-256',bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));return [...new Uint8Array(d)].map(b=>b.toString(16).padStart(2,'0')).join('');}
function openDb(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(STORE))r.result.createObjectStore(STORE)};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
async function loadHandle(){try{const db=await openDb();return await new Promise((resolve,reject)=>{const r=db.transaction(STORE,'readonly').objectStore(STORE).get(KEY);r.onsuccess=()=>resolve(r.result||null);r.onerror=()=>reject(r.error);});}catch(_){return null}}
async function saveHandle(handle){const db=await openDb();await new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).put(handle,KEY);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});}
async function permission(handle,ask=false){if(!handle)return false;const o={mode:'readwrite'};try{if(await handle.queryPermission(o)==='granted')return true;if(ask&&await handle.requestPermission(o)==='granted')return true}catch(_){}return false;}
async function readJson(handle,name){const fh=await handle.getFileHandle(name);return JSON.parse(await(await fh.getFile()).text());}
async function getPackageRecord(version){
    const stored=(await chrome.storage.local.get(CACHE))[CACHE];
    if(stored?.version===version&&stored?.packageBase64&&/^[a-f0-9]{64}$/i.test(String(stored.sha256||''))){
        try{const bytes=base64Bytes(stored.packageBase64);if((await sha256(bytes))===String(stored.sha256).toLowerCase()){progress(18,'저장된 업데이트 사용 중…');return stored;}}catch(_){}
        await chrome.storage.local.remove(CACHE);
    }
    progress(12,'업데이트 받는 중…');
    const fresh=await EntrySettingsFetch.fetchUpdatePackage(version,{timeout:45000});
    await chrome.storage.local.set({[CACHE]:fresh});
    return fresh;
}
async function loadPackage(){
    const version=String(new URLSearchParams(location.search).get('version')||'').trim();
    if(!/^\d+\.\d+\.\d+$/.test(version)||compare(version,current)<=0)throw new Error('업데이트 정보를 다시 확인하려면 페이지를 새로고침하세요.');
    info={available:true,currentVersion:current,version,filename:`message_V${version}.zip`};
    $('latestVersion').textContent=`v${version}`;
    const record=await getPackageRecord(version),bytes=base64Bytes(record.packageBase64);
    const digest=await sha256(bytes);if(digest!==String(record.sha256).toLowerCase())throw new Error('저장된 업데이트 파일 검증에 실패했습니다.');
    progress(28,'업데이트 확인 중…');
    const entries=await EntryChatZipUpdate.readZip(bytes.buffer);const md=new TextDecoder();const me=entries.find(e=>e.path==='manifest.json'),be=entries.find(e=>e.path==='build-info.json');
    if(!me||!be)throw new Error('업데이트 파일을 확인할 수 없습니다.');
    const m=JSON.parse(md.decode(me.data)),b=JSON.parse(md.decode(be.data));
    if(m.name!==manifest.name||Number(m.manifest_version)!==3||String(m.version)!==version||String(b.version)!==version||!String(b.buildId||'').trim())throw new Error('업데이트 파일 정보가 올바르지 않습니다.');
    pkg={entries,manifest:m,build:b};progress(35,'업데이트 준비 완료');
}
async function dirFor(root,parts){let d=root;for(const p of parts)d=await d.getDirectoryHandle(p,{create:true});return d;}
async function writeEntry(root,e){const parts=e.path.split('/').filter(Boolean),name=parts.pop();if(!name)return;const d=await dirFor(root,parts),fh=await d.getFileHandle(name,{create:true}),w=await fh.createWritable();try{await w.write(e.data)}finally{await w.close()}}
async function validateTarget(handle){const m=await readJson(handle,'manifest.json'),b=await readJson(handle,'build-info.json');if(m.name!==manifest.name||Number(m.manifest_version)!==3)throw new Error('현재 확장 프로그램을 로드한 폴더를 선택하세요.');if(!String(b.buildId||'').trim())throw new Error('선택한 폴더를 확인할 수 없습니다.');return{manifest:m,build:b};}
async function apply(handle){if(busy)return;busy=true;try{await validateTarget(handle);progress(45,'파일 적용 중…');const list=pkg.entries.filter(e=>e.path!=='manifest.json');let n=0;for(const e of list){await writeEntry(handle,e);n++;progress(45+Math.round((n/Math.max(1,list.length))*45),'파일 적용 중…');}await writeEntry(handle,pkg.entries.find(e=>e.path==='manifest.json'));const m=await readJson(handle,'manifest.json'),b=await readJson(handle,'build-info.json');if(String(m.version)!==info.version||String(b.version)!==info.version||String(b.buildId)!==String(pkg.build.buildId))throw new Error('업데이트 적용을 확인하지 못했습니다.');progress(100,'업데이트 완료');setTimeout(()=>chrome.runtime.reload(),500);}catch(e){busy=false;progress(35,e?.message||String(e));$('folderButton').hidden=false;}}
async function choose(){try{const h=await window.showDirectoryPicker({mode:'readwrite',id:'entry-live-studio-source'});await validateTarget(h);await saveHandle(h);await apply(h);}catch(e){if(e?.name!=='AbortError')progress(35,e?.message||String(e));$('folderButton').hidden=false;}}
async function startFolderFlow(){const g=$('guide');g.hidden=false;for(let i=3;i>0;i--){$('countdown').textContent=`${i}초 후 폴더 선택을 시작합니다.`;await new Promise(r=>setTimeout(r,1000));}const h=await loadHandle();if(h&&await permission(h,false)){await apply(h);return;}try{await choose();}catch(_){$('folderButton').hidden=false;}}
$('folderButton').addEventListener('click',choose);
(async()=>{try{await loadPackage();await startFolderFlow();}catch(e){progress(0,e?.message||String(e));}})();
})();
