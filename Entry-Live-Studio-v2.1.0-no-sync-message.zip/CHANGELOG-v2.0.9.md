# v2.0.9 수정/분석 기록

## 원본 v2.0.8에서 확인한 구조

- Manifest V3 service worker인 `background.js`가 방/사용자/메시지 상태와 Supabase Realtime 연결을 담당합니다.
- `content/chat.js`가 모든 일반 웹페이지에 Shadow DOM 기반 채팅 UI를 삽입합니다.
- `shared/chat-store.js`가 IndexedDB + `chrome.storage.local` 이중 저장을 담당합니다.
- `shared/settings-fetch.js`는 원래 `/api/settings` 로그인 설정 조회만 담당했습니다.
- 원본의 이미지 첨부 UI/전송 구조는 1개 파일만 처리했습니다.
- 원본의 전체 채팅 항목은 참가자 콜라주가 아니라 문자형 아이콘을 사용했습니다.

## 설정 서버 저장소와 맞춘 부분

`KKomaProgrammer/supabase-settings-fetch`의 현재 구조에 맞춰 다음 엔드포인트를 사용합니다.

- `POST /api/settings`: 접속 비밀번호 검증 및 Supabase 공개 설정 반환
- `GET /api/status`: `EXTENSION_ACCESS_MODE` 조회
- `/api/backup`: 복구 코드 기반 암호화 백업 저장/읽기/삭제

환경변수 `EXTENSION_ACCESS_MODE`:

- `0` 또는 미설정: 정상
- `1`: 점검중
- `2`: 사용 불가

클라우드 전체 백업에는 Cloudflare Pages의 R2 바인딩 `CHAT_BACKUP_BUCKET`이 필요합니다.

## 구현한 기능

### 즉시 증거 백업

메시지 송신/수신 시 `persistMessageRecord()`에서 다음을 연속 수행합니다.

1. IndexedDB + `chrome.storage.local` 전체 저장
2. `chrome.storage.sync` 암호화 레코드 즉시 저장 시도
3. R2 전체 암호화 레코드 즉시 저장 시도
4. 로컬 자동 백업 스냅샷 갱신 예약

`chrome.storage.sync`는 저장 한도가 작으므로 사진 원본은 넣지 않고 이미지 SHA-256을 넣습니다. 동기화 레코드 자체는 복구 코드에서 파생한 AES-GCM 키로 암호화합니다.

### 복구 코드

- 설치별 복구 코드 자동 생성
- 복구 코드 화면 표시
- 복구 코드로 Chrome 동기화 + R2 백업 병합 복구
- 현재 복구 코드에 연결된 R2 백업 삭제
- 서버에는 복구 코드 원문을 보내지 않음

### 다중 이미지

- 파일 선택 input에 `multiple` 적용
- 최대 12장
- 처리 중 별도 `이미지 업로드 중…` 상태 표시
- 사진별 독립 메시지 전송
- 부분 실패 시 성공한 사진은 제외하고 남은 사진만 재시도 가능

### 전체 채팅 콜라주

- 1명: 단일 아이콘
- 2명: 좌상/우하 대각선
- 3명: 상단 중앙/좌하/우하
- 4명: 4분할
- 5명 이상: 앞 4명 4분할 + 우측 상단 `+(전체 인원-4)`

### 접근 상태

- 시작할 때 `/api/status` 확인
- 실행 중 약 30초 간격으로 재확인
- 점검중/사용 불가 상태면 Realtime 연결 중단
- 해당 상태에서는 비밀번호 입력창을 렌더링하지 않음
- 정상 상태로 돌아오면 세션 설정이 있으면 자동 재연결 시도

### 최초 이용 안내

`entryChatTermsAcceptedV1` 로컬 플래그로 1회성 이용 안내를 구현했습니다. 이용 목적과 부적절한 사용 책임, 암호화 백업 처리 사실을 함께 고지합니다.

## 의도적으로 제외한 요청

다음 기능은 다른 사용자가 모르는 상태에서 사적 채팅을 원격 수집·복호화하거나 삭제 동작을 우회할 수 있어 넣지 않았습니다.

- 숨은 하위 URL에서 모든 사용자의 `chrome.storage.sync`를 강제 회수하는 기능
- 관리자 마스터 비밀번호로 타인의 복구 코드를 우회하는 기능
- 로그인 IP를 장기/단기 식별키로 저장한 뒤 IP를 이용해 삭제된 확장의 채팅을 우회 회수하는 기능

대신 사용자 소유 복구 코드/백업 파일을 통한 증거 제출 구조를 사용합니다. 별도 승인형 증거 제출 포털을 만든다면 비밀번호 환경변수 이름은 `EVIDENCE_PORTAL_PASSWORD_SHA256`을 권장하지만, 이 빌드에서는 타인 저장소의 숨은 원격 조회 기능과 연결하지 않습니다.

## 검증

- `npm test` 통과
- `npm run validate` 통과
- 6개 JavaScript 파일 `node --check` 통과
- `shared/chat-backup.js`의 AES-GCM 암복호화 + `chrome.storage.sync` 저장/복구 왕복 테스트 통과
