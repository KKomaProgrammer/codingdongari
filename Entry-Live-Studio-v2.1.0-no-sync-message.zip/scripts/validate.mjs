import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const files = ['background.js','shared/settings-fetch.js','shared/chat-realtime.js','shared/chat-store.js','shared/chat-backup.js','content/chat.js'];
for (const file of files) execFileSync(process.execPath, ['--check', path.join(root, file)], { stdio: 'pipe' });
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
if (manifest.version !== '2.1.0') throw new Error('manifest version mismatch');
if (!manifest.content_scripts?.some((item) => item.matches?.includes('<all_urls>'))) throw new Error('all_urls content script missing');
console.log(`검증 완료: ${files.length}개 JavaScript + manifest`);
