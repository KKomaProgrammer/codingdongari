import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
const background = fs.readFileSync(path.join(root, 'background.js'), 'utf8');
const chat = fs.readFileSync(path.join(root, 'content/chat.js'), 'utf8');
const realtime = fs.readFileSync(path.join(root, 'shared/chat-realtime.js'), 'utf8');
const backup = fs.readFileSync(path.join(root, 'shared/chat-backup.js'), 'utf8');
const settings = fs.readFileSync(path.join(root, 'shared/settings-fetch.js'), 'utf8');

const assert = (value, message) => { if (!value) throw new Error(message); };
assert(manifest.name === '이준우가 만든 종합 채팅 확장프로램', '확장 프로그램 이름이 요청값과 다릅니다.');
assert(!manifest.content_scripts[0].css, '존재하지 않는 content/chat.css 참조가 남아 있습니다.');
assert(manifest.icons?.['128'] === 'assets/chat-ext-128.png', 'manifest 확장 아이콘이 새 아이콘으로 변경되지 않았습니다.');
assert(manifest.web_accessible_resources?.some((entry) => entry.resources?.includes('assets/chat-ext-48.png') && entry.matches?.includes('<all_urls>')), '채팅창 제목 아이콘이 web_accessible_resources에 등록되지 않았습니다.');
assert(chat.includes('.launcher svg{width:25px;height:25px'), '화면 우측 하단 채팅 아이콘이 변경되었습니다.');
assert(chat.includes('<b>채팅창</b>'), '채팅 박스 제목이 채팅창으로 변경되지 않았습니다.');
assert(chat.includes("chrome.runtime.getURL('assets/chat-ext-48.png')") && chat.includes('class="brandicon"'), '채팅 박스 제목 아이콘에 manifest 확장 아이콘이 반영되지 않았습니다.');
assert(chat.includes('#panelBody{height:100%;min-height:0;overflow:hidden}') && chat.includes('.main{height:100%;min-height:0;overflow:hidden'), '로그인 후 패널 하단 잘림 방지 레이아웃이 없습니다.');
assert(chat.includes('100dvh') && chat.includes('max-height:calc(100dvh - 16px)'), '동적 브라우저 높이에 맞춘 패널 크기 보정이 없습니다.');
assert(chat.includes('background:#f9dc4b') && chat.includes('.msg.mine .bubble'), '메신저형 채팅 디자인이 반영되지 않았습니다.');

assert(manifest.permissions.includes('storage') && manifest.permissions.includes('unlimitedStorage'), '채팅 영구 저장에 필요한 storage/unlimitedStorage 권한이 없습니다.');
assert(!manifest.permissions.includes('tabCapture') && !manifest.permissions.includes('offscreen'), '화면 공유 권한이 남아 있습니다.');
assert(manifest.content_scripts[0].matches.includes('<all_urls>'), '모든 사이트 주입 설정이 없습니다.');
assert(!background.includes('captureVisibleTab') && !background.includes('tabCapture') && !background.includes('RTCPeerConnection'), '화면 공유/P2P 코드가 남아 있습니다.');
assert(background.includes("String(1000 + Math.floor(Math.random() * 9000))"), '4자리 숫자 방 코드 생성 로직이 없습니다.');
assert(background.includes("case 'CREATE_ROOM'") && background.includes("case 'JOIN_ROOM'") && background.includes("case 'RENAME_ROOM'"), '방 생성/참가/이름 수정 기능이 없습니다.');
assert(background.includes('rooms = new Map()') && background.includes('reconnectSavedRooms'), '여러 채팅방 동시 연결 구조가 없습니다.');
assert(background.includes('room.isLeader') && chat.includes('대표'), '방 생성자 대표 표시가 없습니다.');
assert(chat.includes('data-open-room=') && chat.includes('data-open-chat=') && chat.includes("state.view = 'room'") && chat.includes("state.view = 'conversation'"), '방 목록 → 방 → 대화 단계형 UI 구조가 없습니다.');
assert(chat.includes('전체 채팅') && chat.includes('개인 채팅'), '전체/개인 채팅 구분이 없습니다.');
assert(chat.includes('backToRooms') && chat.includes('backToRoom') && chat.includes('들어가기 ›'), '방 들어가기/뒤로가기 탐색이 없습니다.');
assert(chat.includes('saveCurrentDraft()') && chat.includes('state.drafts.get(key)'), '화면 전환 중 채팅 초안 보존 처리가 없습니다.');
assert(chat.includes('position:fixed;right:18px;bottom:18px'), '우측 하단 채팅 아이콘이 없습니다.');
assert(chat.includes("entryChatLauncherPosition"), '채팅 아이콘 위치 저장 키가 없습니다.');
assert(chat.includes("chrome.storage.onChanged.addListener"), '다른 페이지로 아이콘 위치를 실시간 동기화하는 리스너가 없습니다.');
assert(chat.includes("await chrome.storage.local.set({ [LAUNCHER_POSITION_KEY]: next })"), '드래그 종료 위치 저장 기능이 없습니다.');
assert(chat.includes("launcher.addEventListener('pointermove'") && chat.includes("launcher.addEventListener('pointerup'"), '채팅 아이콘 드래그 기능이 없습니다.');
assert(chat.includes("if (moved && !cancelled)") && chat.includes("togglePanel(!state.open)"), '드래그와 클릭 동작 분리가 없습니다.');
assert(background.includes('entryChatRooms') && background.includes('entryChatServerConfig'), '방 목록 저장/세션 설정 구조가 없습니다.');
assert(background.includes("chrome.storage.session.set({ entryChatServerConfig: config })"), 'Supabase 설정이 세션 저장 방식이 아닙니다.');
assert(!background.includes('password:') || background.includes('fetchSettings(password)'), '비밀번호 처리 구조를 확인하세요.');

assert(chat.includes("document.addEventListener('pointerdown'") && chat.includes("togglePanel(false)"), '채팅창 바깥 클릭 시 닫기 기능이 없습니다.');
assert(chat.includes('나와의 채팅') && background.includes("case 'SEND_SELF_CHAT'"), '나와의 채팅 기능이 없습니다.');
assert(chat.includes('editProfilePhoto') && background.includes("case 'SET_PROFILE_IMAGE'"), '프로필 사진 설정 기능이 없습니다.');
assert(chat.includes('messageImageInput') && chat.includes('compressImageFile') && background.includes('imageDataUrl'), '채팅 사진 첨부 기능이 없습니다.');
assert(background.includes('EntryChatDurableStore') && background.includes("persistMessageRecord('room'") && background.includes("persistMessageRecord('self'"), '채팅/사진 이중 저장 연결이 없습니다.');
assert(fs.existsSync(path.join(root, 'shared/chat-store.js')), 'IndexedDB + chrome.storage.local 이중 저장 모듈이 없습니다.');
const storeSource = fs.readFileSync(path.join(root, 'shared/chat-store.js'), 'utf8');
assert(storeSource.includes('indexedDB.open') && storeSource.includes('chrome.storage.local.set'), '이중 저장소 구현이 완전하지 않습니다.');
assert(chat.includes('백업 내보내기') && chat.includes('백업 복구') && background.includes("case 'EXPORT_BACKUP'") && background.includes("case 'IMPORT_BACKUP'"), '백업 파일 내보내기/복구 기능이 없습니다.');
assert(fs.existsSync(path.join(root, 'CHAT_RECOVERY.md')), '복구 가이드 MD가 패키지에 없습니다.');

const sandbox = { globalThis: {}, console, setTimeout, clearTimeout, setInterval, clearInterval };
vm.createContext(sandbox);
vm.runInContext(realtime, sandbox);
assert(typeof sandbox.globalThis.EntryChatRealtimeHub === 'function', 'Realtime hub를 로드할 수 없습니다.');
const hub = new sandbox.globalThis.EntryChatRealtimeHub({ url:'https://example.supabase.co', key:'x' });
assert(hub.normalizeTopic('els-chat-room-1234') === 'realtime:els-chat-room-1234', 'Realtime topic 정규화 실패');


assert(manifest.version === '2.1.0', 'manifest 버전이 v2.1.0가 아닙니다.');
assert(background.includes("'shared/chat-backup.js'") && background.includes('EntryChatSyncEvidenceStore') && background.includes('saveCloudRecord(record)'), '즉시 암호화 백업 연결이 없습니다.');
assert(backup.includes('chrome.storage.sync.set') && backup.includes('AES-GCM') && backup.includes('imageSha256'), 'chrome.storage.sync 암호화 증거 백업 구현이 없습니다.');
assert(backup.includes('SYNC_SOFT_LIMIT_BYTES') && backup.includes('SYNC_TARGET_BYTES'), 'Chrome sync 용량 정리 로직이 없습니다.');
assert(settings.includes("STATUS_URL = `${API_BASE}/status`") && background.includes('STATUS_POLL_MS = 30000'), '확장 사용 상태 확인/주기 폴링이 없습니다.');
assert(background.includes("case 'ACCEPT_TERMS'") && chat.includes('이용 전 확인'), '최초 1회 이용 안내가 없습니다.');
assert(chat.includes('이미지 업로드 중…') && chat.includes('multiple hidden') && chat.includes('최대 12개'), '다중 이미지 업로드 UX가 없습니다.');
assert(chat.includes('pendingImages.slice(sentCount)') && chat.includes('const items = pendingImages.length ? pendingImages : [null]'), '다중 이미지 부분 실패 복구 전송 로직이 없습니다.');
assert(chat.includes('groupAvatarHtml(room.users || [])') && chat.includes('people.length - 4'), '전체 채팅 참가자 콜라주/+N 표시가 없습니다.');
assert(chat.includes("Number(state.data.accessMode) === 1") && chat.includes('renderAccessBlocked()'), '점검중/사용 불가에서 로그인 UI 차단 처리가 없습니다.');
assert(background.includes("case 'GET_RECOVERY_INFO'") && background.includes("case 'RECOVER_WITH_CODE'") && background.includes("case 'DELETE_CLOUD_BACKUP'"), '복구 코드 기반 백업 관리 명령이 없습니다.');
assert(!background.includes('CF-Connecting-IP') && !background.includes('X-Forwarded-For'), '원치 않는 IP 수집 코드가 포함되어 있습니다.');
assert(chat.includes('captureComposerFocus') && chat.includes('restoreComposerFocus') && chat.includes("root.activeElement !== input"), '상태 재렌더 시 입력창 포커스/커서 복원 코드가 없습니다.');
assert(!chat.includes('메시지와 사진은 IndexedDB와 Chrome 로컬 저장소에 이중 저장됩니다. 확장 삭제/Chrome 데이터 삭제에 대비하려면 백업 파일도 보관하세요.'), '삭제 요청한 저장 안내 문구가 남아 있습니다.');
assert(background.includes('automaticBackupLatest') && background.includes('markAutomaticBackupDirty') && background.includes('writeAutomaticBackup'), '자동 백업 스냅샷 기능이 없습니다.');
assert(chat.includes('const focusSnapshot = captureComposerFocus();') && chat.includes('restoreComposerFocus(focusSnapshot);'), '상대 메시지 상태 갱신 경로의 입력 포커스 복원이 없습니다.');

assert(manifest.host_permissions.includes('https://img.bloupla.net/*'), 'img.bloupla.net 임시 암호화 이미지 보관 권한이 없습니다.');
assert(background.includes("TEMP_IMAGE_BACKUP_URL = 'https://img.bloupla.net/api/upload'") && background.includes("case 'BACKUP_ORIGINAL_IMAGE_TEMP'") && background.includes('AES-GCM-256'), '원본 이미지 암호화 임시 보관 연결이 없습니다.');
assert(chat.includes('imageGroupId') && chat.includes('groupedMessages(messages)') && chat.includes('gallery-more'), '다중 사진 묶음 메시지/최대 9개 미리보기 구현이 없습니다.');
assert(chat.includes('msg-avatar') && chat.includes('senderAvatar('), '모든 메시지의 발신자 프로필 표시가 없습니다.');
assert(chat.includes("shortcutKey: 'Alt'") && chat.includes('installPageShortcut') && chat.includes('SHORTCUT_KEYS'), 'Alt 두 번 기본 단축키/변경 기능이 없습니다.');
assert(chat.includes('drop-trash') && chat.includes('requestHideCurrentPageFromDrag') && chat.includes('확인 (${remain})'), '드래그 숨김 및 최초 3초 확인 기능이 없습니다.');
assert(!chat.includes('id="recoverByCode"') && !chat.includes('id="deleteCloudBackup"'), '삭제 요청된 복구 코드 복구/클라우드 백업 삭제 버튼이 남아 있습니다.');

console.log('테스트 완료: 바깥 클릭 닫기, 나와의 채팅, 사진/백업, 자동 백업, 주기 상태 갱신 후 입력 포커스 유지');
