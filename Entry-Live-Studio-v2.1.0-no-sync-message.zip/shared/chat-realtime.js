(function (root) {
  class EntryChatRealtimeHub {
    constructor({ url, key, onBroadcast, onStatus }) {
      this.url = String(url || '').replace(/\/$/, '');
      this.key = String(key || '');
      this.onBroadcast = onBroadcast || (() => {});
      this.onStatus = onStatus || (() => {});
      this.socket = null;
      this.ref = 0;
      this.channels = new Map();
      this.closed = false;
      this.reconnectCount = 0;
      this.heartbeatTimer = null;
      this.reconnectTimer = null;
      this.openPromise = null;
    }

    connect() {
      if (this.closed) return Promise.reject(new Error('연결이 종료되었습니다.'));
      if (this.socket?.readyState === WebSocket.OPEN) return Promise.resolve();
      if (this.openPromise) return this.openPromise;
      this.openPromise = new Promise((resolve, reject) => {
        const socketUrl = this.url.replace(/^http:/, 'ws:').replace(/^https:/, 'wss:');
        const wsUrl = `${socketUrl}/realtime/v1/websocket?apikey=${encodeURIComponent(this.key)}&vsn=1.0.0`;
        try { this.socket = new WebSocket(wsUrl); }
        catch (error) { this.openPromise = null; reject(error); return; }
        this.onStatus('connecting');
        const fail = () => {
          if (this.openPromise) reject(new Error('실시간 서버에 연결할 수 없습니다.'));
          this.openPromise = null;
        };
        this.socket.addEventListener('open', () => {
          this.reconnectCount = 0;
          this.onStatus('online');
          clearInterval(this.heartbeatTimer);
          this.heartbeatTimer = setInterval(() => this.heartbeat(), 25000);
          const topics = [...this.channels.keys()];
          for (const topic of topics) this.join(topic, true);
          this.openPromise = null;
          resolve();
        }, { once: true });
        this.socket.addEventListener('message', (event) => this.handleMessage(event.data));
        this.socket.addEventListener('error', fail, { once: true });
        this.socket.addEventListener('close', () => {
          clearInterval(this.heartbeatTimer);
          for (const channel of this.channels.values()) { channel.joined = false; channel.joinRef = null; channel.joining = null; channel.resolveJoin = null; channel.rejectJoin = null; }
          this.onStatus('offline');
          if (this.openPromise) fail();
          this.scheduleReconnect();
        });
      });
      return this.openPromise;
    }

    async ensureChannel(topic) {
      topic = this.normalizeTopic(topic);
      let channel = this.channels.get(topic);
      if (!channel) {
        channel = { topic, joined: false, joining: null, joinRef: null, queue: [] };
        this.channels.set(topic, channel);
      }
      await this.connect();
      if (!channel.joined) await this.join(topic);
      return channel;
    }

    join(topic, fromReconnect = false) {
      topic = this.normalizeTopic(topic);
      const channel = this.channels.get(topic) || { topic, joined: false, joining: null, joinRef: null, queue: [] };
      this.channels.set(topic, channel);
      if (channel.joined) return Promise.resolve();
      if (channel.joining && !fromReconnect) return channel.joining;
      if (this.socket?.readyState !== WebSocket.OPEN) return this.connect().then(() => this.join(topic));

      channel.joining = new Promise((resolve, reject) => {
        const ref = String(++this.ref);
        channel.joinRef = ref;
        channel.resolveJoin = resolve;
        channel.rejectJoin = reject;
        const payload = {
          config: {
            broadcast: { ack: false, self: false },
            presence: { enabled: false },
            postgres_changes: [],
            private: false,
          },
        };
        if (this.key.split('.').length === 3) payload.access_token = this.key;
        this.socket.send(JSON.stringify({ topic, event: 'phx_join', payload, ref }));
        setTimeout(() => {
          if (!channel.joined && channel.joinRef === ref) {
            channel.joining = null;
            channel.rejectJoin = null;
            channel.resolveJoin = null;
            reject(new Error('채팅방 연결 시간이 초과되었습니다.'));
          }
        }, 7000);
      });
      return channel.joining;
    }

    handleMessage(raw) {
      let message;
      try { message = JSON.parse(raw); } catch (_) { return; }
      const channel = this.channels.get(message.topic);
      if (message.event === 'phx_reply' && channel && message.ref === channel.joinRef) {
        if (message.payload?.status === 'ok') {
          channel.joined = true;
          channel.joining = null;
          channel.resolveJoin?.();
          channel.resolveJoin = null;
          channel.rejectJoin = null;
          this.flush(channel);
        } else {
          channel.joined = false;
          channel.joining = null;
          channel.rejectJoin?.(new Error('Realtime 채널에 연결할 수 없습니다.'));
          channel.resolveJoin = null;
          channel.rejectJoin = null;
        }
        return;
      }
      if (message.event !== 'broadcast') return;
      const envelope = message.payload || {};
      const event = envelope.event || envelope.payload?.event;
      const payload = envelope.payload?.payload ?? envelope.payload;
      if (!event) return;
      this.onBroadcast(message.topic, event, payload || {});
    }

    async send(topic, event, payload = {}) {
      topic = this.normalizeTopic(topic);
      const channel = await this.ensureChannel(topic);
      const message = {
        topic,
        event: 'broadcast',
        payload: { type: 'broadcast', event, payload },
        ref: null,
      };
      if (!channel.joined || this.socket?.readyState !== WebSocket.OPEN) {
        channel.queue.push(message);
        if (channel.queue.length > 200) channel.queue.shift();
        return false;
      }
      this.socket.send(JSON.stringify(message));
      return true;
    }

    leave(topic) {
      topic = this.normalizeTopic(topic);
      const channel = this.channels.get(topic);
      if (!channel) return;
      if (this.socket?.readyState === WebSocket.OPEN && channel.joined) {
        this.socket.send(JSON.stringify({ topic, event: 'phx_leave', payload: {}, ref: String(++this.ref) }));
      }
      this.channels.delete(topic);
    }

    flush(channel) {
      while (channel.joined && channel.queue.length && this.socket?.readyState === WebSocket.OPEN) {
        this.socket.send(JSON.stringify(channel.queue.shift()));
      }
    }

    heartbeat() {
      if (this.socket?.readyState !== WebSocket.OPEN) return;
      this.socket.send(JSON.stringify({ topic: 'phoenix', event: 'heartbeat', payload: {}, ref: String(++this.ref) }));
    }

    scheduleReconnect() {
      if (this.closed || this.reconnectTimer) return;
      const delay = Math.min(12000, 700 * 2 ** this.reconnectCount++);
      this.reconnectTimer = setTimeout(async () => {
        this.reconnectTimer = null;
        try { await this.connect(); } catch (_) { this.scheduleReconnect(); }
      }, delay);
    }

    close() {
      this.closed = true;
      clearInterval(this.heartbeatTimer);
      clearTimeout(this.reconnectTimer);
      try { this.socket?.close(); } catch (_) {}
      this.channels.clear();
    }

    normalizeTopic(topic) {
      const clean = String(topic || '').replace(/[^a-zA-Z0-9:_-]/g, '').slice(0, 180);
      if (!clean) throw new Error('잘못된 채널입니다.');
      return clean.startsWith('realtime:') ? clean : `realtime:${clean}`;
    }
  }

  root.EntryChatRealtimeHub = EntryChatRealtimeHub;
})(globalThis);
