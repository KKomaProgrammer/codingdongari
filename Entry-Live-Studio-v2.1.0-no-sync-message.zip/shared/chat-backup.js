(function (root) {
  const BACKUP_API_URL = 'https://supabase-settings-fetch.pages.dev/api/backup';
  const SYNC_RECORD_PREFIX = 'entryChatSyncEvidenceV1:';
  const SYNC_META_KEY = 'entryChatSyncEvidenceMetaV1';
  const SYNC_SOFT_LIMIT_BYTES = 88000;
  const SYNC_TARGET_BYTES = 72000;
  const SYNC_MAX_RECORDS = 380;
  const MAX_SYNC_TEXT = 2400;

  const encoder = new TextEncoder();
  const decoder = new TextDecoder();

  function bytesToBase64(bytes) {
    let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
    }
    return btoa(binary);
  }

  function base64ToBytes(value) {
    const binary = atob(String(value || ''));
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  function bytesToHex(bytes) {
    return [...bytes].map((byte) => byte.toString(16).padStart(2, '0')).join('');
  }

  function randomBytes(length) {
    const bytes = new Uint8Array(length);
    crypto.getRandomValues(bytes);
    return bytes;
  }

  function normalizeRecoveryCode(value) {
    return String(value || '').trim().replace(/\s+/g, '').replace(/[^A-Za-z0-9_-]/g, '');
  }

  function generateRecoveryCode() {
    const raw = bytesToBase64(randomBytes(24)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
    return raw.match(/.{1,8}/g).join('-');
  }

  async function sha256Bytes(value) {
    const input = value instanceof Uint8Array ? value : encoder.encode(String(value));
    return new Uint8Array(await crypto.subtle.digest('SHA-256', input));
  }

  async function sha256Hex(value) {
    return bytesToHex(await sha256Bytes(value));
  }

  async function deriveMaterials(recoveryCode) {
    const code = normalizeRecoveryCode(recoveryCode);
    if (code.length < 24 || code.length > 160) throw new Error('복구 코드 형식이 올바르지 않습니다.');
    const backupId = await sha256Hex(`entry-live-studio:backup-id:${code}`);
    const token = await sha256Hex(`entry-live-studio:backup-token:${code}`);
    const keyBytes = await sha256Bytes(`entry-live-studio:backup-key:${code}`);
    const key = await crypto.subtle.importKey('raw', keyBytes, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
    return { code, backupId, token, key };
  }

  async function encryptJson(key, value) {
    const iv = randomBytes(12);
    const plain = encoder.encode(JSON.stringify(value));
    const encrypted = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, plain));
    return { v: 1, iv: bytesToBase64(iv), data: bytesToBase64(encrypted) };
  }

  async function decryptJson(key, envelope) {
    if (!envelope || Number(envelope.v) !== 1 || !envelope.iv || !envelope.data) throw new Error('암호화 백업 형식이 올바르지 않습니다.');
    const iv = base64ToBytes(envelope.iv);
    const encrypted = base64ToBytes(envelope.data);
    const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, encrypted);
    return JSON.parse(decoder.decode(plain));
  }

  async function fetchJson(url, options = {}, timeout = 15000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    let response;
    try {
      response = await fetch(url, { ...options, cache: 'no-store', credentials: 'omit', signal: controller.signal });
    } catch (error) {
      if (error?.name === 'AbortError') throw new Error('백업 서버 응답 시간이 초과되었습니다.');
      throw new Error('백업 서버에 연결할 수 없습니다.');
    } finally {
      clearTimeout(timer);
    }
    let data = null;
    try { data = await response.json(); } catch (_) {}
    if (!response.ok || !data?.ok) throw new Error(data?.error || `백업 서버 오류(HTTP ${response.status})`);
    return data;
  }

  class EntryChatCloudBackupClient {
    constructor(recoveryCode) {
      this.recoveryCode = recoveryCode;
      this.materialsPromise = null;
    }

    materials() {
      if (!this.materialsPromise) this.materialsPromise = deriveMaterials(this.recoveryCode);
      return this.materialsPromise;
    }

    async request(method, body) {
      const materials = await this.materials();
      return fetchJson(BACKUP_API_URL, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'X-Backup-Token': materials.token,
        },
        body: JSON.stringify({ backupId: materials.backupId, ...body }),
      }, method === 'POST' ? 30000 : 18000);
    }

    async saveMeta(meta) {
      const { key } = await this.materials();
      const payload = await encryptJson(key, meta);
      await this.request('PUT', { action: 'meta', payload });
      return true;
    }

    async saveRecord(record) {
      if (!record?.id) throw new Error('백업할 메시지 ID가 없습니다.');
      const { key } = await this.materials();
      const payload = await encryptJson(key, record);
      await this.request('PUT', { action: 'record', recordId: String(record.id), payload });
      return true;
    }

    async readAll() {
      const { key } = await this.materials();
      const response = await this.request('POST', { action: 'read' });
      const meta = await decryptJson(key, response.meta);
      const records = [];
      for (const item of response.records || []) {
        try {
          const record = await decryptJson(key, item.payload);
          if (record?.id) records.push(record);
        } catch (_) {}
      }
      records.sort((a, b) => Number(a.at || 0) - Number(b.at || 0));
      return { meta, records };
    }

    async deleteAll() {
      return this.request('DELETE', {});
    }
  }

  function compactEvidenceRecord(record, imageDigest = '') {
    return {
      scope: record.scope === 'self' ? 'self' : 'room',
      id: String(record.id || ''),
      roomCode: String(record.roomCode || ''),
      from: String(record.from || ''),
      fromName: String(record.fromName || '').slice(0, 80),
      to: record.to ? String(record.to) : null,
      text: String(record.text || '').slice(0, MAX_SYNC_TEXT),
      imageName: String(record.imageName || '').slice(0, 160),
      imageGroupId: String(record.imageGroupId || '').slice(0, 120),
      imageGroupIndex: Number(record.imageGroupIndex || 0),
      imageGroupCount: Number(record.imageGroupCount || 0),
      hasImage: Boolean(record.imageDataUrl),
      imageSha256: imageDigest,
      at: Number(record.at || Date.now()),
      savedAt: Number(record.savedAt || Date.now()),
    };
  }

  class EntryChatSyncEvidenceStore {
    constructor(recoveryCode) {
      this.recoveryCode = recoveryCode;
      this.materialsPromise = null;
      this.queue = Promise.resolve();
      this.pruneScheduled = false;
    }

    materials() {
      if (!this.materialsPromise) this.materialsPromise = deriveMaterials(this.recoveryCode);
      return this.materialsPromise;
    }

    async putRecord(record) {
      this.queue = this.queue.catch(() => {}).then(async () => {
        const { key, backupId } = await this.materials();
        const imageDigest = record?.imageDataUrl ? await sha256Hex(record.imageDataUrl) : '';
        const compact = compactEvidenceRecord(record, imageDigest);
        const payload = await encryptJson(key, compact);
        const storageKey = `${SYNC_RECORD_PREFIX}${compact.id}`;
        const value = { v: 1, at: compact.at, payload };
        const estimated = storageKey.length + JSON.stringify(value).length;
        if (estimated > 7900) throw new Error('동기화 백업 항목이 Chrome 항목 제한을 초과했습니다.');

        try {
          await chrome.storage.sync.set({
            [storageKey]: value,
            [SYNC_META_KEY]: { v: 1, backupId, updatedAt: Date.now() },
          });
        } catch (_) {
          await this.prune(true);
          await chrome.storage.sync.set({
            [storageKey]: value,
            [SYNC_META_KEY]: { v: 1, backupId, updatedAt: Date.now() },
          });
        }
        this.schedulePrune();
        return true;
      });
      return this.queue;
    }

    schedulePrune() {
      if (this.pruneScheduled) return;
      this.pruneScheduled = true;
      setTimeout(() => {
        this.pruneScheduled = false;
        this.prune(false).catch(() => {});
      }, 1500);
    }

    async prune(force = false) {
      const all = await chrome.storage.sync.get(null);
      const entries = Object.entries(all)
        .filter(([storageKey, value]) => storageKey.startsWith(SYNC_RECORD_PREFIX) && value?.payload)
        .sort((a, b) => Number(a[1]?.at || 0) - Number(b[1]?.at || 0));
      const bytes = await chrome.storage.sync.getBytesInUse(null);
      if (!force && bytes <= SYNC_SOFT_LIMIT_BYTES && entries.length <= SYNC_MAX_RECORDS) return 0;

      const remove = [];
      let estimatedBytes = bytes;
      let remaining = entries.length;
      for (const [storageKey, value] of entries) {
        if (remaining <= Math.min(SYNC_MAX_RECORDS, 300) && estimatedBytes <= SYNC_TARGET_BYTES) break;
        remove.push(storageKey);
        estimatedBytes -= storageKey.length + JSON.stringify(value).length;
        remaining -= 1;
      }
      if (remove.length) await chrome.storage.sync.remove(remove);
      return remove.length;
    }

    async loadAllRecords() {
      const { key } = await this.materials();
      const all = await chrome.storage.sync.get(null);
      const records = [];
      for (const [storageKey, value] of Object.entries(all)) {
        if (!storageKey.startsWith(SYNC_RECORD_PREFIX) || !value?.payload) continue;
        try {
          const record = await decryptJson(key, value.payload);
          if (record?.id) records.push(record);
        } catch (_) {}
      }
      records.sort((a, b) => Number(a.at || 0) - Number(b.at || 0));
      return records;
    }

    async count() {
      const all = await chrome.storage.sync.get(null);
      return Object.entries(all).filter(([storageKey, value]) => storageKey.startsWith(SYNC_RECORD_PREFIX) && value?.payload).length;
    }
  }

  root.EntryChatBackup = {
    BACKUP_API_URL,
    generateRecoveryCode,
    normalizeRecoveryCode,
    deriveMaterials,
    EntryChatCloudBackupClient,
    EntryChatSyncEvidenceStore,
  };
})(globalThis);
