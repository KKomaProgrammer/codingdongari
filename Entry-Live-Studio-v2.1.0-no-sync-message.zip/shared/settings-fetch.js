(function (root) {
  const API_BASE = 'https://supabase-settings-fetch.pages.dev/api';
  const API_URL = `${API_BASE}/settings`;
  const STATUS_URL = `${API_BASE}/status`;
  const BACKUP_URL = `${API_BASE}/backup`;

  async function requestJson(url, options = {}, timeout = 12000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    let response;
    try {
      response = await fetch(url, {
        cache: 'no-store',
        credentials: 'omit',
        ...options,
        signal: controller.signal,
      });
    } catch (error) {
      if (error?.name === 'AbortError') throw new Error('설정 서버 응답 시간이 초과되었습니다.');
      throw new Error('설정 서버에 연결할 수 없습니다.');
    } finally {
      clearTimeout(timer);
    }

    let data = null;
    try { data = await response.json(); } catch (_) {}
    if (!response.ok || !data?.ok) {
      const error = new Error(data?.error || `설정 서버 오류(HTTP ${response.status})`);
      error.accessMode = Number(data?.accessMode || 0);
      error.status = data?.status || '';
      throw error;
    }
    return data;
  }

  async function fetchStatus({ timeout = 8000 } = {}) {
    const data = await requestJson(STATUS_URL, { method: 'GET' }, timeout);
    const mode = Number(data.accessMode || 0);
    return {
      accessMode: mode === 1 || mode === 2 ? mode : 0,
      status: mode === 1 ? 'maintenance' : mode === 2 ? 'disabled' : 'normal',
    };
  }

  async function fetchSettings(password, { timeout = 12000 } = {}) {
    if (typeof password !== 'string' || !password.length) throw new Error('연결 비밀번호를 입력하세요.');
    if (password.length > 256) throw new Error('연결 비밀번호가 너무 깁니다.');

    const data = await requestJson(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password }),
    }, timeout);

    const serverUrl = String(data.serverUrl || '').trim().replace(/\/$/, '');
    const anonKey = String(data.anonKey || '').trim();
    if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(serverUrl)) throw new Error('설정 서버의 Supabase URL이 올바르지 않습니다.');
    if (!anonKey || anonKey.startsWith('sb_secret_')) throw new Error('브라우저용 Supabase 키가 아닙니다.');
    return { serverUrl, anonKey, accessMode: 0 };
  }

  root.EntrySettingsFetch = { API_BASE, API_URL, STATUS_URL, BACKUP_URL, fetchStatus, fetchSettings };
})(globalThis);
