(function (root) {
  const DB_NAME = 'junwoo-comprehensive-chat-v1';
  const DB_VERSION = 1;
  const RECORD_STORE = 'records';
  const KV_STORE = 'kv';
  const LOCAL_INDEX_KEY = 'entryChatArchiveIndexV1';
  const LOCAL_RECORD_PREFIX = 'entryChatArchiveRecordV1:';
  const LOCAL_KV_PREFIX = 'entryChatArchiveKvV1:';

  class EntryChatDurableStore {
    constructor() {
      this.dbPromise = null;
      this.queue = Promise.resolve();
      this.index = null;
    }

    openDb() {
      if (this.dbPromise) return this.dbPromise;
      this.dbPromise = new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        request.onupgradeneeded = () => {
          const db = request.result;
          if (!db.objectStoreNames.contains(RECORD_STORE)) db.createObjectStore(RECORD_STORE, { keyPath: 'id' });
          if (!db.objectStoreNames.contains(KV_STORE)) db.createObjectStore(KV_STORE, { keyPath: 'key' });
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error || new Error('채팅 IndexedDB를 열 수 없습니다.'));
      });
      return this.dbPromise;
    }

    async idbPut(storeName, value) {
      const db = await this.openDb();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(storeName, 'readwrite');
        tx.objectStore(storeName).put(value);
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => reject(tx.error || new Error('IndexedDB 저장 실패'));
        tx.onabort = () => reject(tx.error || new Error('IndexedDB 저장 중단'));
      });
    }

    async idbGetAll(storeName) {
      const db = await this.openDb();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(storeName, 'readonly');
        const request = tx.objectStore(storeName).getAll();
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = () => reject(request.error || new Error('IndexedDB 읽기 실패'));
      });
    }

    async ensureIndex() {
      if (this.index) return this.index;
      const local = await chrome.storage.local.get(LOCAL_INDEX_KEY);
      const raw = Array.isArray(local[LOCAL_INDEX_KEY]) ? local[LOCAL_INDEX_KEY] : [];
      this.index = [...new Set(raw.filter((id) => typeof id === 'string' && id))];
      return this.index;
    }

    putRecord(record) {
      const clean = structuredClone(record);
      if (!clean?.id) return Promise.reject(new Error('백업 레코드 ID가 없습니다.'));
      this.queue = this.queue.catch(() => {}).then(async () => {
        const index = await this.ensureIndex();
        if (!index.includes(clean.id)) index.push(clean.id);
        const localKey = `${LOCAL_RECORD_PREFIX}${clean.id}`;
        // 서로 다른 Chrome 저장 계층에 같은 레코드를 각각 보관한다.
        await Promise.all([
          this.idbPut(RECORD_STORE, clean),
          chrome.storage.local.set({ [localKey]: clean, [LOCAL_INDEX_KEY]: index.slice() }),
        ]);
      });
      return this.queue;
    }

    setKv(key, value) {
      const cleanKey = String(key || '');
      const item = { key: cleanKey, value: structuredClone(value), updatedAt: Date.now() };
      this.queue = this.queue.catch(() => {}).then(() => Promise.all([
        this.idbPut(KV_STORE, item),
        chrome.storage.local.set({ [`${LOCAL_KV_PREFIX}${cleanKey}`]: item }),
      ]));
      return this.queue;
    }

    async loadAllRecords() {
      const index = await this.ensureIndex();
      const keys = index.map((id) => `${LOCAL_RECORD_PREFIX}${id}`);
      let localRecords = [];
      for (let offset = 0; offset < keys.length; offset += 200) {
        const chunk = keys.slice(offset, offset + 200);
        const local = await chrome.storage.local.get(chunk);
        localRecords.push(...chunk.map((key) => local[key]).filter((item) => item?.id));
      }
      let idbRecords = [];
      try { idbRecords = await this.idbGetAll(RECORD_STORE); } catch (_) {}
      const merged = new Map();
      for (const item of [...idbRecords, ...localRecords]) {
        if (!item?.id) continue;
        const current = merged.get(item.id);
        if (!current || Number(item.at || item.savedAt || 0) >= Number(current.at || current.savedAt || 0)) merged.set(item.id, item);
      }
      return [...merged.values()].sort((a, b) => Number(a.at || 0) - Number(b.at || 0));
    }

    async getKv(key) {
      const localKey = `${LOCAL_KV_PREFIX}${String(key || '')}`;
      const local = await chrome.storage.local.get(localKey);
      if (local[localKey]) return local[localKey].value;
      try {
        const items = await this.idbGetAll(KV_STORE);
        return items.find((item) => item.key === key)?.value;
      } catch (_) {
        return undefined;
      }
    }

    async exportSnapshot(extra = {}) {
      const records = await this.loadAllRecords();
      return {
        format: 'junwoo-comprehensive-chat-backup',
        version: 1,
        exportedAt: new Date().toISOString(),
        records,
        ...structuredClone(extra),
      };
    }

    async importRecords(records) {
      if (!Array.isArray(records)) throw new Error('백업 records 형식이 올바르지 않습니다.');
      let count = 0;
      for (const record of records) {
        if (!record?.id || !['room', 'self'].includes(record.scope)) continue;
        await this.putRecord(record);
        count += 1;
      }
      return count;
    }
  }

  root.EntryChatDurableStore = EntryChatDurableStore;
})(globalThis);
