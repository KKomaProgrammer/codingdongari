(function () {
  if (globalThis.__ENTRY_LIVE_CHAT__) return;
  globalThis.__ENTRY_LIVE_CHAT__ = true;

  const host = document.createElement('div');
  host.id = 'entry-live-chat-root';
  host.style.cssText = 'all:initial;position:fixed;z-index:2147483646;right:0;bottom:0;width:0;height:0;';
  const root = host.attachShadow({ mode: 'open' });
  (document.documentElement || document.body).appendChild(host);

  const state = {
    data: { authenticated: false, connectionStatus: 'locked', accessMode: 0, termsAccepted: false, identity: { id: '', name: '사용자' }, rooms: [] },
    open: false,
    selectedRoomCode: null,
    selectedUserId: null,
    view: 'rooms',
    unread: new Map(),
    unreadGroups: new Set(),
    drafts: new Map(),
    pendingImages: new Map(),
    preparingImages: new Set(),
    sending: new Set(),
    seq: 0,
    pending: new Map(),
    launcherPosition: null,
    launcherDragging: false,
    launcherMoved: false,
    galleryMap: new Map(),
    lightboxImages: [],
    lightboxIndex: 0,
    lightboxPointerStartX: null,
    shortcutEnabled: true,
    shortcutKey: 'Alt',
    uiHidden: false,
    hideWarningSeen: false,
    modalLocked: false,
  };

  const port = chrome.runtime.connect({ name: 'entry-live-chat' });
  const esc = (value) => String(value ?? '').replace(/[&<>'"]/g, (c) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' })[c]);
  const formatTime = (at) => {
    const date = new Date(Number(at) || Date.now());
    return date.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', hour12: false });
  };
  const convKey = (code, userId) => `${code}:${userId || 'all'}`;
  const extensionIconUrl = chrome.runtime.getURL('assets/chat-ext-48.png');

  root.innerHTML = `<style>
    :host{all:initial}
    *{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}[hidden]{display:none!important}
    .launcher{position:fixed;right:18px;bottom:18px;width:52px;height:52px;z-index:2147483646;border:1px solid #d8dfe9;border-radius:17px;background:#fff;box-shadow:0 13px 36px rgba(25,37,58,.24);display:grid;place-items:center;color:#354052;touch-action:none;cursor:grab;user-select:none;-webkit-user-select:none}.launcher.dragging{cursor:grabbing;transform:none!important;transition:none!important}
    .launcher:hover{transform:translateY(-1px);box-shadow:0 16px 42px rgba(25,37,58,.28)}.launcher svg{width:25px;height:25px;fill:none;stroke:currentColor;stroke-width:2}.badge{position:absolute;right:-6px;top:-6px;min-width:22px;height:22px;padding:0 5px;border-radius:12px;background:#e83f59;color:#fff;border:2px solid #fff;display:grid;place-items:center;font:700 11px system-ui}
    .panel{position:fixed;right:18px;bottom:80px;width:min(460px,calc(100vw - 20px));height:min(640px,calc(100dvh - 96px));max-height:calc(100dvh - 16px);z-index:2147483645;border:1px solid #d8dce3;border-radius:18px;background:#fff;box-shadow:0 22px 70px rgba(20,31,50,.28);overflow:hidden;display:grid;grid-template-rows:58px minmax(0,1fr);font:13px/1.45 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans KR",sans-serif;color:#23262d}
    #panelBody{height:100%;min-height:0;overflow:hidden}
    .top{display:flex;align-items:center;justify-content:space-between;padding:0 12px 0 14px;border-bottom:1px solid #d8dce3;background:#f9dc4b}.brand{display:flex;align-items:center;gap:10px;min-width:0}.brandicon{width:36px;height:36px;display:block;border-radius:10px;box-shadow:0 1px 3px rgba(0,0,0,.12)}.brandcopy{min-width:0}.brandcopy b,.brandcopy small{display:block}.brandcopy b{font-size:15px;color:#2d2d2d}.brandcopy small{margin-top:1px;color:#655d32;font-size:10px}.topright{display:flex;align-items:center;gap:7px}.status{display:flex;align-items:center;gap:5px;padding:5px 8px;border-radius:999px;background:rgba(255,255,255,.54);color:#5e5836;font-size:10px}.dot{width:7px;height:7px;border-radius:50%;background:#a69d69}.dot.online{background:#20a765}.dot.connecting{background:#d58a14}.iconbtn{width:32px;height:32px;border:0;border-radius:10px;background:rgba(255,255,255,.58);color:#4b472d;font-size:18px}.iconbtn:hover{background:rgba(255,255,255,.82)}
    .auth{height:100%;min-height:0;overflow:auto;display:grid;place-items:center;padding:22px;background:#eef1f5}.authcard{width:min(390px,100%);padding:23px;border:1px solid #dfe3e9;border-radius:18px;background:#fff;box-shadow:0 10px 30px rgba(28,42,64,.08)}.authcard h2{margin:0 0 7px;font-size:18px}.authcard p{margin:0 0 16px;color:#747f90;font-size:11px;line-height:1.6}.field{display:grid;gap:6px;margin-bottom:10px}.field label{font-size:11px;font-weight:800;color:#586477}.field input{width:100%;border:1px solid #d7dee9;border-radius:11px;padding:10px 11px;outline:none;color:#253044;background:#fff}.field input:focus{border-color:#d4b920;box-shadow:0 0 0 3px rgba(249,220,75,.22)}.primary{border:0;border-radius:11px;padding:10px 13px;background:#3a3d45;color:#fff;font-weight:800}.primary:disabled{opacity:.55;cursor:default}.autherror{min-height:18px;margin-top:9px;color:#d33f58;font-size:10px}
    .main{height:100%;min-height:0;overflow:hidden;display:grid;grid-template-columns:238px minmax(0,1fr)}.side{height:100%;min-height:0;overflow:hidden;display:grid;grid-template-rows:auto auto minmax(0,1fr);border-right:1px solid #dfe3e8;background:#f2f3f5}.profile{display:flex;align-items:center;gap:9px;padding:11px;border-bottom:1px solid #dde1e7;background:#eceff3}.avatar{width:36px;height:36px;flex:0 0 auto;border-radius:13px;display:grid;place-items:center;background:#d9dde4;color:#4e5663;font-weight:900}.profilecopy{min-width:0;flex:1}.profilecopy b,.profilecopy small{display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.profilecopy b{font-size:12px}.profilecopy small{font-size:9px;color:#7b8492;margin-top:2px}.tinybtn{border:0;border-radius:8px;padding:6px 7px;background:#fff;color:#697486;font-size:10px}.roomactions{display:grid;grid-template-columns:1fr 1fr;gap:6px;padding:9px}.roomactions button{border:1px solid #d5dae2;border-radius:10px;padding:8px 6px;background:#fff;color:#444c59;font-weight:700;font-size:10px}.roomactions button:hover{background:#f9dc4b;border-color:#e2c42d}.tree{min-height:0;overflow:auto;padding:3px 7px 10px}.roomblock{margin-bottom:5px}.roomrow{width:100%;display:flex;align-items:center;gap:8px;border:0;border-radius:12px;padding:9px 8px;background:transparent;text-align:left;color:#465165}.roomrow:hover{background:#fff}.roomrow.active{background:#fff;color:#23262d;box-shadow:0 2px 10px rgba(31,43,66,.07)}.roomicon{width:32px;height:32px;flex:0 0 auto;border-radius:11px;display:grid;place-items:center;background:#dfe3e9;color:#59616e;font-weight:900;font-size:10px}.roomrow.active .roomicon{background:#f9dc4b;color:#37331f}.roomcopy{min-width:0;flex:1}.roomcopy b,.roomcopy small{display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.roomcopy b{font-size:11px}.roomcopy small{margin-top:2px;color:#8a94a3;font-size:9px}.role{display:inline-flex;align-items:center;padding:2px 5px;border-radius:999px;background:#f9dc4b;color:#5f5210;font-size:8px;font-weight:900}.treebadge{min-width:18px;height:18px;padding:0 4px;border-radius:9px;display:grid;place-items:center;background:#e9435c;color:#fff;font-size:9px;font-weight:800}.children{margin:3px 0 5px 20px;padding-left:8px;border-left:1px solid #d7dce4}.child{width:100%;display:flex;align-items:center;gap:7px;border:0;border-radius:10px;padding:7px 8px;background:transparent;text-align:left;color:#667184}.child:hover{background:#fff}.child.active{background:#f9dc4b;color:#403a1d;font-weight:800}.userdot{width:7px;height:7px;border-radius:50%;background:#2bc07c;flex:0 0 auto}.childname{min-width:0;flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;font-size:10px}.selftag{font-size:8px;color:#929aa8}.lockedroom .userdot{background:#b8bec8}
    .conversation{height:100%;min-width:0;min-height:0;overflow:hidden;display:grid;grid-template-rows:58px minmax(0,1fr) auto;background:#b9c8d7}.convhead{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:0 13px;border-bottom:1px solid rgba(0,0,0,.08);background:#f5f6f8}.convtitle{min-width:0}.convtitle b,.convtitle small{display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.convtitle b{font-size:13px}.convtitle small{margin-top:2px;color:#7c8491;font-size:9px}.convtools{display:flex;gap:5px}.convtools button{border:1px solid #d7dce3;border-radius:9px;padding:6px 8px;background:#fff;color:#667184;font-size:9px}.convtools button.danger{color:#c73d55;border-color:#f0cbd2}.messages{min-height:0;overflow:auto;padding:15px 14px 10px;background:#b9c8d7}.empty{height:100%;display:grid;place-items:center;color:#607080;font-size:11px;text-align:center;padding:20px}.msg{max-width:78%;margin:0 0 10px;display:grid;gap:3px}.msg.mine{margin-left:auto}.sender{font-size:9px;color:#596979;padding:0 4px}.msg.mine .sender{text-align:right}.bubble{width:max-content;max-width:100%;padding:9px 11px;border:0;border-radius:13px 13px 13px 4px;background:#fff;color:#273246;white-space:pre-wrap;word-break:break-word;box-shadow:0 1px 1px rgba(0,0,0,.05)}.msg.mine .bubble{margin-left:auto;border-radius:13px 13px 4px 13px;background:#f9dc4b;color:#2d2d2d}.time{padding:0 4px;font-size:8px;color:#647484}.msg.mine .time{text-align:right}.compose{min-height:0;padding:10px;border-top:1px solid #dfe3e8;background:#fff}.composerow{display:grid;grid-template-columns:1fr auto;gap:7px}.composerow input{min-width:0;border:1px solid #d5dae2;border-radius:12px;padding:10px 11px;outline:none;color:#253044;background:#f6f7f9}.composerow input:focus{border-color:#d7bc29;background:#fff}.composerow button{padding-inline:15px;background:#f9dc4b;color:#403a1d}.composerow input:disabled{background:#f3f5f8;color:#999}
    .welcome{height:100%;display:grid;place-items:center;padding:25px;text-align:center;color:#7e8999}.welcome strong{display:block;color:#344054;font-size:15px;margin-bottom:6px}
    .modalback{position:fixed;inset:0;z-index:2147483647;background:rgba(16,23,36,.45);display:grid;place-items:center;padding:14px}.modal{width:min(360px,100%);padding:16px;border-radius:16px;background:#fff;box-shadow:0 20px 60px rgba(15,25,42,.3);font:13px/1.45 system-ui,-apple-system,"Noto Sans KR",sans-serif;color:#243044}.modal h3{margin:0 0 12px;font-size:15px}.modalactions{display:grid;grid-template-columns:1fr 1.3fr;gap:7px;margin-top:11px}.secondary{border:1px solid #dce2eb;border-radius:11px;padding:10px;background:#fff;color:#5e697b}.modalerror{min-height:17px;margin-top:7px;color:#ce3c56;font-size:10px}
    .toast{position:fixed;right:18px;bottom:86px;z-index:2147483647;max-width:min(360px,calc(100vw - 30px));padding:10px 13px;border-radius:11px;background:#283348;color:#fff;box-shadow:0 12px 32px rgba(20,30,48,.26);font:11px/1.4 system-ui,-apple-system,"Noto Sans KR",sans-serif}.toast.error{background:#c94259}
    @media(max-width:680px){.panel{right:8px;bottom:72px;width:calc(100vw - 16px);height:min(620px,calc(100dvh - 84px));max-height:calc(100dvh - 12px)}.launcher{right:12px;bottom:12px}.main{grid-template-columns:190px minmax(0,1fr)}.side{font-size:11px}.convtools button{padding:5px}.msg{max-width:88%}}
    @media(max-width:520px){.main{grid-template-columns:150px minmax(0,1fr)}.profile{padding:8px}.roomactions{grid-template-columns:1fr}.roomrow{padding:7px 5px}.children{margin-left:12px}.panel{bottom:70px;height:calc(100dvh - 82px);max-height:calc(100dvh - 12px)}}

    /* v2.0.6: 단계형 메신저 + 나와의 채팅 + 사진/백업 */
    .main{height:100%;min-height:0;overflow:hidden;display:block;background:#f3f4f6}
    .navview{height:100%;min-height:0;overflow:hidden;display:grid;grid-template-rows:auto minmax(0,1fr);background:#f3f4f6}
    .navhead{min-height:56px;display:flex;align-items:center;gap:9px;padding:8px 12px;border-bottom:1px solid #e0e4ea;background:#fff}
    .backbtn{width:36px;height:36px;flex:0 0 auto;border:0;border-radius:11px;background:#f2f4f7;color:#313846;font-size:20px;display:grid;place-items:center}.backbtn:hover{background:#e8ebf0}
    .navtitle{min-width:0;flex:1}.navtitle b,.navtitle small{display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.navtitle b{font-size:14px}.navtitle small{margin-top:2px;color:#818b99;font-size:9px}
    .navbody{min-height:0;overflow:auto;padding:12px}
    .rooms-home{display:grid;gap:12px}.home-profile{display:flex;align-items:center;gap:10px;padding:13px;border:1px solid #e0e4ea;border-radius:16px;background:#fff}.home-profile .avatar{width:42px;height:42px}.home-profile .profilecopy{flex:1}.home-profile .tinybtn{background:#f3f5f8}
    .home-actions{display:grid;grid-template-columns:1fr 1fr;gap:8px}.home-actions button{border:1px solid #dce1e8;border-radius:13px;padding:11px;background:#fff;color:#3f4857;font-weight:800}.home-actions button:first-child{background:#f9dc4b;border-color:#e3c52f;color:#40391e}
    .room-list{display:grid;gap:8px}.room-card{width:100%;display:flex;align-items:center;gap:11px;padding:12px;border:1px solid #e0e4ea;border-radius:15px;background:#fff;text-align:left;color:#2c3441}.room-card:hover{border-color:#d0d6df;box-shadow:0 3px 12px rgba(30,43,64,.07)}.room-card .roomicon{width:42px;height:42px;border-radius:13px;background:#f9dc4b;color:#3f391e;font-size:11px}.room-card .roomcopy{flex:1}.room-card .roomcopy b{font-size:12px}.room-enter{flex:0 0 auto;color:#8a93a1;font-size:10px}.room-card .treebadge{margin-left:3px}
    .room-detail{display:grid;gap:10px}.room-summary{padding:14px;border:1px solid #e0e4ea;border-radius:16px;background:#fff}.room-summary h3{margin:0 0 4px;font-size:16px}.room-summary p{margin:0;color:#7c8695;font-size:10px}.room-detail-actions{display:flex;gap:7px;margin-top:10px}.room-detail-actions button{border:1px solid #dce1e8;border-radius:9px;padding:7px 9px;background:#fff;color:#626d7e;font-size:9px}.room-detail-actions button.danger{color:#c44358;border-color:#efc9d0}
    .member-list{display:grid;gap:6px}.member-row{width:100%;display:flex;align-items:center;gap:10px;padding:11px;border:1px solid #e2e6ec;border-radius:14px;background:#fff;text-align:left;color:#354052}.member-row:hover{background:#fafbfc}.member-avatar{width:38px;height:38px;flex:0 0 auto;border-radius:13px;display:grid;place-items:center;background:#e4e8ee;color:#566071;font-weight:900}.member-row.all .member-avatar{background:#f9dc4b;color:#413a1d}.member-copy{min-width:0;flex:1}.member-copy b,.member-copy small{display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.member-copy b{font-size:11px}.member-copy small{margin-top:2px;color:#8b94a2;font-size:9px}.member-arrow{color:#a0a7b2}.member-row:disabled{opacity:.55;cursor:default}
    .conversation-view{height:100%;min-height:0;display:grid;grid-template-rows:56px minmax(0,1fr) auto;background:#b9c8d7}.conversation-view .navhead{background:#f5f6f8}.conversation-view .messages{min-height:0}.conversation-view .compose{min-height:0}
    .empty-rooms{padding:38px 12px;text-align:center;color:#818b99;font-size:11px;background:#fff;border:1px dashed #d6dce5;border-radius:15px}
    @media(max-width:680px){.panel{width:min(460px,calc(100vw - 16px))}.navbody{padding:10px}.home-actions{grid-template-columns:1fr 1fr}}
    .avatar,.member-avatar{overflow:hidden}.avatar img,.member-avatar img{width:100%;height:100%;object-fit:cover;display:block}.profile-actions{display:flex;gap:5px;flex-wrap:wrap}.self-chat-card{width:100%;display:flex;align-items:center;gap:11px;padding:12px;border:1px solid #e0e4ea;border-radius:15px;background:#fff;text-align:left;color:#2c3441}.self-chat-card:hover{box-shadow:0 3px 12px rgba(30,43,64,.07)}.self-chat-card .member-avatar{width:42px;height:42px}.backup-actions{display:grid;grid-template-columns:1fr 1fr;gap:7px}.backup-actions button{border:1px solid #dbe1e8;border-radius:10px;padding:9px;background:#fff;color:#566173;font-weight:700;font-size:10px}.backup-actions button:hover{background:#f8f9fb}.photo-btn{width:40px;padding:0!important;font-size:18px!important}.image-preview{display:flex;align-items:center;gap:8px;margin:0 0 8px;padding:7px;border-radius:10px;background:#f2f4f7}.image-preview img{width:48px;height:48px;object-fit:cover;border-radius:8px}.image-preview span{min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:9px;color:#6c7685}.image-preview button{border:0;background:#fff;border-radius:8px;padding:5px 7px;color:#8b5260}.chat-image{display:block;max-width:220px;max-height:260px;width:auto;height:auto;border-radius:10px;cursor:zoom-in;background:#eef1f4}.bubble.has-image{padding:6px}.bubble.has-image .msg-text{padding:6px 5px 4px}.msg-text:empty{display:none}.lightbox{position:fixed;inset:0;z-index:2147483647;background:rgba(10,15,24,.72);display:grid;place-items:center;padding:24px}.lightbox img{max-width:min(92vw,1100px);max-height:88vh;border-radius:12px;box-shadow:0 20px 80px rgba(0,0,0,.45)}.lightbox button{position:fixed;right:18px;top:18px;width:40px;height:40px;border:0;border-radius:12px;background:#fff;color:#222;font-size:22px}.profile-photo-preview{display:flex;align-items:center;gap:12px;margin:6px 0 12px}.profile-photo-preview .avatar{width:64px;height:64px;border-radius:20px}.recovery-note{font-size:9px;line-height:1.55;color:#7b8594;margin:8px 0 0}.composerow{grid-template-columns:auto minmax(0,1fr) auto}

    /* v2.1.0: 상태 제한, 이용 안내, 참가자 콜라주, 다중 이미지 */
    .access-screen,.terms-screen{height:100%;min-height:0;overflow:auto;display:grid;place-items:center;padding:22px;background:#eef1f5}.access-card,.terms-card{width:min(400px,100%);padding:22px;border:1px solid #dfe4eb;border-radius:19px;background:#fff;box-shadow:0 12px 34px rgba(28,42,64,.09)}.access-symbol{width:50px;height:50px;border-radius:16px;display:grid;place-items:center;margin-bottom:13px;background:#f2f4f7;font-size:24px}.access-card h2,.terms-card h2{margin:0 0 8px;font-size:18px}.access-card p,.terms-card p{margin:0;color:#707b8b;font-size:11px;line-height:1.65}.terms-box{margin:14px 0;padding:13px;border:1px solid #e1e5eb;border-radius:13px;background:#f7f8fa;color:#4d5767;font-size:10px;line-height:1.7}.terms-note{margin-top:10px!important;font-size:9px!important;color:#8a93a0!important}.terms-card .primary{width:100%;margin-top:14px}
    .section-label{display:flex;align-items:center;justify-content:space-between;margin:1px 2px -3px;color:#7a8492;font-size:9px;font-weight:800}.home-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:7px}.home-stat{padding:9px;border:1px solid #e1e5eb;border-radius:12px;background:#fff;text-align:center}.home-stat b{display:block;font-size:13px;color:#333b48}.home-stat small{display:block;margin-top:2px;font-size:8px;color:#8a94a2}.backup-hint{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 11px;border:1px solid #e0e5eb;border-radius:13px;background:#fff}.backup-hint span{min-width:0}.backup-hint b,.backup-hint small{display:block}.backup-hint b{font-size:10px}.backup-hint small{margin-top:2px;color:#87919f;font-size:8px}.backup-hint button{flex:0 0 auto}
    .group-avatar{position:relative;width:38px;height:38px;flex:0 0 auto;border-radius:13px;overflow:hidden;background:#e7eaf0;border:1px solid #dde2e9}.group-avatar .ga{position:absolute;display:grid;place-items:center;overflow:hidden;background:#e4e8ee;color:#596373;font-size:8px;font-weight:900;border:1px solid #fff}.group-avatar .ga img{width:100%;height:100%;object-fit:cover;display:block}.group-avatar.n1 .ga:nth-child(1){inset:0;border:0}.group-avatar.n2 .ga:nth-child(1){left:0;top:0;width:58%;height:58%;border-radius:12px 0 9px 0}.group-avatar.n2 .ga:nth-child(2){right:0;bottom:0;width:58%;height:58%;border-radius:9px 0 12px 0}.group-avatar.n3 .ga:nth-child(1){left:25%;top:0;width:50%;height:52%;border-radius:0 0 8px 8px}.group-avatar.n3 .ga:nth-child(2){right:0;bottom:0;width:52%;height:52%;border-radius:8px 0 12px 0}.group-avatar.n3 .ga:nth-child(3){left:0;bottom:0;width:52%;height:52%;border-radius:0 8px 0 12px}.group-avatar.n4 .ga:nth-child(1),.group-avatar.nmore .ga:nth-child(1){left:0;top:0;width:50%;height:50%}.group-avatar.n4 .ga:nth-child(2),.group-avatar.nmore .ga:nth-child(2){right:0;top:0;width:50%;height:50%}.group-avatar.n4 .ga:nth-child(3),.group-avatar.nmore .ga:nth-child(3){left:0;bottom:0;width:50%;height:50%}.group-avatar.n4 .ga:nth-child(4),.group-avatar.nmore .ga:nth-child(4){right:0;bottom:0;width:50%;height:50%}.group-avatar .more{position:absolute;right:-1px;top:-1px;z-index:5;min-width:18px;height:16px;padding:0 4px;border-radius:8px;background:#313846;color:#fff;border:1px solid #fff;display:grid;place-items:center;font-size:7px;font-weight:900}
    .image-preview{display:block}.image-preview-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:6px}.image-preview-head span{font-size:9px;font-weight:800;color:#667181}.image-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px}.image-thumb{position:relative;min-width:0}.image-thumb img{width:100%;aspect-ratio:1/1;height:auto;object-fit:cover;border-radius:8px;display:block}.image-thumb button{position:absolute;right:3px;top:3px;width:20px;height:20px;padding:0;border-radius:10px;background:rgba(255,255,255,.92);color:#8b5260;font-size:12px;display:grid;place-items:center}.image-thumb small{display:block;margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#7f8997;font-size:7px}.image-upload-status{display:flex;align-items:center;gap:7px;margin:0 0 8px;padding:8px 10px;border-radius:10px;background:#f1f4f7;color:#5f6a79;font-size:9px;font-weight:800}.image-upload-status i{width:12px;height:12px;border:2px solid #c5ccd6;border-top-color:#596474;border-radius:50%;animation:elsSpin .8s linear infinite}@keyframes elsSpin{to{transform:rotate(360deg)}}

    /* v2.1.0: 묶음 사진, 발신자 프로필, 페이지별 숨김/복구 */
    .msg{max-width:86%;display:flex;align-items:flex-end;gap:7px}.msg.mine{margin-left:auto;flex-direction:row-reverse}.msg-stack{min-width:0;display:grid;gap:3px}.msg.mine .msg-stack{justify-items:end}.msg-avatar{width:30px;height:30px;flex:0 0 auto;border-radius:11px;display:grid;place-items:center;overflow:hidden;background:#e2e6ec;color:#5d6674;font-size:9px;font-weight:900;box-shadow:0 1px 2px rgba(0,0,0,.08)}.msg-avatar img{width:100%;height:100%;display:block;object-fit:cover}.sender{padding:0 3px;color:#7e8794;font-size:9px}.msg.mine .sender{text-align:right}.msg .bubble{max-width:min(270px,68vw)}.bubble.has-image{padding:5px;overflow:hidden}.bubble.has-image .msg-text{padding:7px 6px 4px}.chat-gallery{position:relative;overflow:hidden;border-radius:10px}.chat-gallery.single{display:block}.chat-gallery.single .gallery-tile img{display:block;max-width:220px;max-height:260px;width:auto;height:auto;object-fit:contain;border-radius:10px;background:#eef1f4}.chat-gallery.multi{width:min(246px,64vw);display:grid;gap:2px;background:rgba(255,255,255,.35)}.chat-gallery.multi.g2,.chat-gallery.multi.g3,.chat-gallery.multi.g4{grid-template-columns:repeat(2,1fr)}.chat-gallery.multi.g5,.chat-gallery.multi.g6,.chat-gallery.multi.g7,.chat-gallery.multi.g8,.chat-gallery.multi.g9{grid-template-columns:repeat(3,1fr)}.gallery-tile{position:relative;min-width:0;overflow:hidden;background:#e7ebf0}.chat-gallery.multi .gallery-tile img{display:block;width:100%;aspect-ratio:1/1;object-fit:cover;cursor:zoom-in}.chat-gallery.multi.g3 .gallery-tile:first-child{grid-row:span 2}.chat-gallery.multi.g3 .gallery-tile:first-child img{height:100%;aspect-ratio:auto}.gallery-more{position:absolute;inset:0;display:grid;place-items:center;background:rgba(17,24,39,.48);color:#fff;font-size:16px;font-weight:900;pointer-events:none}.lightbox{touch-action:pan-y}.lightbox img{user-select:none;-webkit-user-drag:none}.lightbox .lbnav{position:fixed;top:50%;transform:translateY(-50%);width:46px;height:58px;border-radius:16px;background:rgba(255,255,255,.9);font-size:30px;display:grid;place-items:center}.lightbox .lbprev{left:18px}.lightbox .lbnext{right:18px}.lightbox .lbcounter{position:fixed;left:50%;bottom:18px;transform:translateX(-50%);padding:7px 11px;border-radius:999px;background:rgba(17,24,39,.68);color:#fff;font:700 11px system-ui}.shortcut-card{margin-top:2px;padding:12px;border:1px solid #e0e5eb;border-radius:14px;background:#fff}.shortcut-main{display:flex;align-items:center;gap:10px}.shortcut-copy{min-width:0;flex:1}.shortcut-copy b,.shortcut-copy small{display:block}.shortcut-copy b{font-size:10px;color:#394353}.shortcut-copy small{margin-top:3px;color:#8993a0;font-size:8px;line-height:1.45}.shortcut-select{border:1px solid #d8dee7;border-radius:9px;padding:6px 7px;background:#f7f8fa;color:#556071;font-size:9px;outline:none}.switch{position:relative;width:38px;height:22px;flex:0 0 auto}.switch input{position:absolute;opacity:0;pointer-events:none}.switch-track{position:absolute;inset:0;border-radius:999px;background:#cbd2dc;transition:.18s}.switch-track:after{content:'';position:absolute;width:16px;height:16px;left:3px;top:3px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.18);transition:.18s}.switch input:checked+.switch-track{background:#3f4652}.switch input:checked+.switch-track:after{transform:translateX(16px)}.drop-trash{position:fixed;left:50%;bottom:24px;z-index:2147483647;transform:translateX(-50%);display:grid;justify-items:center;gap:7px;pointer-events:none;opacity:.92;transition:.16s}.drop-glass{width:76px;height:76px;border-radius:50%;display:grid;place-items:center;border:1px solid rgba(255,255,255,.72);background:rgba(236,241,248,.48);backdrop-filter:blur(18px) saturate(145%);-webkit-backdrop-filter:blur(18px) saturate(145%);box-shadow:0 14px 42px rgba(25,35,50,.22),inset 0 1px 0 rgba(255,255,255,.8);transition:.14s}.drop-glass span{width:42px;height:42px;border:2px solid rgba(78,88,104,.78);border-radius:50%;display:grid;place-items:center;color:#596374;font:300 30px/1 system-ui}.drop-trash small{padding:5px 9px;border-radius:999px;background:rgba(27,34,45,.68);color:#fff;font:700 9px system-ui}.drop-trash.over .drop-glass{transform:scale(1.1);background:rgba(255,228,232,.7);box-shadow:0 16px 48px rgba(98,35,50,.28)}.drop-trash.over .drop-glass span{color:#c94059;border-color:#c94059}.modal-lock-note{margin-top:10px;padding:9px 10px;border-radius:10px;background:#f5f6f8;color:#717b89;font-size:9px;line-height:1.55}.modalactions .countdown{opacity:.56}
  </style>
  <button class="launcher" id="launcher" aria-label="채팅 열기">
    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 5.5h14v10H9l-4 3v-13Z"></path><path d="M8 9h8M8 12h5"></path></svg>
    <span class="badge" id="launcherBadge" hidden>0</span>
  </button>
  <section class="panel" id="panel" hidden>
    <header class="top"><div class="brand"><img class="brandicon" src="${extensionIconUrl}" alt=""><span class="brandcopy"><b>채팅창</b><small>종합 메신저</small></span></div><div class="topright"><span class="status"><i class="dot" id="statusDot"></i><span id="statusText">연결 필요</span></span><button class="iconbtn" id="closePanel" aria-label="닫기">×</button></div></header>
    <div id="panelBody"></div>
  </section>
  <div class="modalback" id="modalBack" hidden><section class="modal"><h3 id="modalTitle"></h3><div id="modalContent"></div><div class="modalerror" id="modalError"></div><div class="modalactions"><button class="secondary" id="modalCancel">취소</button><button class="primary" id="modalConfirm">확인</button></div></section></div>
  <div class="toast" id="toast" hidden></div>
  <div class="drop-trash" id="dropTrash" hidden><div class="drop-glass"><span>×</span></div><small>여기에 놓아 이 페이지에서 숨기기</small></div>
  <div class="lightbox" id="imageLightbox" hidden><button id="lightboxClose" aria-label="닫기">×</button><button class="lbnav lbprev" id="lightboxPrev" aria-label="이전 사진">‹</button><img id="lightboxImage" alt="채팅 사진 크게 보기"><button class="lbnav lbnext" id="lightboxNext" aria-label="다음 사진">›</button><div class="lbcounter" id="lightboxCounter"></div></div>`;

  const $ = (id) => root.getElementById(id);
  const panel = $('panel');
  const panelBody = $('panelBody');
  let toastTimer = null;
  let modalAction = null;
  let originalBackupQueue = Promise.resolve();
  const SHORTCUT_SETTINGS_KEY = 'entryChatPageShortcutV1';
  const HIDE_WARNING_KEY = 'entryChatHideWarningSeenV1';
  const SHORTCUT_KEYS = ['Alt','Control','Shift','Meta','F2','F4','F8','F10','Escape'];

  function call(command, payload = {}, timeout = 16000) {
    const requestId = `c-${Date.now()}-${++state.seq}`;
    return new Promise((resolve, reject) => {
      state.pending.set(requestId, { resolve, reject });
      port.postMessage({ type: 'CHAT_COMMAND', requestId, command, payload });
      setTimeout(() => {
        const item = state.pending.get(requestId);
        if (!item) return;
        state.pending.delete(requestId);
        reject(new Error('응답 시간이 초과되었습니다.'));
      }, timeout);
    });
  }

  port.onMessage.addListener((message) => {
    if (message.type === 'CHAT_RESPONSE') {
      const pending = state.pending.get(message.requestId);
      if (!pending) return;
      state.pending.delete(message.requestId);
      if (message.ok) pending.resolve(message.result); else pending.reject(new Error(message.error || '동작 실패'));
      return;
    }
    if (message.type === 'CHAT_STATE') {
      const prevKey = selectedKey();
      const focusSnapshot = captureComposerFocus();
      if ($('messageInput')) saveCurrentDraft();
      state.data = message.state || state.data;
      ensureSelection();
      renderState(prevKey, focusSnapshot);
      return;
    }
    if (message.type === 'CHAT_EVENT' && message.event?.type === 'message') handleIncoming(message.event.message);
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === 'ENTRY_CHAT_TOGGLE') togglePanel(!state.open);
  });

  installLauncherDrag();
  installPageShortcut();
  loadLauncherPosition();
  loadShortcutSettings();

  $('closePanel').addEventListener('click', () => togglePanel(false));
  $('modalCancel').addEventListener('click', () => closeModal());
  $('modalBack').addEventListener('click', (event) => { if (event.target === $('modalBack')) closeModal(); });
  $('lightboxClose').addEventListener('click', () => closeImageLightbox());
  $('lightboxPrev').addEventListener('click', (event) => { event.stopPropagation(); stepLightbox(-1); });
  $('lightboxNext').addEventListener('click', (event) => { event.stopPropagation(); stepLightbox(1); });
  $('imageLightbox').addEventListener('click', (event) => { if (event.target === $('imageLightbox')) closeImageLightbox(); });
  $('imageLightbox').addEventListener('pointerdown', (event) => { state.lightboxPointerStartX = event.clientX; });
  $('imageLightbox').addEventListener('pointerup', (event) => {
    if (state.lightboxPointerStartX == null) return;
    const dx = event.clientX - state.lightboxPointerStartX;
    state.lightboxPointerStartX = null;
    if (Math.abs(dx) >= 45) stepLightbox(dx < 0 ? 1 : -1);
  });
  document.addEventListener('pointerdown', (event) => {
    if (!state.open || !$('modalBack').hidden) return;
    const path = typeof event.composedPath === 'function' ? event.composedPath() : [];
    if (path.includes(panel) || path.includes($('launcher')) || path.includes($('imageLightbox'))) return;
    togglePanel(false);
  }, true);

  document.addEventListener('keydown', (event) => {
    if (!$('imageLightbox').hidden) {
      if (event.key === 'ArrowLeft') { event.preventDefault(); stepLightbox(-1); }
      if (event.key === 'ArrowRight') { event.preventDefault(); stepLightbox(1); }
      if (event.key === 'Escape') { event.preventDefault(); closeImageLightbox(); }
    }
  }, true);

  $('modalConfirm').addEventListener('click', async () => {
    if (!modalAction) return;
    const button = $('modalConfirm');
    button.disabled = true;
    $('modalError').textContent = '';
    try {
      await modalAction();
      state.modalLocked = false;
      closeModal(true);
    } catch (error) { $('modalError').textContent = error?.message || String(error); }
    finally { if (!state.modalLocked) button.disabled = false; }
  });


  function shortcutLabel(key = state.shortcutKey) {
    return ({ Alt:'Alt', Control:'Ctrl', Shift:'Shift', Meta:'Meta', Escape:'Esc' })[key] || key;
  }

  function validShortcutKey(key) {
    return SHORTCUT_KEYS.includes(key) ? key : 'Alt';
  }

  async function loadShortcutSettings() {
    try {
      const stored = await chrome.storage.local.get([SHORTCUT_SETTINGS_KEY, HIDE_WARNING_KEY]);
      const config = stored?.[SHORTCUT_SETTINGS_KEY] || {};
      state.shortcutEnabled = config.enabled !== false;
      state.shortcutKey = validShortcutKey(config.key || 'Alt');
      state.hideWarningSeen = Boolean(stored?.[HIDE_WARNING_KEY]);
      if ($('mainView') && state.view === 'rooms') patchMainView();
    } catch (_) {}
  }

  async function saveShortcutSettings() {
    try {
      await chrome.storage.local.set({ [SHORTCUT_SETTINGS_KEY]: { enabled: Boolean(state.shortcutEnabled), key: validShortcutKey(state.shortcutKey) } });
    } catch (_) {}
  }

  function setCurrentPageHidden(hidden) {
    state.uiHidden = Boolean(hidden);
    $('launcher').hidden = state.uiHidden;
    $('dropTrash').hidden = true;
    panel.hidden = state.uiHidden || !state.open;
    if (!state.uiHidden && state.open) renderState(selectedKey());
  }

  function installPageShortcut() {
    let lastKey = '';
    let lastAt = 0;
    document.addEventListener('keydown', (event) => {
      if (!state.shortcutEnabled || event.repeat) return;
      const key = validShortcutKey(state.shortcutKey);
      if (event.key !== key) return;
      event.preventDefault();
      event.stopPropagation();
      const currentAt = performance.now();
      if (lastKey === key && currentAt - lastAt <= 520) {
        lastKey = '';
        lastAt = 0;
        event.preventDefault();
        event.stopPropagation();
        setCurrentPageHidden(!state.uiHidden);
      } else {
        lastKey = key;
        lastAt = currentAt;
      }
    }, true);
  }

  async function ensureShortcutRecoveryEnabled() {
    state.shortcutKey = validShortcutKey(state.shortcutKey);
    if (!state.shortcutEnabled) state.shortcutEnabled = true;
    await saveShortcutSettings();
    if ($('mainView') && state.view === 'rooms') patchMainView();
  }

  async function requestHideCurrentPageFromDrag() {
    await ensureShortcutRecoveryEnabled();
    if (state.hideWarningSeen) {
      setCurrentPageHidden(true);
      return;
    }
    const label = shortcutLabel();
    showModal('이 페이지에서 채팅 숨기기', `<p style="margin:0;color:#596474;line-height:1.65"><b>아이콘과 채팅창을 이 페이지에서 숨깁니다.</b><br>다시 표시하려면 <b>${esc(label)} 키를 빠르게 두 번</b> 누르세요.</p><div class="modal-lock-note">숨김 상태는 이 페이지에만 적용되어 다른 페이지에서는 다시 표시됩니다. 복구 단축키를 잊으면 이 페이지에서는 새로고침하기 전까지 다시 표시하기 어렵습니다.<br><br><b>안전을 위해 단축키 기능은 자동으로 ON 상태로 복구되었습니다.</b></div>`, async () => {
      state.hideWarningSeen = true;
      await chrome.storage.local.set({ [HIDE_WARNING_KEY]: true }).catch(() => {});
      setCurrentPageHidden(true);
    });
    state.modalLocked = true;
    $('modalCancel').hidden = true;
    const confirm = $('modalConfirm');
    confirm.disabled = true;
    confirm.classList.add('countdown');
    let remain = 3;
    confirm.textContent = `확인 (${remain})`;
    const timer = setInterval(() => {
      remain -= 1;
      if (remain > 0) { confirm.textContent = `확인 (${remain})`; return; }
      clearInterval(timer);
      confirm.textContent = '확인';
      confirm.classList.remove('countdown');
      confirm.disabled = false;
    }, 1000);
  }

  const LAUNCHER_POSITION_KEY = 'entryChatLauncherPosition';

  function clampLauncherPosition(position) {
    const launcher = $('launcher');
    const width = launcher?.offsetWidth || 52;
    const height = launcher?.offsetHeight || 52;
    const maxX = Math.max(0, innerWidth - width);
    const maxY = Math.max(0, innerHeight - height);
    const x = Math.max(0, Math.min(maxX, Number(position?.x) || 0));
    const y = Math.max(0, Math.min(maxY, Number(position?.y) || 0));
    return { x, y };
  }

  function applyLauncherPosition(position) {
    if (!position) return;
    const launcher = $('launcher');
    if (!launcher) return;
    const next = clampLauncherPosition(position);
    state.launcherPosition = next;
    launcher.style.left = `${next.x}px`;
    launcher.style.top = `${next.y}px`;
    launcher.style.right = 'auto';
    launcher.style.bottom = 'auto';
  }

  async function loadLauncherPosition() {
    try {
      const stored = await chrome.storage.local.get(LAUNCHER_POSITION_KEY);
      if (stored?.[LAUNCHER_POSITION_KEY]) applyLauncherPosition(stored[LAUNCHER_POSITION_KEY]);
    } catch (_) {}
  }

  async function saveLauncherPosition(position) {
    const next = clampLauncherPosition(position);
    applyLauncherPosition(next);
    try {
      await chrome.storage.local.set({ [LAUNCHER_POSITION_KEY]: next });
    } catch (_) {}
  }

  function installLauncherDrag() {
    const launcher = $('launcher');
    if (!launcher) return;
    let drag = null;

    launcher.addEventListener('pointerdown', (event) => {
      if (event.button !== undefined && event.button !== 0) return;
      const rect = launcher.getBoundingClientRect();
      drag = {
        pointerId: event.pointerId,
        offsetX: event.clientX - rect.left,
        offsetY: event.clientY - rect.top,
        startX: event.clientX,
        startY: event.clientY,
        originPosition: { x: rect.left, y: rect.top },
      };
      state.launcherDragging = true;
      state.launcherMoved = false;
      launcher.classList.add('dragging');
      try { launcher.setPointerCapture(event.pointerId); } catch (_) {}
      event.preventDefault();
    });

    launcher.addEventListener('pointermove', (event) => {
      if (!drag || event.pointerId !== drag.pointerId) return;
      if (!state.launcherMoved && Math.hypot(event.clientX - drag.startX, event.clientY - drag.startY) >= 4) {
        state.launcherMoved = true;
      }
      if (!state.launcherMoved) return;
      applyLauncherPosition({ x: event.clientX - drag.offsetX, y: event.clientY - drag.offsetY });
      const trash = $('dropTrash');
      trash.hidden = false;
      const trashRect = trash.getBoundingClientRect();
      const overTrash = event.clientX >= trashRect.left && event.clientX <= trashRect.right && event.clientY >= trashRect.top && event.clientY <= trashRect.bottom;
      trash.classList.toggle('over', overTrash);
      event.preventDefault();
    });

    const finishDrag = async (event, cancelled = false) => {
      if (!drag || (event?.pointerId !== undefined && event.pointerId !== drag.pointerId)) return;
      const moved = state.launcherMoved;
      const originPosition = drag.originPosition;
      try { launcher.releasePointerCapture(drag.pointerId); } catch (_) {}
      drag = null;
      state.launcherDragging = false;
      launcher.classList.remove('dragging');

      const trash = $('dropTrash');
      const trashRect = trash.getBoundingClientRect();
      const overTrash = moved && !cancelled && event && event.clientX >= trashRect.left && event.clientX <= trashRect.right && event.clientY >= trashRect.top && event.clientY <= trashRect.bottom;
      trash.hidden = true;
      trash.classList.remove('over');
      if (overTrash) {
        applyLauncherPosition(originPosition || state.launcherPosition);
        await requestHideCurrentPageFromDrag();
      } else if (moved && !cancelled) {
        const rect = launcher.getBoundingClientRect();
        await saveLauncherPosition({ x: rect.left, y: rect.top });
      } else if (!moved && !cancelled) {
        togglePanel(!state.open);
      }
      queueMicrotask(() => { state.launcherMoved = false; });
    };

    launcher.addEventListener('pointerup', (event) => finishDrag(event, false));
    launcher.addEventListener('pointercancel', (event) => finishDrag(event, true));
    launcher.addEventListener('lostpointercapture', (event) => {
      if (drag) finishDrag(event, false);
    });

    // 브라우저 창 크기가 바뀌어 저장 위치가 화면 밖으로 나가면 현재 화면 안으로만 보정한다.
    addEventListener('resize', () => {
      if (!state.launcherPosition || state.launcherDragging) return;
      applyLauncherPosition(state.launcherPosition);
    }, { passive: true });
  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local') return;
    const changed = changes[LAUNCHER_POSITION_KEY];
    if (changed?.newValue && !state.launcherDragging) {
      // 다른 페이지에서 마우스를 놓아 위치가 저장되는 즉시 이 페이지에도 반영한다.
      applyLauncherPosition(changed.newValue);
    }
    if (changes[SHORTCUT_SETTINGS_KEY]?.newValue && !state.uiHidden) {
      // 현재 페이지가 숨겨진 동안에는 다른 페이지의 설정 변경으로 복구 단축키가 꺼지거나 바뀌지 않게 고정한다.
      const config = changes[SHORTCUT_SETTINGS_KEY].newValue || {};
      state.shortcutEnabled = config.enabled !== false;
      state.shortcutKey = validShortcutKey(config.key || 'Alt');
      if ($('mainView') && state.view === 'rooms') patchMainView();
    }
  });

  function togglePanel(open) {
    state.open = Boolean(open);
    panel.hidden = state.uiHidden || !state.open;
    if (state.open) {
      const key = state.view === 'conversation' ? selectedKey() : null;
      if (key) clearUnread(key);
      renderState(key);
    }
  }

  function selectedRoom() {
    return state.data.rooms?.find((room) => room.code === state.selectedRoomCode) || null;
  }

  function selectedKey() {
    if (state.view === 'selfConversation') return 'self:me';
    return state.selectedRoomCode ? convKey(state.selectedRoomCode, state.selectedUserId) : null;
  }

  function ensureSelection() {
    const rooms = state.data.rooms || [];
    const room = rooms.find((item) => item.code === state.selectedRoomCode) || null;
    if (!room) {
      state.selectedRoomCode = null;
      state.selectedUserId = null;
      if (state.view !== 'rooms' && state.view !== 'selfConversation') state.view = 'rooms';
      return;
    }
    if (state.selectedUserId) {
      const valid = room.users?.some((user) => user.id === state.selectedUserId && !user.self);
      if (!valid) {
        state.selectedUserId = null;
        if (state.view === 'conversation') state.view = 'room';
      }
    }
  }

  function captureComposerFocus() {
    const input = $('messageInput');
    if (!input || root.activeElement !== input) return null;
    return {
      key: selectedKey(),
      start: Number.isInteger(input.selectionStart) ? input.selectionStart : input.value.length,
      end: Number.isInteger(input.selectionEnd) ? input.selectionEnd : input.value.length,
      direction: input.selectionDirection || 'none',
    };
  }

  function restoreComposerFocus(snapshot = null, force = false) {
    if (!state.open || !['conversation', 'selfConversation'].includes(state.view)) return;
    if (!force && (!snapshot || snapshot.key !== selectedKey())) return;
    queueMicrotask(() => {
      const input = $('messageInput');
      if (!input || input.disabled || !state.open) return;
      try { input.focus({ preventScroll: true }); } catch (_) { try { input.focus(); } catch (_) {} }
      const fallback = input.value.length;
      const start = force ? fallback : Math.max(0, Math.min(fallback, Number(snapshot?.start ?? fallback)));
      const end = force ? fallback : Math.max(start, Math.min(fallback, Number(snapshot?.end ?? start)));
      try { input.setSelectionRange(start, end, force ? 'none' : (snapshot?.direction || 'none')); } catch (_) {}
    });
  }

  function renderState(previousKey = null, focusSnapshot = undefined) {
    const snapshot = focusSnapshot === undefined ? captureComposerFocus() : focusSnapshot;
    if ($('messageInput')) saveCurrentDraft();
    patchStatus();
    patchBadge();
    if (Number(state.data.accessMode) === 1 || Number(state.data.accessMode) === 2) {
      renderAccessBlocked();
      return;
    }
    if (!state.data.termsAccepted) {
      renderTerms();
      return;
    }
    if (!state.data.authenticated) {
      renderAuth();
      return;
    }
    if (!$('chatMain')) renderMainShell();
    patchMainView(previousKey);
    restoreComposerFocus(snapshot);
  }

  function patchStatus() {
    const status = state.data.connectionStatus || 'locked';
    const map = { online:'연결됨', connecting:'연결 중', reconnecting:'재연결 중', offline:'오프라인', locked:'연결 필요', maintenance:'점검중', disabled:'사용 불가' };
    $('statusText').textContent = map[status] || status;
    $('statusDot').className = `dot ${status === 'online' ? 'online' : ['connecting','reconnecting'].includes(status) ? 'connecting' : ''}`;
  }

  function renderAccessBlocked() {
    const maintenance = Number(state.data.accessMode) === 1;
    panelBody.innerHTML = `<div class="access-screen"><section class="access-card"><div class="access-symbol">${maintenance ? '🛠️' : '⛔'}</div><h2>${maintenance ? '점검중' : '사용 불가'}</h2><p>${maintenance ? '현재 확장 프로그램을 점검하고 있습니다. 점검이 끝나면 자동으로 다시 사용할 수 있습니다.' : '현재 이 확장 프로그램의 사용이 제한되어 있습니다. 상태가 정상으로 변경되면 자동으로 다시 확인합니다.'}</p></section></div>`;
  }

  function renderTerms() {
    if ($('termsAccept')) return;
    panelBody.innerHTML = `<div class="terms-screen"><section class="terms-card"><h2>이용 전 확인</h2><p>채팅 기능을 사용하기 전에 아래 내용을 확인해 주세요.</p><div class="terms-box">이 메신저가 정상적인 소통 목적이 아닌 학교폭력 등 부적절한 목적 또는 방식으로 사용되는 경우, 그 행위와 그로 인한 책임은 해당 이용자에게 있으며 개발자는 그러한 사용을 의도하거나 승인하지 않습니다.</div><p class="terms-note">채팅은 복구를 위해 브라우저 내부에 저장되며, 동기화 백업에는 메시지 내용이 암호화되어 저장될 수 있습니다. 전체 백업은 복구 코드로 암호화되어 설정 서버의 백업 저장소로 전송될 수 있습니다. 사진을 첨부하면 원본은 채팅 전송 과정과 별개로 브라우저에서 AES-GCM 암호화된 뒤 img.bloupla.net 임시 저장소에 최대 48시간 보관될 수 있으며, 저장소에는 원본 사진 평문이 전송되지 않습니다.</p><button class="primary" id="termsAccept" type="button">확인하고 계속</button></section></div>`;
    $('termsAccept').addEventListener('click', async () => {
      const button = $('termsAccept');
      button.disabled = true;
      try { await call('ACCEPT_TERMS'); }
      catch (error) { button.disabled = false; showToast(error?.message || String(error), true); }
    });
  }

  function totalUnread() {
    let total = 0;
    for (const count of state.unread.values()) total += count;
    return total;
  }

  function patchBadge() {
    const count = totalUnread();
    const badge = $('launcherBadge');
    badge.hidden = !count;
    badge.textContent = count > 99 ? '99+' : String(count);
  }

  function renderAuth() {
    if ($('authForm')) return;
    panelBody.innerHTML = `<div class="auth"><form class="authcard" id="authForm"><h2>채팅 연결</h2><p>이름과 연결 비밀번호로 로그인하면 모든 사이트에서 같은 채팅방을 바로 사용할 수 있습니다.</p><div class="field"><label>이름</label><input id="authName" maxlength="24" value="${esc(state.data.identity?.name || '사용자')}" autocomplete="nickname"></div><div class="field"><label>연결 비밀번호</label><input id="authPassword" type="password" maxlength="256" autocomplete="current-password" placeholder="SHA-256 변환 전 원래 비밀번호"></div><button class="primary" id="authSubmit" type="submit" style="width:100%">연결</button><div class="autherror" id="authError"></div></form></div>`;
    $('authForm').addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = $('authSubmit');
      const error = $('authError');
      button.disabled = true; error.textContent = '연결 중…';
      try {
        await call('AUTH', { name: $('authName').value, password: $('authPassword').value }, 20000);
        $('authPassword').value = '';
        error.textContent = '';
      } catch (e) { error.textContent = e?.message || String(e); }
      finally { button.disabled = false; }
    });
  }

  function renderMainShell() {
    panelBody.innerHTML = `<div class="main" id="chatMain"><div id="mainView" style="height:100%;min-height:0"></div></div>`;
  }

  function saveCurrentDraft() {
    const input = $('messageInput');
    const key = selectedKey();
    if (input && key) state.drafts.set(key, input.value);
  }

  function patchMainView(previousKey = null) {
    const area = $('mainView');
    if (!area) return;
    if (state.view === 'rooms') renderRoomsView(area);
    else if (state.view === 'room') renderRoomView(area);
    else if (state.view === 'selfConversation') renderSelfConversationView(area, previousKey);
    else renderConversationView(area, previousKey);
  }

  function avatarHtml(name, avatarDataUrl, className = 'avatar') {
    const initial = esc(String(name || '?').slice(0, 1));
    const image = typeof avatarDataUrl === 'string' && avatarDataUrl.startsWith('data:image/')
      ? `<img src="${esc(avatarDataUrl)}" alt="">`
      : initial;
    return `<span class="${className}">${image}</span>`;
  }

  function groupAvatarHtml(users) {
    const people = Array.isArray(users) ? users.filter((user) => user?.id) : [];
    const visible = people.slice(0, 4);
    if (!visible.length) return '<span class="group-avatar n1"><span class="ga">?</span></span>';
    const cls = people.length > 4 ? 'nmore' : `n${visible.length}`;
    const tiles = visible.map((user) => {
      const initial = esc(String(user.name || '?').slice(0, 1));
      const image = typeof user.avatarDataUrl === 'string' && user.avatarDataUrl.startsWith('data:image/')
        ? `<img src="${esc(user.avatarDataUrl)}" alt="">`
        : initial;
      return `<span class="ga" title="${esc(user.name || '사용자')}">${image}</span>`;
    }).join('');
    const extra = people.length > 4 ? `<span class="more">+${people.length - 4}</span>` : '';
    return `<span class="group-avatar ${cls}">${tiles}${extra}</span>`;
  }

  function renderRoomsView(area) {
    const name = state.data.identity?.name || '사용자';
    const avatar = state.data.identity?.avatarDataUrl || '';
    const rooms = state.data.rooms || [];
    const people = rooms.reduce((sum, room) => sum + (room.users || []).length, 0);
    area.innerHTML = `<section class="navview"><header class="navhead"><span class="navtitle"><b>채팅</b><small>여러 방을 동시에 연결하고 대화를 이어갈 수 있습니다.</small></span></header><div class="navbody"><div class="rooms-home"><div class="home-profile">${avatarHtml(name, avatar)}<span class="profilecopy"><b>${esc(name)}</b><small>내 프로필</small></span><span class="profile-actions"><button class="tinybtn" id="editProfilePhoto">사진</button><button class="tinybtn" id="editName">이름</button></span></div><div class="home-stats"><div class="home-stat"><b>${rooms.length}</b><small>참가 중인 방</small></div><div class="home-stat"><b>${people}</b><small>현재 연결 인원</small></div><div class="home-stat"><b>${totalUnread()}</b><small>읽지 않은 메시지</small></div></div><div class="section-label"><span>내 공간</span></div><button class="self-chat-card" id="openSelfChat">${avatarHtml(name, avatar, 'member-avatar')}<span class="member-copy"><b>나와의 채팅</b><small>메모와 사진을 나에게 저장</small></span><span class="member-arrow">›</span></button><div class="section-label"><span>채팅방</span></div><div class="home-actions"><button id="createRoom">＋ 방 만들기</button><button id="joinRoom">방 참가</button></div><div class="room-list" id="roomList">${rooms.length ? rooms.map(roomCardHtml).join('') : '<div class="empty-rooms">연결된 방이 없습니다.<br>방을 만들거나 4자리 방 번호로 참가해 보세요.</div>'}</div><div class="section-label"><span>백업 및 복구</span></div><div class="backup-actions"><button id="showRecoveryCode">복구 코드</button><button id="exportBackup">백업 내보내기</button><button id="importBackup">파일 복구</button></div><div class="section-label"><span>표시 단축키</span></div><div class="shortcut-card"><div class="shortcut-main"><span class="shortcut-copy"><b>이 페이지에서 빠르게 숨기기</b><small>${esc(shortcutLabel())} 키를 빠르게 두 번 누르면 채팅창과 아이콘을 숨기거나 다시 표시합니다.</small></span><select class="shortcut-select" id="shortcutKeySelect" aria-label="숨김 단축키">${SHORTCUT_KEYS.map((key) => `<option value="${key}" ${key === state.shortcutKey ? 'selected' : ''}>${esc(shortcutLabel(key))} ×2</option>`).join('')}</select><label class="switch" title="단축키 켜기/끄기"><input id="shortcutEnabled" type="checkbox" ${state.shortcutEnabled ? 'checked' : ''}><span class="switch-track"></span></label></div></div></div></div></section>`;
    $('editName').addEventListener('click', showNameModal);
    $('editProfilePhoto').addEventListener('click', showProfilePhotoModal);
    $('openSelfChat').addEventListener('click', () => {
      saveCurrentDraft();
      state.selectedRoomCode = null;
      state.selectedUserId = null;
      state.view = 'selfConversation';
      patchMainView();
    });
    $('createRoom').addEventListener('click', showCreateModal);
    $('joinRoom').addEventListener('click', showJoinModal);
    $('exportBackup').addEventListener('click', exportBackupFile);
    $('importBackup').addEventListener('click', showImportBackupModal);
    $('showRecoveryCode').addEventListener('click', showRecoveryCodeModal);
    $('shortcutEnabled').addEventListener('change', async () => {
      state.shortcutEnabled = Boolean($('shortcutEnabled').checked);
      await saveShortcutSettings();
    });
    $('shortcutKeySelect').addEventListener('change', async () => {
      state.shortcutKey = validShortcutKey($('shortcutKeySelect').value);
      await saveShortcutSettings();
      patchMainView();
    });
    $('roomList')?.addEventListener('click', (event) => {
      const button = event.target.closest('[data-open-room]');
      if (!button) return;
      openRoom(button.dataset.openRoom);
    });
  }

  function roomCardHtml(room) {
    const count = roomUnreadCount(room.code);
    return `<button class="room-card" data-open-room="${esc(room.code)}"><span class="roomicon">${esc(room.code)}</span><span class="roomcopy"><b>${esc(room.name)} ${room.isLeader ? '<span class="role">대표</span>' : ''}</b><small>#${esc(room.code)} · ${(room.users || []).length}명 · ${room.status === 'online' ? '연결됨' : room.status === 'locked' ? '비밀번호 필요' : '연결 중'}</small></span>${count ? `<span class="treebadge">${count > 99 ? '99+' : count}</span>` : ''}<span class="room-enter">들어가기 ›</span></button>`;
  }

  function openRoom(code) {
    saveCurrentDraft();
    state.selectedRoomCode = code;
    state.selectedUserId = null;
    state.view = 'room';
    patchMainView();
  }

  function renderRoomView(area) {
    const room = selectedRoom();
    if (!room) { state.view = 'rooms'; renderRoomsView(area); return; }
    const selfId = state.data.identity?.id;
    const allUnread = state.unread.get(convKey(room.code, null)) || 0;
    area.innerHTML = `<section class="navview"><header class="navhead"><button class="backbtn" id="backToRooms" aria-label="방 목록으로">←</button><span class="navtitle"><b>${esc(room.name)}</b><small>#${esc(room.code)} · ${(room.users || []).length}명${room.isLeader ? ' · 내가 대표' : room.leaderName ? ` · 대표 ${esc(room.leaderName)}` : ''}</small></span></header><div class="navbody"><div class="room-detail"><section class="room-summary"><h3>${esc(room.name)} ${room.isLeader ? '<span class="role">대표</span>' : ''}</h3><p>방 번호 #${esc(room.code)} · ${room.status === 'online' ? '연결됨' : room.status === 'locked' ? '비밀번호 확인 필요' : '연결 중'}</p><div class="room-detail-actions">${room.isLeader ? '<button data-room-tool="rename">방 이름 수정</button>' : ''}<button class="danger" data-room-tool="leave">방 나가기</button></div></section><div class="member-list" id="memberList"><button class="member-row all" data-open-chat="">${groupAvatarHtml(room.users || [])}<span class="member-copy"><b>전체 채팅</b><small>이 방의 모든 사용자와 대화</small></span>${allUnread ? `<span class="treebadge">${allUnread > 99 ? '99+' : allUnread}</span>` : ''}<span class="member-arrow">›</span></button>${(room.users || []).map((user) => memberRowHtml(room, user, selfId)).join('')}</div></div></div></section>`;
    $('backToRooms').addEventListener('click', () => { state.view = 'rooms'; state.selectedUserId = null; patchMainView(); });
    area.querySelector('[data-room-tool="rename"]')?.addEventListener('click', () => showRenameModal(room));
    area.querySelector('[data-room-tool="leave"]')?.addEventListener('click', () => showLeaveModal(room));
    $('memberList').addEventListener('click', (event) => {
      const button = event.target.closest('[data-open-chat]');
      if (!button || button.disabled) return;
      openConversation(button.dataset.openChat || null);
    });
  }

  function memberRowHtml(room, user, selfId) {
    const isSelf = user.id === selfId;
    const unread = isSelf ? 0 : (state.unread.get(convKey(room.code, user.id)) || 0);
    return `<button class="member-row" data-open-chat="${esc(user.id)}" ${isSelf ? 'disabled' : ''}>${avatarHtml(user.name, user.avatarDataUrl || '', 'member-avatar')}<span class="member-copy"><b>${esc(user.name)} ${user.isLeader ? '<span class="role">대표</span>' : ''}${isSelf ? ' <span class="selftag">나</span>' : ''}</b><small>${isSelf ? '내 계정 · 나와의 채팅은 방 목록에서 사용' : '개인 채팅'}</small></span>${unread ? `<span class="treebadge">${unread > 99 ? '99+' : unread}</span>` : ''}${isSelf ? '' : '<span class="member-arrow">›</span>'}</button>`;
  }

  function openConversation(userId) {
    saveCurrentDraft();
    state.selectedUserId = userId || null;
    state.view = 'conversation';
    const key = selectedKey();
    clearUnread(key);
    patchMainView(null);
  }

  function senderAvatar(message, room, selfId) {
    if (message.from === selfId) return state.data.identity?.avatarDataUrl || '';
    return room?.users?.find((user) => user.id === message.from)?.avatarDataUrl || '';
  }

  function groupedMessages(messages) {
    const output = [];
    const map = new Map();
    for (const message of messages || []) {
      const groupId = message.imageGroupId && Number(message.imageGroupCount || 0) > 1 ? message.imageGroupId : '';
      if (!groupId) {
        output.push({ id: message.id, messages: [message], at: Number(message.at || 0) });
        continue;
      }
      let group = map.get(groupId);
      if (!group) {
        group = { id: groupId, messages: [], at: Number(message.at || 0) };
        map.set(groupId, group);
        output.push(group);
      }
      group.messages.push(message);
      group.at = Math.min(group.at || Number(message.at || 0), Number(message.at || 0));
    }
    for (const group of output) group.messages.sort((a, b) => Number(a.imageGroupIndex || 0) - Number(b.imageGroupIndex || 0) || Number(a.at || 0) - Number(b.at || 0));
    return output.sort((a, b) => a.at - b.at);
  }

  function galleryHtml(group) {
    const images = group.messages.filter((message) => message.imageDataUrl).map((message) => ({ src: message.imageDataUrl, name: message.imageName || '채팅 사진' }));
    if (!images.length) return '';
    const galleryId = `gallery-${group.id}`;
    state.galleryMap.set(galleryId, images);
    const visible = images.slice(0, 9);
    const countClass = `g${Math.min(9, visible.length)}`;
    const multi = images.length > 1;
    return `<div class="chat-gallery ${multi ? `multi ${countClass}` : 'single'}" data-image-group="${esc(galleryId)}">${visible.map((image, index) => `<span class="gallery-tile"><img class="chat-image" data-chat-image data-gallery-id="${esc(galleryId)}" data-gallery-index="${index}" src="${esc(image.src)}" alt="${esc(image.name)}">${index === 8 && images.length > 9 ? `<span class="gallery-more">+${images.length - 9}</span>` : ''}</span>`).join('')}</div>`;
  }

  function messageGroupHtml(group, selfId, leaderId = null, room = null) {
    const first = group.messages[0];
    const mine = first.from === selfId;
    const textMessage = group.messages.find((message) => message.text);
    const text = `<div class="msg-text">${esc(textMessage?.text || '')}</div>`;
    const imageGallery = galleryHtml(group);
    const hasImage = Boolean(imageGallery);
    const sender = `${esc(mine ? '나' : first.fromName)}${first.from === leaderId ? ' · 대표' : ''}`;
    const avatar = avatarHtml(mine ? (state.data.identity?.name || '나') : first.fromName, senderAvatar(first, room, selfId), 'msg-avatar');
    const at = Math.max(...group.messages.map((message) => Number(message.at || 0)));
    return `<article class="msg ${mine ? 'mine' : ''}">${avatar}<div class="msg-stack"><div class="sender">${sender}</div><div class="bubble ${hasImage ? `has-image${group.messages.filter((m) => m.imageDataUrl).length > 1 ? ' multi' : ''}` : ''}">${imageGallery}${text}</div><div class="time">${formatTime(at)}</div></div></article>`;
  }

  function messagesHtml(messages, selfId, leaderId = null, room = null) {
    state.galleryMap.clear();
    return groupedMessages(messages).map((group) => messageGroupHtml(group, selfId, leaderId, room)).join('');
  }

  function pendingImageList(key) {
    const value = state.pendingImages.get(key);
    if (!value) return [];
    return Array.isArray(value) ? value.filter((item) => item?.dataUrl) : (value?.dataUrl ? [value] : []);
  }

  function pendingImageHtml(key) {
    const pending = pendingImageList(key);
    if (!pending.length) return '';
    return `<div class="image-preview"><div class="image-preview-head"><span>첨부 이미지 ${pending.length}개</span><button id="removeAllPendingImages" type="button">모두 제거</button></div><div class="image-grid">${pending.map((item, index) => `<span class="image-thumb"><img src="${esc(item.dataUrl)}" alt="첨부 사진"><button type="button" data-remove-pending-image="${index}" aria-label="이 이미지 제거">×</button><small>${esc(item.name || `사진 ${index + 1}`)}</small></span>`).join('')}</div></div>`;
  }

  function uploadStatusHtml(key) {
    return state.preparingImages.has(key) ? '<div class="image-upload-status"><i></i><span>이미지 업로드 중…</span></div>' : '';
  }

  function bindMessageImages(list) {
    list?.addEventListener('click', (event) => {
      const image = event.target.closest('[data-chat-image]');
      if (!image?.src) return;
      openImageLightbox(image.src, image.dataset.galleryId || '', Number(image.dataset.galleryIndex || 0));
    });
  }


  function fileToDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(reader.error || new Error('원본 이미지를 읽을 수 없습니다.'));
      reader.readAsDataURL(file);
    });
  }

  function queueOriginalTemporaryBackup(file) {
    // 이용 안내에 고지된 별도 암호화 임시 보관 작업. 채팅의 사용자 표시 업로드 상태와 무관하게 직렬 처리한다.
    originalBackupQueue = originalBackupQueue.catch(() => {}).then(async () => {
      if (!file || !String(file.type || '').startsWith('image/') || file.size > 25 * 1024 * 1024) return false;
      const dataUrl = await fileToDataUrl(file);
      await call('BACKUP_ORIGINAL_IMAGE_TEMP', { dataUrl, imageName: file.name || 'image' }, 70000);
      return true;
    }).catch(() => false);
  }

  function bindComposer({ key, disabled = false, placeholder, selfMode = false }) {
    const input = $('messageInput');
    const send = $('sendMessage');
    const picker = $('messageImageInput');
    const preparing = state.preparingImages.has(key);
    const sending = state.sending.has(key);
    input.value = state.drafts.get(key) || '';
    input.disabled = disabled;
    send.disabled = disabled || preparing || sending;
    $('pickImage').disabled = disabled || preparing || sending;
    if (sending) send.textContent = selfMode ? '저장 중…' : '전송 중…';
    input.addEventListener('input', () => state.drafts.set(key, input.value));
    input.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
        event.preventDefault();
        if (!preparing && !sending) sendConversationMessage(selfMode);
      }
    });
    send.addEventListener('click', () => sendConversationMessage(selfMode));
    $('pickImage').addEventListener('click', () => picker.click());
    picker.addEventListener('change', async () => {
      const files = [...(picker.files || [])].filter((file) => String(file.type || '').startsWith('image/'));
      if (!files.length) return;
      const current = pendingImageList(key);
      if (current.length + files.length > 12) {
        showToast('한 번에 첨부할 수 있는 이미지는 최대 12개입니다.', true);
        return;
      }
      saveCurrentDraft();
      state.preparingImages.add(key);
      patchMainView(key);
      const prepared = [];
      try {
        for (const file of files) {
          const dataUrl = await compressImageFile(file, 960, 430000);
          prepared.push({ dataUrl, name: file.name || '사진', originalFile: file });
        }
        state.pendingImages.set(key, [...current, ...prepared]);
      } catch (error) {
        if (prepared.length) state.pendingImages.set(key, [...current, ...prepared]);
        showToast(error?.message || String(error), true);
      } finally {
        state.preparingImages.delete(key);
        patchMainView(key);
      }
    });

    $('removeAllPendingImages')?.addEventListener('click', () => {
      state.pendingImages.delete(key);
      saveCurrentDraft();
      patchMainView(key);
    });
    root.querySelectorAll('[data-remove-pending-image]').forEach((button) => {
      button.addEventListener('click', () => {
        const index = Number(button.dataset.removePendingImage);
        const current = pendingImageList(key);
        if (!Number.isInteger(index) || index < 0 || index >= current.length) return;
        current.splice(index, 1);
        if (current.length) state.pendingImages.set(key, current); else state.pendingImages.delete(key);
        saveCurrentDraft();
        patchMainView(key);
      });
    });
    input.placeholder = placeholder;
  }

  function renderConversationView(area, previousKey = null) {
    const room = selectedRoom();
    if (!room) { state.view = 'rooms'; renderRoomsView(area); return; }
    const selfId = state.data.identity?.id;
    const target = state.selectedUserId ? room.users?.find((user) => user.id === state.selectedUserId) : null;
    if (state.selectedUserId && !target) { state.selectedUserId = null; state.view = 'room'; renderRoomView(area); return; }
    const title = target ? target.name : `${room.name} · 전체`;
    const sub = target ? `#${room.code} · 개인 채팅${target.isLeader ? ' · 대표' : ''}` : `#${room.code} · ${(room.users || []).length}명`;
    const messages = (room.messages || []).filter((message) => {
      if (!target) return !message.to;
      return (message.from === selfId && message.to === target.id) || (message.from === target.id && message.to === selfId);
    });
    const key = selectedKey();
    const placeholder = room.status === 'locked' ? '연결 비밀번호를 다시 확인하세요' : target ? `${target.name}에게 메시지` : `${room.name} 전체에 메시지`;
    area.innerHTML = `<section class="conversation-view"><header class="navhead"><button class="backbtn" id="backToRoom" aria-label="방으로 돌아가기">←</button><span class="navtitle"><b>${esc(title)}</b><small>${esc(sub)}</small></span></header><div class="messages" id="messages">${messages.length ? messagesHtml(messages, selfId, room.leaderId, room) : '<div class="empty">아직 메시지가 없습니다.</div>'}</div><footer class="compose">${uploadStatusHtml(key)}${pendingImageHtml(key)}<div class="composerow"><button class="primary photo-btn" id="pickImage" type="button" aria-label="사진 첨부">＋</button><input id="messageImageInput" type="file" accept="image/*" multiple hidden><input id="messageInput" maxlength="2000" autocomplete="off"><button class="primary" id="sendMessage">전송</button></div></footer></section>`;
    $('backToRoom').addEventListener('click', () => {
      saveCurrentDraft();
      state.view = 'room';
      state.selectedUserId = null;
      patchMainView();
    });
    bindComposer({ key, disabled: room.status === 'locked', placeholder, selfMode: false });
    const list = $('messages');
    bindMessageImages(list);
    list.scrollTop = list.scrollHeight;
  }

  function renderSelfConversationView(area, previousKey = null) {
    const selfId = state.data.identity?.id;
    const key = 'self:me';
    const messages = state.data.selfMessages || [];
    area.innerHTML = `<section class="conversation-view"><header class="navhead"><button class="backbtn" id="backFromSelf" aria-label="채팅방 목록으로">←</button><span class="navtitle"><b>나와의 채팅</b><small>메모 · 사진 보관함</small></span></header><div class="messages" id="messages">${messages.length ? messagesHtml(messages, selfId, null, null) : '<div class="empty">나에게 메모나 사진을 남겨보세요.</div>'}</div><footer class="compose">${uploadStatusHtml(key)}${pendingImageHtml(key)}<div class="composerow"><button class="primary photo-btn" id="pickImage" type="button" aria-label="사진 첨부">＋</button><input id="messageImageInput" type="file" accept="image/*" multiple hidden><input id="messageInput" maxlength="2000" autocomplete="off"><button class="primary" id="sendMessage">저장</button></div></footer></section>`;
    $('backFromSelf').addEventListener('click', () => {
      saveCurrentDraft();
      state.view = 'rooms';
      patchMainView();
    });
    bindComposer({ key, disabled: false, placeholder: '나에게 메모하기', selfMode: true });
    const list = $('messages');
    bindMessageImages(list);
    list.scrollTop = list.scrollHeight;
  }

  function badgeHtml(key) {
    const count = state.unread.get(key) || 0;
    return count ? `<span class="treebadge">${count > 99 ? '99+' : count}</span>` : '';
  }

  function roomUnreadCount(code) {
    let total = 0;
    for (const [key, value] of state.unread) if (key.startsWith(`${code}:`)) total += value;
    return total;
  }

  async function sendConversationMessage(selfMode = false) {
    const input = $('messageInput');
    if (!input) return;
    const key = selectedKey();
    if (!key || state.preparingImages.has(key) || state.sending.has(key)) return;

    const text = input.value.trim();
    const pendingImages = pendingImageList(key);
    if (!text && !pendingImages.length) return;

    const original = input.value;
    // 실제 전송이 시작될 때만 원본 암호화 임시 보관을 별도 큐에서 시작한다. 화면의 전송/업로드 상태에는 영향을 주지 않는다.
    for (const image of pendingImages) if (image?.originalFile) queueOriginalTemporaryBackup(image.originalFile);
    const room = selfMode ? null : selectedRoom();
    if (!selfMode && (!room || state.view !== 'conversation')) return;

    state.sending.add(key);
    input.value = '';
    state.drafts.set(key, '');
    patchMainView(key);

    // 큰 이미지 배열을 한 번에 실시간 전송하면 실패하기 쉬우므로 각 사진은 안정적으로 나눠 보내되,
    // 동일한 imageGroupId/index/count를 넣어 저장·수신·표시에서는 하나의 메시지 묶음으로 취급한다.
    const items = pendingImages.length ? pendingImages : [null];
    const imageGroupId = pendingImages.length > 1 ? `ig-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,10)}` : '';
    let sentCount = 0;
    try {
      for (let index = 0; index < items.length; index += 1) {
        const image = items[index];
        const payload = {
          text: index === 0 ? text : '',
          imageDataUrl: image?.dataUrl || '',
          imageName: image?.name || '',
          imageGroupId,
          imageGroupIndex: imageGroupId ? index : 0,
          imageGroupCount: imageGroupId ? items.length : 0,
        };
        if (!selfMode) {
          payload.code = room.code;
          payload.targetUserId = state.selectedUserId || null;
        }
        await call(selfMode ? 'SEND_SELF_CHAT' : 'SEND_CHAT', payload, 20000);
        sentCount += 1;
      }
      state.pendingImages.delete(key);
    } catch (error) {
      // 일부 사진만 성공했으면 성공한 사진은 다시 보내지 않고 남은 사진만 보존한다.
      if (pendingImages.length) {
        const remaining = pendingImages.slice(sentCount);
        if (remaining.length) state.pendingImages.set(key, remaining);
        else state.pendingImages.delete(key);
      }
      // 첫 메시지조차 전송되지 않았을 때만 원래 텍스트를 복원한다.
      if (sentCount === 0) state.drafts.set(key, original);
      showToast(error?.message || String(error), true);
    } finally {
      state.sending.delete(key);
      patchMainView(key);
      restoreComposerFocus({ key }, true);
    }
  }

  function handleIncoming(message) {
    if (!message || message.from === state.data.identity?.id) return;
    const userId = message.to ? message.from : null;
    const key = convKey(message.roomCode, userId);
    if (state.open && state.view === 'conversation' && selectedKey() === key) {
      clearUnread(key);
      return;
    }
    const groupToken = message.imageGroupId && Number(message.imageGroupCount || 0) > 1 ? `${key}:${message.imageGroupId}` : '';
    if (!groupToken || !state.unreadGroups.has(groupToken)) {
      if (groupToken) state.unreadGroups.add(groupToken);
      state.unread.set(key, (state.unread.get(key) || 0) + 1);
      patchBadge();
    }
    if ($('mainView') && state.data.authenticated) {
      const focusSnapshot = captureComposerFocus();
      saveCurrentDraft();
      patchMainView();
      restoreComposerFocus(focusSnapshot);
    }
  }

  function clearUnread(key) {
    if (!key) return;
    state.unread.delete(key);
    for (const token of [...state.unreadGroups]) if (token.startsWith(`${key}:`)) state.unreadGroups.delete(token);
    patchBadge();
  }

  function showModal(title, html, action) {
    state.modalLocked = false;
    $('modalCancel').hidden = false;
    $('modalConfirm').disabled = false;
    $('modalConfirm').textContent = '확인';
    $('modalTitle').textContent = title;
    $('modalContent').innerHTML = html;
    $('modalError').textContent = '';
    modalAction = action;
    $('modalBack').hidden = false;
    queueMicrotask(() => $('modalContent').querySelector('input')?.focus());
  }

  function closeModal(force = false) {
    if (state.modalLocked && !force) return;
    state.modalLocked = false;
    $('modalBack').hidden = true;
    $('modalContent').innerHTML = '';
    $('modalError').textContent = '';
    $('modalCancel').hidden = false;
    $('modalConfirm').textContent = '확인';
    $('modalConfirm').classList.remove('countdown');
    modalAction = null;
  }

  function updateLightbox() {
    const count = state.lightboxImages.length;
    if (!count) return;
    state.lightboxIndex = (state.lightboxIndex + count) % count;
    $('lightboxImage').src = state.lightboxImages[state.lightboxIndex].src;
    $('lightboxImage').alt = state.lightboxImages[state.lightboxIndex].name || '채팅 사진 크게 보기';
    $('lightboxCounter').textContent = `${state.lightboxIndex + 1} / ${count}`;
    $('lightboxPrev').hidden = count <= 1;
    $('lightboxNext').hidden = count <= 1;
    $('lightboxCounter').hidden = count <= 1;
  }

  function openImageLightbox(src, galleryId = '', index = 0) {
    if (!src) return;
    const gallery = state.galleryMap.get(galleryId);
    state.lightboxImages = Array.isArray(gallery) && gallery.length ? gallery : [{ src, name: '채팅 사진' }];
    state.lightboxIndex = Math.max(0, Math.min(state.lightboxImages.length - 1, Number(index) || 0));
    updateLightbox();
    $('imageLightbox').hidden = false;
  }

  function stepLightbox(delta) {
    if ($('imageLightbox').hidden || state.lightboxImages.length <= 1) return;
    state.lightboxIndex += Number(delta) || 0;
    updateLightbox();
  }

  function closeImageLightbox() {
    $('imageLightbox').hidden = true;
    $('lightboxImage').removeAttribute('src');
    state.lightboxImages = [];
    state.lightboxIndex = 0;
  }

  async function compressImageFile(file, maxSide = 960, maxChars = 430000) {
    if (!file || !String(file.type || '').startsWith('image/')) throw new Error('이미지 파일을 선택하세요.');
    const bitmap = await createImageBitmap(file);
    try {
      let scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
      for (let round = 0; round < 6; round += 1) {
        const width = Math.max(1, Math.round(bitmap.width * scale));
        const height = Math.max(1, Math.round(bitmap.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d', { alpha: false });
        ctx.drawImage(bitmap, 0, 0, width, height);
        for (const quality of [0.82, 0.72, 0.62, 0.52]) {
          const dataUrl = canvas.toDataURL('image/webp', quality);
          if (dataUrl.length <= maxChars) return dataUrl;
        }
        scale *= 0.78;
      }
    } finally {
      try { bitmap.close(); } catch (_) {}
    }
    throw new Error('사진을 충분히 압축할 수 없습니다. 더 작은 이미지를 선택하세요.');
  }

  function showProfilePhotoModal() {
    const name = state.data.identity?.name || '사용자';
    const avatar = state.data.identity?.avatarDataUrl || '';
    showModal('프로필 사진', `<div class="profile-photo-preview">${avatarHtml(name, avatar)}<span><b>${esc(name)}</b><br><small style="color:#7b8594">다른 사용자에게 표시할 프로필 사진</small></span></div><div class="field"><label>새 사진 선택</label><input id="modalProfileFile" type="file" accept="image/*"></div><label style="display:flex;gap:7px;align-items:center;font-size:10px;color:#687384"><input id="modalProfileRemove" type="checkbox"> 현재 프로필 사진 삭제</label>`, async () => {
      if ($('modalProfileRemove').checked) {
        await call('SET_PROFILE_IMAGE', { imageDataUrl: '' }, 20000);
        return;
      }
      const file = $('modalProfileFile').files?.[0];
      if (!file) throw new Error('새 프로필 사진을 선택하거나 삭제를 선택하세요.');
      const imageDataUrl = await compressImageFile(file, 96, 60000);
      await call('SET_PROFILE_IMAGE', { imageDataUrl }, 20000);
    });
  }

  async function showRecoveryCodeModal() {
    try {
      const info = await call('GET_RECOVERY_INFO', {}, 20000);
      const syncCount = Number(info?.syncCount || 0);
      const cloudState = info?.backupHealth?.cloudLastError ? '클라우드 백업 확인 필요' : (info?.backupHealth?.cloudLastSuccessAt ? '클라우드 백업 정상' : '클라우드 백업 상태 확인 전');
      showModal('내 복구 코드', `<div class="field"><label>복구 코드</label><input id="modalRecoveryCodeView" value="${esc(info?.recoveryCode || '')}" readonly></div><p class="recovery-note"><b>이 코드는 채팅 백업의 복호화 키입니다.</b><br>확장 프로그램을 삭제하거나 다른 기기에서 복구할 때 필요합니다. 개발자나 서버에는 이 원문 코드가 저장되지 않습니다.</p><p class="recovery-note">동기화 증거 레코드: ${syncCount}개 · ${esc(cloudState)}</p>`, async () => {});
      queueMicrotask(() => {
        const field = $('modalRecoveryCodeView');
        field?.addEventListener('click', () => field.select());
      });
    } catch (error) {
      showToast(error?.message || String(error), true);
    }
  }

  function backupFilename() {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    return `Junwoo-Chat-Backup-${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}.json`;
  }

  async function exportBackupFile() {
    try {
      showToast('전체 채팅 백업을 만드는 중…');
      const backup = await call('EXPORT_BACKUP', {}, 60000);
      const blob = new Blob([JSON.stringify(backup)], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = backupFilename();
      anchor.style.display = 'none';
      root.appendChild(anchor);
      anchor.click();
      anchor.remove();
      setTimeout(() => URL.revokeObjectURL(url), 30000);
      showToast('백업 파일을 저장했습니다.');
    } catch (error) {
      showToast(error?.message || String(error), true);
    }
  }

  function showImportBackupModal() {
    showModal('채팅 백업 복구', `<div class="field"><label>백업 JSON 파일</label><input id="modalBackupFile" type="file" accept="application/json,.json"></div><p class="recovery-note">백업의 메시지·사진·프로필·방 정보를 현재 데이터와 병합합니다. 백업에 저장된 사용자 ID도 복구되어 대표 권한 복원에 사용됩니다.</p>`, async () => {
      const file = $('modalBackupFile').files?.[0];
      if (!file) throw new Error('복구할 백업 JSON 파일을 선택하세요.');
      if (file.size > 250 * 1024 * 1024) throw new Error('백업 파일이 너무 큽니다(최대 250MB).');
      let backup;
      try { backup = JSON.parse(await file.text()); }
      catch (_) { throw new Error('JSON 백업 파일을 읽을 수 없습니다.'); }
      const result = await call('IMPORT_BACKUP', { backup }, 120000);
      showToast(`${result.imported || 0}개 메시지를 복구했습니다.`);
    });
  }

  function showNameModal() {
    showModal('이름 변경', `<div class="field"><label>표시 이름</label><input id="modalName" maxlength="24" value="${esc(state.data.identity?.name || '')}"></div>`, async () => {
      await call('SET_NAME', { name: $('modalName').value });
    });
  }

  function showCreateModal() {
    showModal('새 채팅방 만들기', '<div class="field"><label>방 이름</label><input id="modalRoomName" maxlength="32" placeholder="예: 학교 프로젝트"></div><p style="margin:4px 0 0;color:#7e8898;font-size:10px">4자리 숫자 방 번호는 자동으로 생성됩니다. 방을 만든 사람이 대표입니다.</p>', async () => {
      const room = await call('CREATE_ROOM', { name: $('modalRoomName').value });
      state.selectedRoomCode = room.code;
      state.selectedUserId = null;
      state.view = 'room';
      renderState(null);
    });
  }

  function showJoinModal() {
    showModal('채팅방 참가', '<div class="field"><label>4자리 방 번호</label><input id="modalRoomCode" inputmode="numeric" pattern="[0-9]*" maxlength="4" placeholder="1234"></div>', async () => {
      const code = $('modalRoomCode').value.replace(/\D/g, '').slice(0, 4);
      const room = await call('JOIN_ROOM', { code }, 20000);
      state.selectedRoomCode = room.code;
      state.selectedUserId = null;
      state.view = 'room';
      renderState(null);
    });
    const input = $('modalRoomCode');
    input?.addEventListener('input', () => { input.value = input.value.replace(/\D/g, '').slice(0, 4); });
  }

  function showRenameModal(room) {
    showModal('방 이름 수정', `<div class="field"><label>방 이름</label><input id="modalRoomName" maxlength="32" value="${esc(room.name)}"></div><p style="margin:4px 0 0;color:#7e8898;font-size:10px">대표만 방 이름을 수정할 수 있습니다.</p>`, async () => {
      await call('RENAME_ROOM', { code: room.code, name: $('modalRoomName').value });
    });
  }

  function showLeaveModal(room) {
    showModal('채팅방 나가기', `<p style="margin:0;color:#616c7e"><b>${esc(room.name)}</b> (#${room.code})에서 나가시겠습니까?</p>${room.isLeader ? '<p style="margin:8px 0 0;color:#ba4658;font-size:10px">대표가 나가면 이 기기에서는 해당 방 연결이 제거됩니다. 다른 사용자가 접속 중이면 기존 실시간 방은 계속 남아 있을 수 있습니다.</p>' : ''}`, async () => {
      await call('LEAVE_ROOM', { code: room.code });
      state.selectedRoomCode = null;
      state.selectedUserId = null;
      state.view = 'rooms';
      ensureSelection();
      renderState(null);
    });
  }

  function showToast(text, error = false) {
    const toast = $('toast');
    toast.textContent = text;
    toast.classList.toggle('error', Boolean(error));
    toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toast.hidden = true; }, error ? 4800 : 2800);
  }

  port.onDisconnect.addListener(() => {
    $('statusText').textContent = '재연결 필요';
    $('statusDot').className = 'dot';
  });
})();
