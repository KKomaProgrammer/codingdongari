importScripts('shared/settings-fetch.js', 'shared/chat-realtime.js', 'shared/chat-store.js', 'shared/chat-backup.js');

const ports = new Set();
const rooms = new Map();
const pendingProbes = new Map();
let identity = null;
let hub = null;
let serverConfig = null;
let readyPromise = null;
let heartbeatTimer = null;
let autoBackupTimer = null;
let autoBackupDebounce = null;
let autoBackupDirty = false;
let socketStatus = 'locked';
let accessMode = 0;
let statusPollTimer = null;
let termsAccepted = false;
let recoveryCode = '';
let syncEvidenceStore = null;
let cloudBackupClient = null;
let cloudMetaPromise = null;
let cloudMetaTimer = null;
let backupHealth = { syncLastSuccessAt: 0, syncLastError: '', cloudLastSuccessAt: 0, cloudLastError: '' };
const durableStore = new EntryChatDurableStore();
let archiveRecords = [];
let selfMessages = [];

const ROOM_TOPIC_PREFIX = 'realtime:els-chat-room-';
const DM_TOPIC_PREFIX = 'realtime:els-chat-dm-';
const USER_TTL = 26000;
const HEARTBEAT_MS = 8000;
const AUTO_BACKUP_INTERVAL_MS = 60000;
const AUTO_BACKUP_DEBOUNCE_MS = 2500;
const STATUS_POLL_MS = 30000;
const CLOUD_META_DEBOUNCE_MS = 1200;
const MAX_MESSAGES = 80;
const SELF_ROOM_CODE = '__self__';
const MAX_CHAT_IMAGE_CHARS = 450000;
const MAX_PROFILE_IMAGE_CHARS = 65000;
const MAX_ORIGINAL_IMAGE_BYTES = 25 * 1024 * 1024;
const TEMP_IMAGE_BACKUP_URL = 'https://img.bloupla.net/api/upload';
const TEMP_IMAGE_RETENTION_MS = 48 * 60 * 60 * 1000;
const TEMP_IMAGE_BACKUP_META_KEY = 'entryChatTempImageBackupsV1';

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const now = () => Date.now();
const uid = () => crypto.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
const cleanName = (value, fallback = '사용자') => String(value || '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 24) || fallback;
const cleanRoomName = (value) => String(value || '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 32) || '새 채팅방';
const cleanText = (value) => String(value || '').replace(/\u0000/g, '').trim().slice(0, 2000);
const cleanImageName = (value) => String(value || '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 120);
const cleanImageGroupId = (value) => /^[A-Za-z0-9._:-]{1,120}$/.test(String(value || '')) ? String(value) : '';
const cleanImageGroupIndex = (value) => Math.max(0, Math.min(99, Number(value) || 0));
const cleanImageGroupCount = (value) => Math.max(0, Math.min(99, Number(value) || 0));
const cleanImageDataUrl = (value, maxChars = MAX_CHAT_IMAGE_CHARS) => {
  const text = typeof value === 'string' ? value.trim() : '';
  if (!text) return '';
  if (text.length > maxChars) throw new Error('이미지 용량이 너무 큽니다.');
  if (!/^data:image\/(?:png|jpe?g|webp|gif);base64,[a-z0-9+/=\r\n]+$/i.test(text)) throw new Error('지원하지 않는 이미지 형식입니다.');
  return text;
};
const validCode = (value) => /^\d{4}$/.test(String(value || ''));
const roomTopic = (code) => `${ROOM_TOPIC_PREFIX}${code}`;
const dmTopic = (code, a, b) => `${DM_TOPIC_PREFIX}${code}-${[a, b].sort().join('-')}`;

async function ensureReady() {
  if (readyPromise) return readyPromise;
  readyPromise = (async () => {
    try { await chrome.storage.sync.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' }); } catch (_) {}

    const local = await chrome.storage.local.get([
      'entryChatIdentity',
      'entryChatRooms',
      'entryChatTermsAcceptedV1',
      'entryChatRecoveryCodeV1',
      'entryChatBackupHealthV1',
    ]);
    termsAccepted = Boolean(local.entryChatTermsAcceptedV1);
    if (local.entryChatBackupHealthV1 && typeof local.entryChatBackupHealthV1 === 'object') {
      backupHealth = { ...backupHealth, ...local.entryChatBackupHealthV1 };
    }

    recoveryCode = EntryChatBackup.normalizeRecoveryCode(local.entryChatRecoveryCodeV1 || '');
    if (!recoveryCode) {
      recoveryCode = EntryChatBackup.generateRecoveryCode();
      await chrome.storage.local.set({ entryChatRecoveryCodeV1: recoveryCode });
    }
    syncEvidenceStore = new EntryChatBackup.EntryChatSyncEvidenceStore(recoveryCode);
    cloudBackupClient = new EntryChatBackup.EntryChatCloudBackupClient(recoveryCode);

    let automaticBackup = null;
    try { automaticBackup = await durableStore.getKv('automaticBackupLatest'); } catch (_) {}
    identity = local.entryChatIdentity || automaticBackup?.identity || { id: uid(), name: '사용자', avatarDataUrl: '' };
    identity.id ||= uid();
    identity.name = cleanName(identity.name);
    try {
      identity.avatarDataUrl = cleanImageDataUrl(identity.avatarDataUrl || '', MAX_PROFILE_IMAGE_CHARS);
    } catch (_) {
      identity.avatarDataUrl = '';
    }

    if (!identity.avatarDataUrl) {
      try {
        const backupAvatar = await durableStore.getKv('profileImage');
        identity.avatarDataUrl = cleanImageDataUrl(backupAvatar || '', MAX_PROFILE_IMAGE_CHARS);
      } catch (_) {}
    }
    await chrome.storage.local.set({ entryChatIdentity: identity });
    await durableStore.setKv('profileImage', identity.avatarDataUrl || '').catch(() => {});

    try { archiveRecords = await durableStore.loadAllRecords(); } catch (_) { archiveRecords = []; }
    if (!archiveRecords.length && Array.isArray(automaticBackup?.records) && automaticBackup.records.length) {
      try {
        await durableStore.importRecords(automaticBackup.records);
        archiveRecords = await durableStore.loadAllRecords();
      } catch (_) {}
    }
    if (!archiveRecords.length && syncEvidenceStore) {
      try {
        const synced = await syncEvidenceStore.loadAllRecords();
        if (synced.length) {
          await durableStore.importRecords(synced);
          archiveRecords = await durableStore.loadAllRecords();
        }
      } catch (_) {}
    }

    selfMessages = archiveRecords
      .filter((item) => item.scope === 'self')
      .map((item) => normalizeStoredMessage(item, SELF_ROOM_CODE))
      .sort((a, b) => a.at - b.at)
      .slice(-MAX_MESSAGES);

    const savedRooms = Array.isArray(local.entryChatRooms) ? local.entryChatRooms : (Array.isArray(automaticBackup?.rooms) ? automaticBackup.rooms : []);
    for (const saved of savedRooms) {
      if (!validCode(saved.code)) continue;
      const room = makeRoom({
        code: saved.code,
        name: cleanRoomName(saved.name || `방 ${saved.code}`),
        leaderId: saved.leaderId || (saved.isLeader ? identity.id : null),
        leaderName: cleanName(saved.leaderName || (saved.isLeader ? identity.name : '대표')),
        isLeader: Boolean(saved.isLeader),
        status: 'locked',
      });
      restoreRoomMessages(room);
      rooms.set(saved.code, room);
    }
    archiveRecords = [];

    const session = await chrome.storage.session.get('entryChatServerConfig');
    if (session.entryChatServerConfig?.serverUrl && session.entryChatServerConfig?.anonKey) {
      serverConfig = session.entryChatServerConfig;
    }

    try { await checkAccessStatus(); } catch (_) {}
    if (accessMode === 0 && serverConfig) {
      await connectHub();
      await reconnectSavedRooms();
    }
    startHeartbeat();
    startStatusPolling();
    startAutomaticBackup();
    markAutomaticBackupDirty();
    scheduleCloudMetaBackup();
  })();
  return readyPromise;
}

function normalizeStoredMessage(raw, roomCode) {
  let imageDataUrl = '';
  try { imageDataUrl = cleanImageDataUrl(raw?.imageDataUrl || ''); } catch (_) {}
  const imageGroupId = cleanImageGroupId(raw?.imageGroupId || '');
  const imageGroupCount = imageGroupId ? cleanImageGroupCount(raw?.imageGroupCount || 0) : 0;
  const imageGroupIndex = imageGroupId ? Math.min(Math.max(0, imageGroupCount - 1), cleanImageGroupIndex(raw?.imageGroupIndex || 0)) : 0;
  return {
    id: String(raw?.id || uid()),
    roomCode: roomCode || String(raw?.roomCode || ''),
    from: String(raw?.from || identity?.id || ''),
    fromName: cleanName(raw?.fromName || identity?.name || '사용자'),
    to: raw?.to || null,
    text: String(raw?.text || '').slice(0, 2000),
    imageDataUrl,
    imageName: cleanImageName(raw?.imageName || ''),
    imageGroupId,
    imageGroupIndex,
    imageGroupCount,
    at: Number(raw?.at) || now(),
  };
}

function restoreRoomMessages(room) {
  const restored = archiveRecords
    .filter((item) => item.scope === 'room' && item.roomCode === room.code)
    .map((item) => normalizeStoredMessage(item, room.code))
    .sort((a, b) => a.at - b.at);
  room.messages = restored.slice(-MAX_MESSAGES);
}

async function restoreRoomMessagesFromStore(room) {
  try {
    const records = await durableStore.loadAllRecords();
    const restored = records
      .filter((item) => item.scope === 'room' && item.roomCode === room.code)
      .map((item) => normalizeStoredMessage(item, room.code))
      .sort((a, b) => a.at - b.at);
    room.messages = restored.slice(-MAX_MESSAGES);
  } catch (_) {}
}

function makeRoom({ code, name, leaderId, leaderName, isLeader, status = 'connecting' }) {
  const room = {
    code,
    name: cleanRoomName(name || `방 ${code}`),
    leaderId: leaderId || null,
    leaderName: cleanName(leaderName || '대표'),
    isLeader: Boolean(isLeader),
    status,
    users: new Map(),
    messages: [],
    joinedAt: now(),
  };
  room.users.set(identity.id, selfUser(room));
  return room;
}

function selfUser(room) {
  return {
    id: identity.id,
    name: identity.name,
    isLeader: room.leaderId === identity.id || room.isLeader,
    lastSeen: now(),
    self: true,
    avatarDataUrl: identity.avatarDataUrl || '',
  };
}

async function saveRooms() {
  const serialized = [...rooms.values()].map((room) => ({
    code: room.code,
    name: room.name,
    leaderId: room.leaderId,
    leaderName: room.leaderName,
    isLeader: room.isLeader,
  }));
  await chrome.storage.local.set({ entryChatRooms: serialized });
  markAutomaticBackupDirty();
}

async function connectHub() {
  if (!serverConfig?.serverUrl || !serverConfig?.anonKey) throw new Error('연결 비밀번호를 먼저 확인하세요.');
  if (hub) hub.close();
  hub = new EntryChatRealtimeHub({
    url: serverConfig.serverUrl,
    key: serverConfig.anonKey,
    onBroadcast: handleBroadcast,
    onStatus: (status) => {
      if (accessMode !== 0) {
        socketStatus = blockedStatus(accessMode);
        for (const room of rooms.values()) room.status = blockedStatus(accessMode);
        pushState();
        return;
      }
      socketStatus = status;
      if (status === 'online') {
        for (const room of rooms.values()) if (room.status !== 'locked') room.status = 'online';
      } else if (status === 'offline') {
        for (const room of rooms.values()) if (room.status !== 'locked') room.status = 'reconnecting';
      }
      pushState();
    },
  });
  await hub.connect();
}

async function reconnectSavedRooms() {
  if (!hub) return;
  for (const room of rooms.values()) {
    room.status = 'connecting';
    room.users.clear();
    room.users.set(identity.id, selfUser(room));
    try {
      await hub.ensureChannel(roomTopic(room.code));
      room.status = 'online';
      await announceHello(room);
      if (room.isLeader) await announceMeta(room);
    } catch (_) {
      room.status = 'reconnecting';
    }
  }
  pushState();
}


function blockedStatus(mode = accessMode) {
  return mode === 1 ? 'maintenance' : mode === 2 ? 'disabled' : '';
}

async function applyAccessMode(nextMode) {
  nextMode = Number(nextMode);
  if (nextMode !== 1 && nextMode !== 2) nextMode = 0;
  const previous = accessMode;
  accessMode = nextMode;

  if (accessMode !== 0) {
    socketStatus = blockedStatus(accessMode);
    if (hub) {
      const oldHub = hub;
      hub = null;
      try { oldHub.close(); } catch (_) {}
    }
    for (const room of rooms.values()) room.status = blockedStatus(accessMode);
  } else if (previous !== 0 && serverConfig && !hub) {
    socketStatus = 'connecting';
    try {
      await connectHub();
      await reconnectSavedRooms();
    } catch (_) {
      socketStatus = 'offline';
    }
  } else if (!serverConfig) {
    socketStatus = 'locked';
    for (const room of rooms.values()) room.status = 'locked';
  }
  pushState();
}

async function checkAccessStatus() {
  const result = await EntrySettingsFetch.fetchStatus();
  await applyAccessMode(result.accessMode);
  return result;
}

function startStatusPolling() {
  if (statusPollTimer) return;
  statusPollTimer = setInterval(() => {
    checkAccessStatus().catch(() => {});
  }, STATUS_POLL_MS);
}

async function acceptTerms() {
  termsAccepted = true;
  await chrome.storage.local.set({ entryChatTermsAcceptedV1: true });
  scheduleCloudMetaBackup();
  pushState();
  return true;
}

function cloudMetaSnapshot() {
  return {
    format: 'entry-live-studio-encrypted-cloud-backup',
    version: 1,
    identity: { ...identity },
    rooms: automaticBackupRoomList(),
    savedAt: now(),
  };
}

async function saveBackupHealth() {
  try { await chrome.storage.local.set({ entryChatBackupHealthV1: { ...backupHealth } }); } catch (_) {}
}

async function writeCloudMetaBackup() {
  if (!cloudBackupClient || !identity) return false;
  if (cloudMetaPromise) return cloudMetaPromise;
  cloudMetaPromise = (async () => {
    try {
      await cloudBackupClient.saveMeta(cloudMetaSnapshot());
      backupHealth.cloudLastSuccessAt = now();
      backupHealth.cloudLastError = '';
      await saveBackupHealth();
      return true;
    } catch (error) {
      backupHealth.cloudLastError = error?.message || String(error);
      await saveBackupHealth();
      return false;
    } finally {
      cloudMetaPromise = null;
    }
  })();
  return cloudMetaPromise;
}

function scheduleCloudMetaBackup() {
  if (!termsAccepted || !cloudBackupClient || !identity) return;
  if (cloudMetaTimer) clearTimeout(cloudMetaTimer);
  cloudMetaTimer = setTimeout(() => {
    cloudMetaTimer = null;
    writeCloudMetaBackup().catch(() => {});
  }, CLOUD_META_DEBOUNCE_MS);
}

async function saveCloudRecord(record) {
  if (!termsAccepted || !cloudBackupClient) return false;
  try {
    const metaReady = await writeCloudMetaBackup();
    if (!metaReady) return false;
    await cloudBackupClient.saveRecord(record);
    backupHealth.cloudLastSuccessAt = now();
    backupHealth.cloudLastError = '';
    await saveBackupHealth();
    return true;
  } catch (error) {
    backupHealth.cloudLastError = error?.message || String(error);
    await saveBackupHealth();
    return false;
  }
}

async function getRecoveryInfo() {
  let syncCount = 0;
  try { syncCount = await syncEvidenceStore?.count() || 0; } catch (_) {}
  return {
    recoveryCode,
    syncCount,
    backupHealth: { ...backupHealth },
    cloudConfigured: !/CHAT_BACKUP_BUCKET R2 바인딩/.test(backupHealth.cloudLastError || ''),
  };
}

async function setRecoveryCode(nextCode) {
  const normalized = EntryChatBackup.normalizeRecoveryCode(nextCode);
  await EntryChatBackup.deriveMaterials(normalized);
  recoveryCode = normalized;
  syncEvidenceStore = new EntryChatBackup.EntryChatSyncEvidenceStore(recoveryCode);
  cloudBackupClient = new EntryChatBackup.EntryChatCloudBackupClient(recoveryCode);
  cloudMetaPromise = null;
  await chrome.storage.local.set({ entryChatRecoveryCodeV1: recoveryCode });
  scheduleCloudMetaBackup();
}

async function recoverWithCode(code) {
  const normalized = EntryChatBackup.normalizeRecoveryCode(code);
  await EntryChatBackup.deriveMaterials(normalized);
  const tempCloud = new EntryChatBackup.EntryChatCloudBackupClient(normalized);
  const tempSync = new EntryChatBackup.EntryChatSyncEvidenceStore(normalized);
  let cloud = null;
  let cloudError = null;
  let syncRecords = [];

  try { cloud = await tempCloud.readAll(); } catch (error) { cloudError = error; }
  try { syncRecords = await tempSync.loadAllRecords(); } catch (_) {}

  const merged = new Map();
  for (const record of [...(cloud?.records || []), ...syncRecords]) {
    if (!record?.id) continue;
    const current = merged.get(record.id);
    if (!current || Number(record.savedAt || record.at || 0) >= Number(current.savedAt || current.at || 0)) merged.set(record.id, record);
  }
  if (!merged.size && !cloud?.meta) {
    throw cloudError || new Error('이 복구 코드로 찾을 수 있는 백업이 없습니다.');
  }

  const backup = {
    format: 'junwoo-comprehensive-chat-backup',
    version: 1,
    records: [...merged.values()],
    identity: cloud?.meta?.identity || undefined,
    rooms: cloud?.meta?.rooms || [],
  };
  await setRecoveryCode(normalized);
  const result = await importBackup(backup);
  return { ...result, cloudRecords: cloud?.records?.length || 0, syncRecords: syncRecords.length };
}

async function deleteCloudBackup() {
  if (!cloudBackupClient) throw new Error('클라우드 백업을 사용할 수 없습니다.');
  const result = await cloudBackupClient.deleteAll();
  backupHealth.cloudLastError = '';
  await saveBackupHealth();
  return result;
}

async function authenticate(password, requestedName) {
  await ensureReady();
  try { await checkAccessStatus(); } catch (_) {}
  if (accessMode === 1) throw new Error('점검중');
  if (accessMode === 2) throw new Error('사용 불가');
  let config;
  try {
    config = await EntrySettingsFetch.fetchSettings(password);
  } catch (error) {
    if (error?.accessMode === 1 || error?.accessMode === 2) await applyAccessMode(error.accessMode);
    throw error;
  }
  if (requestedName) await setIdentityName(requestedName, false);
  serverConfig = config;
  await chrome.storage.session.set({ entryChatServerConfig: config });
  await connectHub();
  await reconnectSavedRooms();
  scheduleCloudMetaBackup();
  return publicState();
}

async function setIdentityName(name, broadcast = true) {
  identity.name = cleanName(name);
  await chrome.storage.local.set({ entryChatIdentity: identity });
  await durableStore.setKv('identity', identity).catch(() => {});
  markAutomaticBackupDirty();
  for (const room of rooms.values()) {
    const self = room.users.get(identity.id) || selfUser(room);
    self.name = identity.name;
    self.avatarDataUrl = identity.avatarDataUrl || '';
    self.lastSeen = now();
    room.users.set(identity.id, self);
    if (room.isLeader) room.leaderName = identity.name;
  }
  await saveRooms();
  if (broadcast && hub) {
    for (const room of rooms.values()) {
      await announceHello(room);
      if (room.isLeader) await announceMeta(room);
    }
  }
  pushState();
}

async function setProfileImage(imageDataUrl) {
  const clean = imageDataUrl ? cleanImageDataUrl(imageDataUrl, MAX_PROFILE_IMAGE_CHARS) : '';
  identity.avatarDataUrl = clean;
  await chrome.storage.local.set({ entryChatIdentity: identity });
  await Promise.all([
    durableStore.setKv('profileImage', clean).catch(() => {}),
    durableStore.setKv('identity', identity).catch(() => {}),
  ]);
  markAutomaticBackupDirty();
  for (const room of rooms.values()) {
    const self = room.users.get(identity.id) || selfUser(room);
    self.name = identity.name;
    self.avatarDataUrl = clean;
    self.lastSeen = now();
    room.users.set(identity.id, self);
  }
  if (hub) {
    for (const room of rooms.values()) {
      if (room.status === 'locked') continue;
      await announceHello(room);
      if (room.isLeader) await announceMeta(room);
    }
  }
  pushState();
  return publicState();
}

async function createRoom(name) {
  requireOnline();
  const roomName = cleanRoomName(name);
  for (let attempt = 0; attempt < 25; attempt++) {
    const code = String(1000 + Math.floor(Math.random() * 9000));
    if (rooms.has(code)) continue;
    const topic = roomTopic(code);
    await hub.ensureChannel(topic);
    const probe = { kind: 'create', found: null };
    pendingProbes.set(code, probe);
    await hub.send(topic, 'room-probe', { requestId: uid(), from: identity.id, at: now() });
    await sleep(750);
    pendingProbes.delete(code);
    if (probe.found) {
      hub.leave(topic);
      continue;
    }

    const room = makeRoom({
      code,
      name: roomName,
      leaderId: identity.id,
      leaderName: identity.name,
      isLeader: true,
      status: 'online',
    });
    rooms.set(code, room);
    await saveRooms();
    await announceMeta(room);
    await announceHello(room);
    pushState();
    return publicRoom(room);
  }
  throw new Error('사용 가능한 4자리 방 번호를 만들지 못했습니다. 다시 시도하세요.');
}

async function joinRoom(code) {
  requireOnline();
  code = String(code || '').trim();
  if (!validCode(code)) throw new Error('방 번호는 4자리 숫자여야 합니다.');
  if (rooms.has(code)) return publicRoom(rooms.get(code));

  const topic = roomTopic(code);
  await hub.ensureChannel(topic);
  const probe = { kind: 'join', found: null };
  pendingProbes.set(code, probe);
  await hub.send(topic, 'room-probe', { requestId: uid(), from: identity.id, at: now() });
  await sleep(1500);
  pendingProbes.delete(code);

  if (!probe.found) {
    hub.leave(topic);
    throw new Error('현재 연결된 사용자가 없어 이 방을 확인할 수 없습니다. 방 번호를 다시 확인하세요.');
  }

  const meta = probe.found;
  const room = makeRoom({
    code,
    name: cleanRoomName(meta.name || `방 ${code}`),
    leaderId: meta.leaderId || null,
    leaderName: cleanName(meta.leaderName || '대표'),
    isLeader: meta.leaderId === identity.id,
    status: 'online',
  });
  await restoreRoomMessagesFromStore(room);
  rooms.set(code, room);
  if (Array.isArray(meta.users)) {
    for (const user of meta.users) rememberUser(room, user);
  }
  await saveRooms();
  await announceHello(room);
  pushState();
  return publicRoom(room);
}

async function leaveRoom(code) {
  const room = rooms.get(String(code));
  if (!room) return;
  if (hub && room.status !== 'locked') {
    try { await hub.send(roomTopic(room.code), 'bye', { userId: identity.id, at: now() }); } catch (_) {}
    for (const user of room.users.values()) {
      if (user.id !== identity.id) hub.leave(dmTopic(room.code, identity.id, user.id));
    }
    hub.leave(roomTopic(room.code));
  }
  rooms.delete(room.code);
  await saveRooms();
  pushState();
}

async function renameRoom(code, name) {
  const room = rooms.get(String(code));
  if (!room) throw new Error('채팅방을 찾을 수 없습니다.');
  if (!room.isLeader || room.leaderId !== identity.id) throw new Error('방 이름은 대표만 수정할 수 있습니다.');
  room.name = cleanRoomName(name);
  room.leaderName = identity.name;
  await saveRooms();
  await announceMeta(room);
  pushState();
  return publicRoom(room);
}

async function sendChat({ code, targetUserId, text, imageDataUrl, imageName, imageGroupId, imageGroupIndex, imageGroupCount }) {
  requireOnline();
  const room = rooms.get(String(code));
  if (!room) throw new Error('채팅방을 찾을 수 없습니다.');
  text = cleanText(text);
  const image = imageDataUrl ? cleanImageDataUrl(imageDataUrl) : '';
  if (!text && !image) throw new Error('메시지나 사진을 입력하세요.');

  const message = {
    id: uid(),
    roomCode: room.code,
    from: identity.id,
    fromName: identity.name,
    to: targetUserId || null,
    text,
    imageDataUrl: image,
    imageName: cleanImageName(imageName || ''),
    imageGroupId: cleanImageGroupId(imageGroupId || ''),
    imageGroupIndex: cleanImageGroupIndex(imageGroupIndex || 0),
    imageGroupCount: cleanImageGroupCount(imageGroupCount || 0),
    at: now(),
  };

  if (targetUserId) {
    if (targetUserId === identity.id) throw new Error('나와의 채팅을 이용해 주세요.');
    const target = room.users.get(targetUserId);
    if (!target) throw new Error('상대방이 현재 방에 연결되어 있지 않습니다.');
    const topic = dmTopic(room.code, identity.id, targetUserId);
    await hub.ensureChannel(topic);
    await hub.send(topic, 'chat', message);
  } else {
    await hub.send(roomTopic(room.code), 'chat', message);
  }

  addMessage(room, message);
  await persistMessageRecord('room', message);
  pushEvent({ type: 'message', message });
  pushState();
  return message;
}

async function sendSelfChat({ text, imageDataUrl, imageName, imageGroupId, imageGroupIndex, imageGroupCount }) {
  text = cleanText(text);
  const image = imageDataUrl ? cleanImageDataUrl(imageDataUrl) : '';
  if (!text && !image) throw new Error('메모나 사진을 입력하세요.');
  const message = {
    id: uid(),
    roomCode: SELF_ROOM_CODE,
    from: identity.id,
    fromName: identity.name,
    to: identity.id,
    text,
    imageDataUrl: image,
    imageName: cleanImageName(imageName || ''),
    imageGroupId: cleanImageGroupId(imageGroupId || ''),
    imageGroupIndex: cleanImageGroupIndex(imageGroupIndex || 0),
    imageGroupCount: cleanImageGroupCount(imageGroupCount || 0),
    at: now(),
  };
  if (!selfMessages.some((item) => item.id === message.id)) selfMessages.push(message);
  if (selfMessages.length > MAX_MESSAGES) selfMessages.splice(0, selfMessages.length - MAX_MESSAGES);
  await persistMessageRecord('self', message);
  pushState();
  return message;
}

async function persistMessageRecord(scope, message) {
  const record = {
    scope,
    id: message.id,
    roomCode: scope === 'self' ? SELF_ROOM_CODE : message.roomCode,
    from: message.from,
    fromName: message.fromName,
    to: message.to || null,
    text: message.text || '',
    imageDataUrl: message.imageDataUrl || '',
    imageName: message.imageName || '',
    imageGroupId: message.imageGroupId || '',
    imageGroupIndex: Number(message.imageGroupIndex || 0),
    imageGroupCount: Number(message.imageGroupCount || 0),
    at: message.at,
    savedAt: now(),
  };
  await durableStore.putRecord(record);
  if (syncEvidenceStore) {
    try {
      await syncEvidenceStore.putRecord(record);
      backupHealth.syncLastSuccessAt = now();
      backupHealth.syncLastError = '';
      saveBackupHealth().catch(() => {});
    } catch (error) {
      backupHealth.syncLastError = error?.message || String(error);
      saveBackupHealth().catch(() => {});
    }
  }
  // 사진 원본을 포함한 전체 레코드는 복구 코드로 브라우저에서 암호화한 뒤 즉시 클라우드 백업을 시도한다.
  saveCloudRecord(record).catch(() => {});
  markAutomaticBackupDirty();
}


function base64ToBytes(value) {
  const binary = atob(String(value || ''));
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function bytesToBase64(bytes) {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  return btoa(binary);
}

function parseOriginalImageDataUrl(dataUrl) {
  const text = String(dataUrl || '');
  const match = text.match(/^data:(image\/(?:png|jpe?g|webp|gif));base64,([A-Za-z0-9+/=\r\n]+)$/i);
  if (!match) throw new Error('지원하지 않는 원본 이미지 형식입니다.');
  const bytes = base64ToBytes(match[2].replace(/[\r\n]/g, ''));
  if (!bytes.length || bytes.length > MAX_ORIGINAL_IMAGE_BYTES) throw new Error('원본 이미지는 최대 25MB까지 임시 보관할 수 있습니다.');
  return { mime: match[1].toLowerCase(), bytes };
}

async function sha256HexBytes(bytes) {
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
  return [...digest].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

async function tempImageBackupKey() {
  const material = new TextEncoder().encode(`entry-live-studio:temp-image-backup:${recoveryCode}`);
  const raw = await crypto.subtle.digest('SHA-256', material);
  return crypto.subtle.importKey('raw', raw, { name: 'AES-GCM' }, false, ['encrypt']);
}

function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let i = 0; i < 8; i += 1) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function u32be(value) {
  return new Uint8Array([(value >>> 24) & 255, (value >>> 16) & 255, (value >>> 8) & 255, value & 255]);
}

function concatBytes(...parts) {
  const length = parts.reduce((sum, part) => sum + part.length, 0);
  const out = new Uint8Array(length);
  let offset = 0;
  for (const part of parts) { out.set(part, offset); offset += part.length; }
  return out;
}

function pngChunk(type, data) {
  const typeBytes = new TextEncoder().encode(type);
  const crc = crc32(concatBytes(typeBytes, data));
  return concatBytes(u32be(data.length), typeBytes, data, u32be(crc));
}

function encryptedBackupPng(envelope) {
  // 1x1 투명 PNG + 표준 tEXt 청크에 암호문을 저장한다. 호스트에는 원본 이미지가 노출되지 않는다.
  const signature = new Uint8Array([137,80,78,71,13,10,26,10]);
  const ihdr = pngChunk('IHDR', new Uint8Array([0,0,0,1,0,0,0,1,8,6,0,0,0]));
  const idat = pngChunk('IDAT', base64ToBytes('eJxjYAACAAAFAAE='));
  const textPayload = new TextEncoder().encode(`ELSBackup\0${JSON.stringify(envelope)}`);
  const textChunk = pngChunk('tEXt', textPayload);
  const iend = pngChunk('IEND', new Uint8Array());
  return concatBytes(signature, ihdr, idat, textChunk, iend);
}

async function pruneTempImageBackupMeta() {
  try {
    const stored = await chrome.storage.local.get(TEMP_IMAGE_BACKUP_META_KEY);
    const items = Array.isArray(stored?.[TEMP_IMAGE_BACKUP_META_KEY]) ? stored[TEMP_IMAGE_BACKUP_META_KEY] : [];
    const fresh = items.filter((item) => Number(item?.expiresAt || 0) > now()).slice(-120);
    if (fresh.length !== items.length) await chrome.storage.local.set({ [TEMP_IMAGE_BACKUP_META_KEY]: fresh });
    return fresh;
  } catch (_) { return []; }
}

async function backupOriginalImageTemporary({ dataUrl, imageName = '' }) {
  if (!termsAccepted) throw new Error('이용 안내 확인 후 사용할 수 있습니다.');
  const { mime, bytes } = parseOriginalImageDataUrl(dataUrl);
  const key = await tempImageBackupKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, bytes));
  const createdAt = now();
  const expiresAt = createdAt + TEMP_IMAGE_RETENTION_MS;
  const envelope = {
    v: 1,
    alg: 'AES-GCM-256',
    iv: bytesToBase64(iv),
    data: bytesToBase64(encrypted),
    mime,
    originalName: cleanImageName(imageName || ''),
    originalSize: bytes.length,
    sha256: await sha256HexBytes(bytes),
    createdAt,
    expiresAt,
  };
  const carrier = encryptedBackupPng(envelope);
  const form = new FormData();
  form.append('file', new Blob([carrier], { type: 'image/png' }), `els-encrypted-${uid()}.png`);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30000);
  let response;
  try {
    response = await fetch(TEMP_IMAGE_BACKUP_URL, { method: 'POST', body: form, cache: 'no-store', credentials: 'omit', signal: controller.signal });
  } finally { clearTimeout(timer); }
  let result = null;
  try { result = await response.json(); } catch (_) {}
  if (!response.ok || !result?.success || !result?.url) throw new Error(result?.error || `이미지 임시 보관 서버 오류(HTTP ${response.status})`);
  const items = await pruneTempImageBackupMeta();
  items.push({ url: String(result.url), createdAt, expiresAt, sha256: envelope.sha256, originalSize: bytes.length });
  await chrome.storage.local.set({ [TEMP_IMAGE_BACKUP_META_KEY]: items.slice(-120) });
  return { ok: true, expiresAt };
}

async function announceHello(room) {
  if (!hub || room.status === 'locked') return;
  const payload = {
    user: { id: identity.id, name: identity.name, avatarDataUrl: identity.avatarDataUrl || '', isLeader: room.leaderId === identity.id || room.isLeader },
    room: { code: room.code, name: room.name, leaderId: room.leaderId, leaderName: room.leaderName },
    at: now(),
  };
  await hub.send(roomTopic(room.code), 'hello', payload);
}

async function announceMeta(room, targetRequestId = null) {
  if (!hub || room.status === 'locked') return;
  await hub.send(roomTopic(room.code), 'room-meta', {
    requestId: targetRequestId,
    code: room.code,
    name: room.name,
    leaderId: room.leaderId,
    leaderName: room.leaderName,
    users: [...room.users.values()].map((user) => ({ id: user.id, name: user.name, avatarDataUrl: user.avatarDataUrl || '', isLeader: user.isLeader })),
    at: now(),
  });
}

async function ensureDm(room, peerId) {
  if (!hub || !peerId || peerId === identity.id) return;
  try { await hub.ensureChannel(dmTopic(room.code, identity.id, peerId)); } catch (_) {}
}

function rememberUser(room, rawUser) {
  if (!rawUser?.id) return;
  const current = room.users.get(rawUser.id) || {};
  const user = {
    id: rawUser.id,
    name: cleanName(rawUser.name || current.name || '사용자'),
    isLeader: Boolean(rawUser.isLeader || rawUser.id === room.leaderId),
    lastSeen: now(),
    self: rawUser.id === identity.id,
    avatarDataUrl: (() => { try { return cleanImageDataUrl(rawUser.avatarDataUrl || current.avatarDataUrl || '', MAX_PROFILE_IMAGE_CHARS); } catch (_) { return current.avatarDataUrl || ''; } })(),
  };
  room.users.set(user.id, user);
  if (user.id !== identity.id) ensureDm(room, user.id);
}

function handleBroadcast(topic, event, payload) {
  const code = extractRoomCode(topic);
  if (!code) {
    const dm = extractDmCode(topic);
    if (dm && event === 'chat') receiveChat(dm, payload);
    return;
  }

  const room = rooms.get(code);
  const probe = pendingProbes.get(code);

  if (event === 'room-probe') {
    if (room) announceMeta(room, payload?.requestId);
    return;
  }

  if (event === 'room-meta') {
    if (probe) probe.found = payload;
    if (!room) return;
    if (payload?.leaderId) {
      room.leaderId = payload.leaderId;
      room.leaderName = cleanName(payload.leaderName || room.leaderName || '대표');
      room.isLeader = room.leaderId === identity.id;
      if (payload.name) room.name = cleanRoomName(payload.name);
      for (const user of payload.users || []) rememberUser(room, user);
      saveRooms();
      pushState();
    }
    return;
  }

  if (!room) return;
  if (event === 'hello') {
    if (payload.room?.leaderId) {
      room.leaderId = payload.room.leaderId;
      room.leaderName = cleanName(payload.room.leaderName || room.leaderName || '대표');
      room.isLeader = room.leaderId === identity.id;
      if (payload.room.name) room.name = cleanRoomName(payload.room.name);
    }
    rememberUser(room, payload.user);
    saveRooms();
    pushState();
    return;
  }
  if (event === 'bye') {
    if (payload?.userId && payload.userId !== identity.id) room.users.delete(payload.userId);
    pushState();
    return;
  }
  if (event === 'chat') receiveChat(code, payload);
}

function receiveChat(code, message) {
  const room = rooms.get(code);
  if (!room || !message?.id || message.from === identity.id) return;
  if (message.to && message.to !== identity.id) return;
  const added = addMessage(room, message);
  if (added) persistMessageRecord('room', normalizeStoredMessage(message, room.code)).catch(() => {});
  const sender = room.users.get(message.from);
  if (sender) sender.lastSeen = now();
  pushEvent({ type: 'message', message });
  pushState();
}

function addMessage(room, raw) {
  if (room.messages.some((item) => item.id === raw.id)) return false;
  const message = normalizeStoredMessage(raw, room.code);
  room.messages.push(message);
  room.messages.sort((a, b) => a.at - b.at);
  if (room.messages.length > MAX_MESSAGES) room.messages.splice(0, room.messages.length - MAX_MESSAGES);
  return true;
}

function extractRoomCode(topic) {
  const match = String(topic || '').match(/^realtime:els-chat-room-(\d{4})$/);
  return match?.[1] || null;
}

function extractDmCode(topic) {
  const match = String(topic || '').match(/^realtime:els-chat-dm-(\d{4})-/);
  return match?.[1] || null;
}

function requireOnline() {
  if (accessMode === 1) throw new Error('점검중');
  if (accessMode === 2) throw new Error('사용 불가');
  if (!hub || !serverConfig) throw new Error('먼저 연결 비밀번호를 확인하세요.');
}

function automaticBackupRoomList() {
  return [...rooms.values()].map((room) => ({
    code: room.code,
    name: room.name,
    leaderId: room.leaderId,
    leaderName: room.leaderName,
    isLeader: room.isLeader,
  }));
}

async function writeAutomaticBackup() {
  if (!identity || !autoBackupDirty) return false;
  autoBackupDirty = false;
  try {
    const snapshot = await durableStore.exportSnapshot({
      identity: { ...identity },
      rooms: automaticBackupRoomList(),
      automatic: true,
      savedAt: now(),
    });
    await durableStore.setKv('automaticBackupLatest', snapshot);
    await chrome.storage.local.set({ entryChatAutomaticBackupAt: snapshot.savedAt });
    return true;
  } catch (error) {
    autoBackupDirty = true;
    throw error;
  }
}

function markAutomaticBackupDirty() {
  autoBackupDirty = true;
  scheduleCloudMetaBackup();
  if (autoBackupDebounce) clearTimeout(autoBackupDebounce);
  autoBackupDebounce = setTimeout(() => {
    autoBackupDebounce = null;
    writeAutomaticBackup().catch(() => {});
  }, AUTO_BACKUP_DEBOUNCE_MS);
}

function startAutomaticBackup() {
  if (autoBackupTimer) return;
  autoBackupTimer = setInterval(() => {
    if (autoBackupDirty) writeAutomaticBackup().catch(() => {});
  }, AUTO_BACKUP_INTERVAL_MS);
}

function startHeartbeat() {
  if (heartbeatTimer) return;
  heartbeatTimer = setInterval(async () => {
    const cutoff = now() - USER_TTL;
    let changed = false;
    for (const room of rooms.values()) {
      for (const [id, user] of [...room.users]) {
        if (id !== identity.id && user.lastSeen < cutoff) {
          room.users.delete(id);
          changed = true;
        }
      }
      const self = room.users.get(identity.id) || selfUser(room);
      self.lastSeen = now();
      self.name = identity.name;
      self.avatarDataUrl = identity.avatarDataUrl || '';
      room.users.set(identity.id, self);
      if (accessMode === 0 && hub && room.status !== 'locked') {
        try {
          await announceHello(room);
          if (room.isLeader) await announceMeta(room);
        } catch (_) {}
      }
    }
    if (changed) pushState();
  }, HEARTBEAT_MS);
}

function publicRoom(room) {
  return {
    code: room.code,
    name: room.name,
    leaderId: room.leaderId,
    leaderName: room.leaderName,
    isLeader: room.isLeader,
    status: room.status,
    users: [...room.users.values()]
      .map((user) => ({ id: user.id, name: user.name, avatarDataUrl: user.avatarDataUrl || '', isLeader: Boolean(user.isLeader), self: Boolean(user.self), lastSeen: user.lastSeen }))
      .sort((a, b) => Number(b.isLeader) - Number(a.isLeader) || a.name.localeCompare(b.name, 'ko')),
    messages: room.messages.slice(-MAX_MESSAGES),
  };
}

function publicState() {
  const blocked = blockedStatus(accessMode);
  return {
    authenticated: Boolean(accessMode === 0 && serverConfig && hub),
    connectionStatus: blocked || (serverConfig ? socketStatus : 'locked'),
    accessMode,
    accessStatus: blocked || 'normal',
    termsAccepted,
    identity: { ...identity },
    selfMessages: selfMessages.slice(-MAX_MESSAGES),
    backupHealth: { ...backupHealth },
    rooms: [...rooms.values()].map(publicRoom).sort((a, b) => a.name.localeCompare(b.name, 'ko') || a.code.localeCompare(b.code)),
  };
}

function pushState() {
  if (!identity) return;
  const message = { type: 'CHAT_STATE', state: publicState() };
  for (const port of [...ports]) {
    try { port.postMessage(message); } catch (_) { ports.delete(port); }
  }
}

function pushEvent(event) {
  for (const port of [...ports]) {
    try { port.postMessage({ type: 'CHAT_EVENT', event }); } catch (_) { ports.delete(port); }
  }
}

async function exportBackup() {
  const roomList = [...rooms.values()].map((room) => ({
    code: room.code,
    name: room.name,
    leaderId: room.leaderId,
    leaderName: room.leaderName,
    isLeader: room.isLeader,
  }));
  return durableStore.exportSnapshot({
    identity: { ...identity },
    rooms: roomList,
  });
}

async function importBackup(backup) {
  if (!backup || backup.format !== 'junwoo-comprehensive-chat-backup' || Number(backup.version) !== 1) {
    throw new Error('지원하지 않는 채팅 백업 파일입니다.');
  }
  const imported = await durableStore.importRecords(backup.records || []);

  if (backup.identity && typeof backup.identity === 'object') {
    const restoredId = String(backup.identity.id || '').trim();
    if (restoredId && restoredId.length <= 160) identity.id = restoredId;
    identity.name = cleanName(backup.identity.name || identity.name);
    try { identity.avatarDataUrl = cleanImageDataUrl(backup.identity.avatarDataUrl || '', MAX_PROFILE_IMAGE_CHARS); }
    catch (_) { identity.avatarDataUrl = ''; }
    await chrome.storage.local.set({ entryChatIdentity: identity });
    await Promise.all([
      durableStore.setKv('identity', identity).catch(() => {}),
      durableStore.setKv('profileImage', identity.avatarDataUrl || '').catch(() => {}),
    ]);
  }

  try { archiveRecords = await durableStore.loadAllRecords(); } catch (_) { archiveRecords = []; }
  selfMessages = archiveRecords
    .filter((item) => item.scope === 'self')
    .map((item) => normalizeStoredMessage(item, SELF_ROOM_CODE))
    .sort((a, b) => a.at - b.at)
    .slice(-MAX_MESSAGES);

  const currentRooms = [...rooms.values()].map((room) => ({
    code: room.code, name: room.name, leaderId: room.leaderId, leaderName: room.leaderName, isLeader: room.isLeader,
  }));
  const incomingRooms = Array.isArray(backup.rooms) ? backup.rooms : [];
  const mergedRooms = new Map();
  for (const saved of [...currentRooms, ...incomingRooms]) {
    if (!validCode(saved?.code)) continue;
    mergedRooms.set(saved.code, saved);
  }

  if (hub) hub.close();
  hub = null;
  rooms.clear();
  for (const saved of mergedRooms.values()) {
    const leaderId = saved.leaderId || (saved.isLeader ? identity.id : null);
    const room = makeRoom({
      code: saved.code,
      name: cleanRoomName(saved.name || `방 ${saved.code}`),
      leaderId,
      leaderName: cleanName(saved.leaderName || (leaderId === identity.id ? identity.name : '대표')),
      isLeader: leaderId === identity.id || Boolean(saved.isLeader),
      status: serverConfig ? 'connecting' : 'locked',
    });
    restoreRoomMessages(room);
    rooms.set(room.code, room);
  }
  archiveRecords = [];
  await saveRooms();
  if (serverConfig) {
    await connectHub();
    await reconnectSavedRooms();
  }
  markAutomaticBackupDirty();
  pushState();
  return { imported, rooms: rooms.size, selfMessages: selfMessages.length };
}

async function handleCommand(command, payload = {}) {
  await ensureReady();
  switch (command) {
    case 'GET_STATE': return publicState();
    case 'ACCEPT_TERMS': return acceptTerms();
    case 'AUTH': return authenticate(payload.password, payload.name);
    case 'GET_RECOVERY_INFO': return getRecoveryInfo();
    case 'RECOVER_WITH_CODE': return recoverWithCode(payload.recoveryCode);
    case 'DELETE_CLOUD_BACKUP': return deleteCloudBackup();
    case 'SET_NAME': await setIdentityName(payload.name); return publicState();
    case 'SET_PROFILE_IMAGE': return setProfileImage(payload.imageDataUrl || '');
    case 'BACKUP_ORIGINAL_IMAGE_TEMP': return backupOriginalImageTemporary(payload);
    case 'CREATE_ROOM': return createRoom(payload.name);
    case 'JOIN_ROOM': return joinRoom(payload.code);
    case 'LEAVE_ROOM': await leaveRoom(payload.code); return true;
    case 'RENAME_ROOM': return renameRoom(payload.code, payload.name);
    case 'SEND_CHAT': return sendChat(payload);
    case 'SEND_SELF_CHAT': return sendSelfChat(payload);
    case 'EXPORT_BACKUP': return exportBackup();
    case 'IMPORT_BACKUP': return importBackup(payload.backup);
    default: throw new Error(`지원하지 않는 명령입니다: ${command}`);
  }
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'entry-live-chat') return;
  ports.add(port);
  ensureReady().then(() => port.postMessage({ type: 'CHAT_STATE', state: publicState() })).catch(() => {});
  port.onDisconnect.addListener(() => ports.delete(port));
  port.onMessage.addListener(async (message) => {
    if (message?.type !== 'CHAT_COMMAND') return;
    try {
      const result = await handleCommand(message.command, message.payload || {});
      port.postMessage({ type: 'CHAT_RESPONSE', requestId: message.requestId, ok: true, result });
      pushState();
    } catch (error) {
      port.postMessage({ type: 'CHAT_RESPONSE', requestId: message.requestId, ok: false, error: error?.message || String(error) });
    }
  });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== 'ENTRY_CHAT_COMMAND') return;
  handleCommand(message.command, message.payload || {}).then((result) => sendResponse({ ok: true, result })).catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
  return true;
});

chrome.action.onClicked.addListener((tab) => {
  if (!tab?.id) return;
  chrome.tabs.sendMessage(tab.id, { type: 'ENTRY_CHAT_TOGGLE' }).catch(() => {});
});

ensureReady().catch(() => {});
