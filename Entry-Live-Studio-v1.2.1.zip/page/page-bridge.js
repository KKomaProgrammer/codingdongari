(function () {
  if (window.__ENTRY_LIVE_STUDIO_BRIDGE__) return;
  window.__ENTRY_LIVE_STUDIO_BRIDGE__ = true;

  const REQUEST = 'ENTRY_LIVE_STUDIO_REQUEST';
  const RESPONSE = 'ENTRY_LIVE_STUDIO_RESPONSE';
  let renderBoard = null;
  let renderCode = null;
  let renderHost = null;

  function waitForEntry(timeout = 30000) {
    const started = Date.now();
    return new Promise((resolve, reject) => {
      const check = () => {
        if (
          window.Entry?.container?.getAllObjects &&
          window.Entry?.playground &&
          window.Entry?.getMainWS?.()?.getBoard
        ) {
          resolve(window.Entry);
        } else if (Date.now() - started > timeout) {
          reject(new Error('엔트리 편집기가 준비되지 않았습니다.'));
        } else {
          setTimeout(check, 250);
        }
      };
      check();
    });
  }

  function clonePlain(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function parseScript(script) {
    if (Array.isArray(script)) return clonePlain(script);
    if (typeof script === 'string') {
      try { return JSON.parse(script); } catch (_) { return []; }
    }
    return [];
  }

  function summary(Entry) {
    const selected = Entry.container.selectedObject || Entry.playground.object;
    const selectedScript = selected?.script?.stringify?.() || '';
    let selectedCodeSignature = 2166136261;
    for (let i = 0; i < selectedScript.length; i++) {
      selectedCodeSignature ^= selectedScript.charCodeAt(i);
      selectedCodeSignature = Math.imul(selectedCodeSignature, 16777619);
    }
    const objects = Entry.container.getAllObjects().map((object) => ({
      id: object.id,
      name: object.name,
      blockCount: object.script?.countBlock?.() || 0,
      selected: object.id === Entry.container.selectedObject?.id,
    }));
    return {
      ready: true,
      projectId: Entry.projectId || location.pathname.split('/').pop(),
      selectedObjectId: Entry.container.selectedObject?.id || Entry.playground.object?.id || null,
      selectedCodeSignature: (selectedCodeSignature >>> 0).toString(36),
      objects,
    };
  }

  function freshCodeForScope(Entry, objectId, scope) {
    const object = Entry.container.getObject(objectId) || Entry.container.selectedObject;
    if (!object) throw new Error('보낼 오브젝트를 선택해 주세요.');
    const workspace = Entry.getMainWS();
    const selected = workspace?.selectedBlockView?.block;
    let code;
    if (scope === 'thread' || scope === 'below') {
      if (!selected?.thread || selected.getCode?.() !== object.script) {
        throw new Error('해당 오브젝트에서 블록을 먼저 선택해 주세요.');
      }
      if (scope === 'below') code = [selected.thread.toJSON(true, selected)];
      else code = [selected.thread.toJSON(true)];
    } else {
      code = object.script.getThreads().map((thread) => thread.toJSON(true));
    }
    return { objectId: object.id, objectName: object.name, scope, code: clonePlain(code) };
  }

  function ensureRenderer(Entry) {
    if (renderBoard && renderHost?.isConnected) return;
    renderHost = document.createElement('div');
    renderHost.id = 'entry-live-studio-renderer';
    Object.assign(renderHost.style, {
      position: 'fixed',
      left: '-10000px',
      top: '0',
      width: '1800px',
      height: '1400px',
      overflow: 'hidden',
      pointerEvents: 'none',
      opacity: '0.01',
      zIndex: '-1',
    });
    document.documentElement.appendChild(renderHost);
    renderBoard = new Entry.Board({
      dom: renderHost,
      workspace: Entry.getMainWS(),
      readOnly: true,
      scale: 1,
    });
    const mainBoard = Entry.getMainWS?.()?.getBoard?.();
    if (mainBoard?.svgDom) Entry.Utils.setSVGDom(mainBoard.svgDom);
  }

  function inlineSvgStyles(original, clone) {
    const properties = [
      'fill', 'fill-opacity', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin',
      'stroke-opacity', 'opacity', 'display', 'visibility', 'font-family', 'font-size',
      'font-style', 'font-weight', 'letter-spacing', 'text-anchor', 'dominant-baseline',
    ];
    const originals = [original, ...original.querySelectorAll('*')];
    const clones = [clone, ...clone.querySelectorAll('*')];
    originals.forEach((node, index) => {
      const target = clones[index];
      if (!target) return;
      const style = getComputedStyle(node);
      for (const property of properties) {
        const value = style.getPropertyValue(property);
        if (value) target.style.setProperty(property, value);
      }
    });
  }

  async function renderCodeSvg(Entry, code) {
    ensureRenderer(Entry);
    renderCode?.destroyView?.();
    renderCode = new Entry.Code(parseScript(code));
    renderBoard.changeCode(renderCode);
    await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    try { renderBoard.alignThreads(); } catch (_) {}
    await new Promise((resolve) => setTimeout(resolve, 40));

    const svg = renderBoard.svgDom?.[0] || renderHost.querySelector('svg');
    const content = renderBoard.svgBlockGroup || svg?.querySelector('.svgBlockGroup');
    if (!svg || !content) return null;
    let box;
    try { box = content.getBBox(); } catch (_) { box = { x: 0, y: 0, width: 900, height: 650 }; }
    const padding = 8;
    const width = Math.max(1, Math.ceil(box.width + padding * 2));
    const height = Math.max(1, Math.ceil(box.height + padding * 2));
    const clone = svg.cloneNode(true);
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    clone.setAttribute('xmlns:xlink', 'http://www.w3.org/1999/xlink');
    clone.setAttribute('viewBox', `${box.x - padding} ${box.y - padding} ${width} ${height}`);
    clone.setAttribute('width', String(width));
    clone.setAttribute('height', String(height));
    clone.style.background = 'transparent';
    inlineSvgStyles(svg, clone);
    const xml = new XMLSerializer().serializeToString(clone);
    return {
      dataUrl: `data:image/svg+xml;charset=utf-8,${encodeURIComponent(xml)}`,
      width,
      height,
    };
  }

  async function codeView(Entry, objectId) {
    const object = Entry.container.getObject(objectId) || Entry.container.selectedObject;
    if (!object) throw new Error('오브젝트가 없습니다.');
    const code = object.script.toJSON();
    const image = await renderCodeSvg(Entry, code);
    return {
      objectId: object.id,
      objectName: object.name,
      code: clonePlain(code),
      image,
      blockCount: object.script.countBlock?.() || 0,
    };
  }

  function codeData(Entry, objectId) {
    const object = Entry.container.getObject(objectId) || Entry.container.selectedObject;
    if (!object) throw new Error('오브젝트가 없습니다.');
    return {
      objectId: object.id,
      objectName: object.name,
      code: clonePlain(object.script.toJSON()),
      image: null,
      blockCount: object.script.countBlock?.() || 0,
    };
  }

  function offsetThreads(code, amount) {
    const copy = clonePlain(parseScript(code));
    copy.forEach((thread, index) => {
      const first = thread?.[0];
      if (!first || typeof first !== 'object') return;
      first.x = (Number(first.x) || 20) + amount + index * 10;
      first.y = (Number(first.y) || 20) + amount + index * 10;
    });
    return copy;
  }

  function collectScalarStrings(value, output = new Set()) {
    if (typeof value === 'string') {
      output.add(value);
      return output;
    }
    if (Array.isArray(value)) {
      value.forEach((item) => collectScalarStrings(item, output));
      return output;
    }
    if (value && typeof value === 'object') {
      Object.values(value).forEach((item) => collectScalarStrings(item, output));
    }
    return output;
  }

  function modelIds(model) {
    if (!model || typeof model !== 'object') return [];
    return [model.id, model._id, model.variableId, model.messageId, model.functionId, model.tableId]
      .filter((value) => typeof value === 'string' && value);
  }

  function dependencyBundle(Entry, code) {
    const refs = collectScalarStrings(code);
    const project = Entry.exportProject({}) || {};
    const pick = (items) => (Array.isArray(items) ? items : []).filter((item) =>
      modelIds(item).some((id) => refs.has(id))
    );
    return {
      variables: pick(project.variables),
      messages: pick(project.messages),
      functions: pick(project.functions),
      tables: pick(project.tables),
    };
  }

  function applyDependencies(Entry, dependencies) {
    if (!dependencies) return { added: 0 };
    let added = 0;
    Entry.stateManager?.startIgnore?.();
    try {
      const variableContainer = Entry.variableContainer;
      const existingVariables = variableContainer.getVariableJSON?.() || [];
      const variableIds = new Set(existingVariables.flatMap(modelIds));
      const missingVariables = (dependencies.variables || []).filter(
        (item) => !modelIds(item).some((id) => variableIds.has(id))
      );
      if (missingVariables.length) {
        variableContainer.setVariables(clonePlain(missingVariables), {});
        added += missingVariables.length;
      }

      const existingMessages = variableContainer.getMessageJSON?.() || [];
      const messageIds = new Set(existingMessages.flatMap(modelIds));
      const missingMessages = (dependencies.messages || []).filter(
        (item) => !modelIds(item).some((id) => messageIds.has(id))
      );
      if (missingMessages.length) {
        variableContainer.setMessages([...clonePlain(existingMessages), ...clonePlain(missingMessages)]);
        added += missingMessages.length;
      }

      const existingFunctions = variableContainer.getFunctionJSON?.() || [];
      const functionIds = new Set(existingFunctions.flatMap(modelIds));
      const missingFunctions = (dependencies.functions || []).filter(
        (item) => !modelIds(item).some((id) => functionIds.has(id))
      );
      if (missingFunctions.length) {
        variableContainer.setFunctions(clonePlain(missingFunctions));
        added += missingFunctions.length;
      }

      const existingTables = Entry.DataTable?.getTableJSON?.() || [];
      const tableIds = new Set(existingTables.flatMap(modelIds));
      const missingTables = (dependencies.tables || []).filter(
        (item) => !modelIds(item).some((id) => tableIds.has(id))
      );
      if (missingTables.length && Entry.DataTable?.addSources) {
        Entry.DataTable.addSources(clonePlain(missingTables));
        added += missingTables.length;
      }

      variableContainer.updateViews?.();
      variableContainer.updateList?.();
      Entry.Utils?.doCodeChange?.();
    } finally {
      Entry.stateManager?.endIgnore?.();
    }
    return { added };
  }

  async function sourceCodePackage(Entry, objectId, scope) {
    const source = freshCodeForScope(Entry, objectId, scope);
    return {
      ...source,
      dependencies: dependencyBundle(Entry, source.code),
      image: await renderCodeSvg(Entry, source.code),
    };
  }

  function applyCode(Entry, payload) {
    if (!Entry.engine.isState('stop')) Entry.engine.toggleStop();
    const dependencyResult = applyDependencies(Entry, payload.dependencies);
    let targetObject = null;
    const code = offsetThreads(payload.code, 24 + Math.floor(Math.random() * 30));
    if (payload.targetMode === 'new') {
      const base =
        Entry.container.getObject(payload.baseObjectId) ||
        Entry.container.selectedObject ||
        Entry.container.getAllObjects()[0];
      if (!base) throw new Error('복제할 기본 오브젝트가 없습니다.');
      const model = base.toJSON(true);
      model.name = payload.newObjectName || `${payload.sourceName || '받은 코드'} 작업`;
      model.script = code;
      Entry.container.addObject(model);
      targetObject = Entry.container.selectedObject;
    } else {
      targetObject =
        Entry.container.getObject(payload.targetObjectId) || Entry.container.selectedObject;
      if (!targetObject) throw new Error('코드를 받을 오브젝트를 선택해 주세요.');
      Entry.container.selectObject(targetObject.id);
      Entry.do('addThreads', code).isPass(false);
      Entry.Utils?.doCodeChange?.();
    }
    return { objectId: targetObject?.id, objectName: targetObject?.name, dependenciesAdded: dependencyResult.added };
  }

  function getFullProject(Entry) {
    const project = Entry.exportProject({});
    if (!project) throw new Error('작품을 내보낼 수 없습니다.');
    return clonePlain(project);
  }

  function getCollabSnapshot(Entry) {
    const objects = Entry.container.toJSON().map((object) => ({
      ...object,
      script: parseScript(object.script),
    }));
    return {
      objects,
      selectedObjectId: Entry.container.selectedObject?.id || null,
      globals: {
        variables: Entry.variableContainer.getVariableJSON?.() || [],
        messages: Entry.variableContainer.getMessageJSON?.() || [],
        functions: Entry.variableContainer.getFunctionJSON?.() || [],
        scenes: Entry.scene.toJSON?.() || [],
        speed: Entry.FPS || 60,
        expansionBlocks: Entry.expansionBlocks || [],
        aiUtilizeBlocks: Entry.aiUtilizeBlocks || [],
        hardwareLiteBlocks: Entry.hardwareLiteBlocks || [],
      },
    };
  }

  function applyObjectSnapshot(Entry, model) {
    if (!model?.id) return false;
    if (!Entry.engine.isState('stop')) Entry.engine.toggleStop();
    const existing = Entry.container.getObject(model.id);
    if (!existing) {
      Entry.container.addObject({ ...clonePlain(model), script: parseScript(model.script) });
      return true;
    }

    const wasSelected = existing.id === Entry.container.selectedObject?.id;
    const code = parseScript(model.script);
    existing.script.destroyView?.();
    existing.script.load(code);
    existing.setName?.(model.name || existing.name);
    if (typeof model.text === 'string') existing.setText?.(model.text);
    if (typeof model.lock === 'boolean') existing.setLock?.(model.lock);
    if (model.rotateMethod) existing.setRotateMethod?.(model.rotateMethod);
    if (model.selectedPictureId) {
      const picture = existing.getPicture?.(model.selectedPictureId);
      if (picture) existing.selectedPicture = picture;
    }
    if (model.entity && existing.entity?.injectModel) {
      try { existing.entity.injectModel(existing.selectedPicture || null, clonePlain(model.entity)); } catch (_) {}
    }
    if (wasSelected) {
      Entry.playground.object = existing;
      Entry.playground.injectCode();
      existing.updateCoordinateView?.();
    }
    Entry.Utils?.doCodeChange?.();
    return true;
  }

  function removeObject(Entry, objectId) {
    if (!Entry.container.getObject(objectId)) return false;
    Entry.do('removeObject', objectId).isPass(false);
    return true;
  }

  function applyGlobals(Entry, globals) {
    if (!globals) return false;
    Entry.stateManager?.startIgnore?.();
    try {
      if (globals.variables) Entry.variableContainer.setVariables(globals.variables, {});
      if (globals.messages) Entry.variableContainer.setMessages(globals.messages);
      if (globals.functions) Entry.variableContainer.setFunctions(globals.functions);
      if (Number.isFinite(globals.speed)) Entry.FPS = globals.speed;
      if (globals.expansionBlocks) Entry.expansionBlocks = clonePlain(globals.expansionBlocks);
      if (globals.aiUtilizeBlocks) Entry.aiUtilizeBlocks = clonePlain(globals.aiUtilizeBlocks);
      if (globals.hardwareLiteBlocks) Entry.hardwareLiteBlocks = clonePlain(globals.hardwareLiteBlocks);
      Entry.variableContainer.updateViews?.();
      Entry.variableContainer.updateList?.();
      Entry.Utils?.doCodeChange?.();
    } finally {
      Entry.stateManager?.endIgnore?.();
    }
    return true;
  }

  async function execute(action, payload = {}) {
    const Entry = await waitForEntry();
    switch (action) {
      case 'PING': return { ready: true };
      case 'GET_SUMMARY': return summary(Entry);
      case 'GET_CODE_VIEW': return codeView(Entry, payload.objectId);
      case 'GET_CODE_DATA': return codeData(Entry, payload.objectId);
      case 'GET_SOURCE_CODE': return sourceCodePackage(Entry, payload.objectId, payload.scope || 'object');
      case 'GET_CONTEXT_CODE': {
        const object = Entry.container.selectedObject || Entry.playground.object;
        return sourceCodePackage(Entry, object?.id, 'thread');
      }
      case 'RENDER_CODE': return renderCodeSvg(Entry, payload.code);
      case 'APPLY_CODE': return applyCode(Entry, payload);
      case 'GET_FULL_PROJECT': return getFullProject(Entry);
      case 'APPLY_FULL_PROJECT':
        Entry.clearProject();
        Entry.loadProject(clonePlain(payload.project));
        return true;
      case 'GET_COLLAB_SNAPSHOT': return getCollabSnapshot(Entry);
      case 'APPLY_OBJECT': return applyObjectSnapshot(Entry, clonePlain(payload.object));
      case 'REMOVE_OBJECT': return removeObject(Entry, payload.objectId);
      case 'APPLY_GLOBALS': return applyGlobals(Entry, clonePlain(payload.globals));
      default: throw new Error(`지원하지 않는 요청: ${action}`);
    }
  }

  window.addEventListener('message', async (event) => {
    if (event.source !== window || event.data?.source !== REQUEST) return;
    const { requestId, action, payload } = event.data;
    try {
      const result = await execute(action, payload);
      window.postMessage({ source: RESPONSE, requestId, ok: true, result }, '*');
    } catch (error) {
      window.postMessage(
        { source: RESPONSE, requestId, ok: false, error: error?.message || String(error) },
        '*'
      );
    }
  });
})();
