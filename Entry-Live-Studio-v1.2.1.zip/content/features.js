(function () {
  if (globalThis.__ENTRY_LIVE_STUDIO_FEATURES__) return;
  globalThis.__ENTRY_LIVE_STUDIO_FEATURES__ = true;

  const studio = globalThis.__entryLiveStudio;
  if (!studio) return;

  const esc = (value) => String(value ?? '').replace(/[&<>'"]/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;',
  })[c]);
  const randomId = () => crypto.randomUUID?.() || `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`;

  const original = {
    start: studio.start.bind(studio),
    refreshOwnSummary: studio.refreshOwnSummary.bind(studio),
    onData: studio.onData.bind(studio),
    onBusEvent: studio.onBusEvent.bind(studio),
    onPeerState: studio.onPeerState.bind(studio),
    handleCommand: studio.handleCommand.bind(studio),
    publicState: studio.publicState.bind(studio),
    captureFrame: studio.captureFrame.bind(studio),
    unmountUi: studio.unmountUi.bind(studio),
    patchCodePreview: studio.patchCodePreview.bind(studio),
  };

  function initFeatureState() {
    studio.chatMessages ||= [];
    studio.chatUnread ||= 0;
    studio.chatOpen ||= false;
    studio.chatCooldownMs = Math.max(0, Number(studio.chatCooldownMs ?? studio.config?.chatCooldownMs ?? 3000));
    studio.lastChatSentAt ||= 0;
    studio.chatLastByUser ||= new Map();
    studio.participantPolicies ||= new Map();
    studio.peerChatAllowed = Boolean(studio.peerChatAllowed);
    studio.announcement ||= null;
    studio.viewerOverride ||= null;
    studio.codeShares ||= new Map();
    studio.codeShareOrder ||= [];
    studio.lastCodeDelivery ||= null;
    studio.chatPos ||= { x: null, y: null };
    studio.activeChatRoom ||= null;
    studio.pendingContextCode ||= null;
    studio.viewerFrameAspect ||= 16 / 9;
    studio.featureTimer ||= null;
    studio.chatPeers ||= [];
  }

  function participantName(id) {
    if (id === studio.userId) return studio.config?.name || '나';
    if (id === studio.leaderId) return studio.role === 'leader' ? (studio.config?.name || '관리자') : '관리자';
    return studio.participants.get(id)?.name || '참여자';
  }

  const leaderConversation = (participantId) => `leader:${participantId}`;
  const peerConversation = (a, b) => `peer:${[a, b].sort().join(':')}`;

  function formatDuration(ms) {
    const total = Math.max(0, Math.floor(Number(ms || 0) / 1000));
    const hours = Math.floor(total / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const seconds = total % 60;
    return hours > 0
      ? `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`
      : `${minutes}:${String(seconds).padStart(2, '0')}`;
  }

  function conversationForIncoming(message) {
    return message?.conversationId || (message?.targetLabel === '모두' ? 'all' : 'all');
  }

  function policyFor(userId) {
    const saved = studio.participantPolicies.get(userId) || {};
    return {
      peerChatAllowed: Boolean(saved.peerChatAllowed),
      cooldownMs: Math.max(0, Number(saved.cooldownMs ?? studio.chatCooldownMs ?? 3000)),
    };
  }

  function sendPolicy(userId) {
    if (studio.role !== 'leader' || !userId) return;
    const peers = [...studio.participants.values()]
      .filter((item) => item.id && item.id !== userId && item.id !== studio.leaderId)
      .map((item) => ({ id: item.id, name: item.name || '참여자', peerState: item.peerState || 'connecting' }));
    studio.sendTo(userId, { type: 'CHAT_POLICY', policy: policyFor(userId), peers });
  }

  function pushChat(message, { unread = true } = {}) {
    initFeatureState();
    if (!message?.conversationId) message.conversationId = 'all';
    studio.chatMessages.push(message);
    if (studio.chatMessages.length > 180) studio.chatMessages.splice(0, studio.chatMessages.length - 180);
    const visibleRoom = studio.chatOpen && studio.activeChatRoom === conversationForIncoming(message);
    if (unread && message.from !== studio.userId && !visibleRoom) studio.chatUnread += 1;
    patchFeatureUi();
    studio.notifyUiEvent?.({ type: 'chat', message, unread: studio.chatUnread });
    studio.notifyState?.();
  }

  function makeTextMessage({ from, text, targetLabel = '', kind = 'text', dataUrl = '', title = '', conversationId = 'all', toUserIds = [] }) {
    return {
      id: randomId(), from, fromName: participantName(from), text: String(text || '').slice(0, 2000),
      targetLabel, kind, dataUrl, title, conversationId, toUserIds: [...new Set(toUserIds.filter(Boolean))], at: Date.now(),
    };
  }

  async function leaderHandleParticipantChat(from, packet) {
    const policy = policyFor(from);
    const now = Date.now();
    const previous = studio.chatLastByUser.get(from) || 0;
    if (policy.cooldownMs && now - previous < policy.cooldownMs) {
      studio.sendTo(from, { type: 'CHAT_REJECT', remainingMs: policy.cooldownMs - (now - previous) });
      return;
    }
    studio.chatLastByUser.set(from, now);

    const requestedTarget = packet.targetUserId || (packet.targetMode === 'all' ? 'all' : studio.leaderId);
    if (requestedTarget === 'all') {
      if (!policy.peerChatAllowed) {
        studio.sendTo(from, { type: 'CHAT_REJECT', message: '참가자 간 대화가 허용되지 않았습니다.' });
        return;
      }
      const targets = studio.peerIds().filter((id) => id !== from);
      const message = makeTextMessage({ from, text: packet.text, targetLabel: '모두', conversationId: 'all', toUserIds: targets });
      pushChat(message);
      for (const id of targets) studio.sendTo(id, { type: 'CHAT_MESSAGE', message });
      return;
    }

    if (requestedTarget && requestedTarget !== studio.leaderId) {
      if (!policy.peerChatAllowed) {
        studio.sendTo(from, { type: 'CHAT_REJECT', message: '참가자 간 대화가 허용되지 않았습니다.' });
        return;
      }
      if (!studio.participants.has(requestedTarget)) {
        studio.sendTo(from, { type: 'CHAT_REJECT', message: '선택한 참가자가 연결되어 있지 않습니다.' });
        return;
      }
      const message = makeTextMessage({
        from, text: packet.text, targetLabel: participantName(requestedTarget),
        conversationId: peerConversation(from, requestedTarget), toUserIds: [requestedTarget],
      });
      studio.sendTo(requestedTarget, { type: 'CHAT_MESSAGE', message });
      return;
    }

    const message = makeTextMessage({
      from, text: packet.text, targetLabel: '관리자',
      conversationId: leaderConversation(from), toUserIds: [studio.leaderId],
    });
    pushChat(message);
  }

  async function sendChat(payload) {
    initFeatureState();
    const text = String(payload.text || '').trim();
    if (!text) throw new Error('메시지를 입력해 주세요.');
    if (studio.mode !== 'mode1') throw new Error('대표 송출 모드에서 사용할 수 있습니다.');

    if (studio.role === 'leader') {
      const room = String(payload.conversationId || 'all');
      if (room === 'all') {
        const userIds = studio.peerIds();
        const message = makeTextMessage({ from: studio.userId, text, targetLabel: '모두', conversationId: 'all', toUserIds: userIds });
        pushChat(message, { unread: false });
        for (const id of userIds) studio.sendTo(id, { type: 'CHAT_MESSAGE', message });
        return { count: userIds.length };
      }
      const match = /^leader:(.+)$/.exec(room);
      const userId = match?.[1] || (Array.isArray(payload.userIds) ? payload.userIds[0] : null);
      if (!userId) throw new Error('대화 상대를 선택해 주세요.');
      const message = makeTextMessage({
        from: studio.userId, text, targetLabel: participantName(userId),
        conversationId: leaderConversation(userId), toUserIds: [userId],
      });
      pushChat(message, { unread: false });
      studio.sendTo(userId, { type: 'CHAT_MESSAGE', message });
      return { count: 1 };
    }

    const now = Date.now();
    if (studio.chatCooldownMs && now - studio.lastChatSentAt < studio.chatCooldownMs) {
      const sec = Math.ceil((studio.chatCooldownMs - (now - studio.lastChatSentAt)) / 1000);
      throw new Error(`${sec}초 후 다시 보낼 수 있습니다.`);
    }
    studio.lastChatSentAt = now;
    const targetUserId = payload.targetUserId || studio.leaderId;
    let conversationId;
    let targetLabel;
    if (targetUserId === 'all') {
      if (!studio.peerChatAllowed) throw new Error('참가자 간 대화가 허용되지 않았습니다.');
      conversationId = 'all'; targetLabel = '모두';
    } else if (targetUserId === studio.leaderId) {
      conversationId = leaderConversation(studio.userId); targetLabel = '관리자';
    } else {
      if (!studio.peerChatAllowed) throw new Error('참가자 간 대화가 허용되지 않았습니다.');
      conversationId = peerConversation(studio.userId, targetUserId); targetLabel = participantName(targetUserId);
    }
    const local = makeTextMessage({ from: studio.userId, text, targetLabel, conversationId, toUserIds: targetUserId === 'all' ? studio.peerIds() : [targetUserId] });
    pushChat(local, { unread: false });
    studio.sendTo(studio.leaderId, { type: 'CHAT_SEND', text, targetUserId, targetMode: targetUserId === 'all' ? 'all' : 'direct' });
    return { count: 1 };
  }

  studio.start = async function patchedStart(config) {
    this.chatMessages = [];
    this.chatUnread = 0;
    this.chatOpen = false;
    this.participantPolicies = new Map();
    this.peerChatAllowed = false;
    this.chatCooldownMs = Math.max(0, Number(config?.chatCooldownMs ?? 3000));
    this.announcement = null;
    this.viewerOverride = null;
    this.codeShares = new Map();
    this.codeShareOrder = [];
    this.lastCodeDelivery = null;
    this.activeChatRoom = null;
    this.pendingContextCode = null;
    this.chatPeers = [];
    const result = await original.start(config);
    if (this.role === 'leader' && this.screenEnabled) this.screenShareStartedAt ||= Date.now();
    initFeatureState();
    installContextMenuObserver();
    patchFeatureUi();
    return this.publicState();
  };

  studio.refreshOwnSummary = async function patchedRefreshOwnSummary(forceCode) {
    if (this.mode === 'mode1' && this.role !== 'leader') return;
    return original.refreshOwnSummary(forceCode);
  };

  studio.captureFrame = async function flickerFreeCapture() {
    if (!this.active || this.mode !== 'mode1' || this.role !== 'leader' || !this.screenEnabled || this.captureBusy) return;
    // tabCapture/offscreen already streams frames. Do not take a second visible screenshot.
    if (this.config.captureBackend === 'tab') return;
    if (!this.peerIds().length) return;
    this.captureBusy = true;
    try {
      const result = await chrome.runtime.sendMessage({
        type: 'ENTRY_LIVE_CAPTURE', quality: this.config.captureQuality,
      });
      if (result?.ok && result.dataUrl) {
        this.latestFrames.screen = result.dataUrl;
        this.sendAll({ type: 'SCREEN_FRAME', dataUrl: result.dataUrl, stamp: Date.now(), startedAt: this.screenShareStartedAt || this.startedAt });
        this.notifyUiEvent({ type: 'leader-screen', dataUrl: result.dataUrl });
      }
    } finally {
      this.captureBusy = false;
    }
  };

  studio.onBusEvent = async function patchedBusEvent(event, payload, sender) {
    const result = await original.onBusEvent(event, payload, sender);
    if (event === 'hello' && this.role === 'leader' && payload?.user?.id && payload.user.id !== this.userId) {
      for (const id of this.peerIds()) sendPolicy(id);
      this.sendTo(payload.user.id, { type: 'SCREEN_STATUS', enabled: this.screenEnabled, startedAt: this.screenShareStartedAt });
      if (this.announcement?.text) this.sendTo(payload.user.id, { type: 'ANNOUNCEMENT', announcement: this.announcement });
    }
    return result;
  };

  studio.onPeerState = function patchedPeerState(peerId, state) {
    const result = original.onPeerState(peerId, state);
    if (this.role === 'leader') {
      for (const id of this.peerIds()) sendPolicy(id);
      if (state === 'connected') this.sendTo(peerId, { type: 'SCREEN_STATUS', enabled: this.screenEnabled, startedAt: this.screenShareStartedAt });
    }
    patchFeatureUi();
    return result;
  };

  studio.onData = async function patchedOnData(from, packet) {
    initFeatureState();
    if (!packet?.type) return;
    switch (packet.type) {
      case 'CHAT_SEND':
        if (this.role === 'leader') await leaderHandleParticipantChat(from, packet);
        return;
      case 'CHAT_MESSAGE':
        pushChat(packet.message || makeTextMessage({ from, text: packet.text }));
        return;
      case 'CHAT_REJECT':
        this.setNotice(packet.message || `${Math.max(1, Math.ceil((packet.remainingMs || 0) / 1000))}초 후 다시 보낼 수 있습니다.`, 'error');
        return;
      case 'CHAT_POLICY':
        this.peerChatAllowed = Boolean(packet.policy?.peerChatAllowed);
        this.chatCooldownMs = Math.max(0, Number(packet.policy?.cooldownMs ?? this.chatCooldownMs));
        this.chatPeers = Array.isArray(packet.peers) ? packet.peers : [];
        patchFeatureUi();
        this.notifyState();
        return;
      case 'ANNOUNCEMENT':
        this.announcement = packet.announcement || null;
        patchFeatureUi();
        this.notifyUiEvent({ type: 'announcement', announcement: this.announcement });
        this.notifyState();
        return;
      case 'PARTICIPANT_CODE_SHARE': {
        if (this.role !== 'leader') return;
        const share = {
          id: packet.shareId || randomId(), from, fromName: participantName(from),
          sourceName: packet.sourceName || '전송한 코드', code: packet.code || [], dependencies: packet.dependencies || {},
          image: packet.image || null, at: Date.now(),
        };
        this.codeShares.set(share.id, share);
        this.codeShareOrder.unshift(share.id);
        this.codeShareOrder.splice(40);
        const message = makeTextMessage({
          from, text: '관리자에게 코드를 전송했습니다.', kind: 'code', dataUrl: share.image?.dataUrl || '', title: share.sourceName,
          conversationId: leaderConversation(from), toUserIds: [this.leaderId],
        });
        message.shareId = share.id;
        pushChat(message);
        this.notifyUiEvent({ type: 'code-share', share: { ...share, code: undefined, dependencies: undefined } });
        return;
      }
      case 'MANAGER_MEDIA': {
        const message = packet.message || makeTextMessage({
          from, text: packet.note || (packet.route === 'chat' ? '관리자가 이미지를 보냈습니다.' : '관리자가 표시 화면을 보냈습니다.'),
          kind: 'image', dataUrl: packet.dataUrl || '', title: packet.title || '관리자 이미지',
          conversationId: leaderConversation(this.userId), toUserIds: [this.userId],
        });
        if (packet.route === 'chat') {
          pushChat(message);
        } else {
          this.viewerOverride = { dataUrl: packet.dataUrl, title: packet.title || '관리자 표시', at: Date.now() };
          this.chatUnread += 1;
          loadFeatureViewer(packet.dataUrl);
          patchFeatureUi();
          this.notifyState();
        }
        return;
      }
      case 'PROJECT_EXPORT_REQUEST': {
        if (this.role === 'leader') return;
        try {
          const project = await this.bridge('GET_FULL_PROJECT', {}, 60000);
          this.sendTo(from, { type: 'PROJECT_EXPORT_RESPONSE', requestId: packet.requestId, project, projectName: this.config?.name || '참여자' });
        } catch (error) {
          this.sendTo(from, { type: 'PROJECT_EXPORT_RESPONSE', requestId: packet.requestId, error: error?.message || String(error) });
        }
        return;
      }
      case 'PROJECT_EXPORT_RESPONSE':
        if (this.role === 'leader') {
          this.notifyUiEvent({
            type: 'participant-project', requestId: packet.requestId, from, fromName: participantName(from),
            project: packet.project || null, projectName: packet.projectName || participantName(from), error: packet.error || '',
          });
        }
        return;
    }

    const result = await original.onData(from, packet);
    if (packet.type === 'APPLY_CODE' && from === this.leaderId) {
      const preview = packet.payload?.preview || null;
      this.lastCodeDelivery = {
        image: preview, sourceName: packet.payload?.sourceName || '관리자 코드', at: Date.now(),
      };
      this.chatUnread += 1;
      const msg = makeTextMessage({
        from, text: '관리자가 코드를 전송했습니다. 코드가 작품에 적용되었습니다.',
        kind: 'code', dataUrl: preview?.dataUrl || '', title: packet.payload?.sourceName || '관리자 코드',
        conversationId: leaderConversation(this.userId), toUserIds: [this.userId],
      });
      pushChat(msg);
      showCodeDelivery();
    }
    return result;
  };

  async function sendPreparedCode(source, targets = []) {
    if (studio.role !== 'leader') throw new Error('대표만 코드를 전송할 수 있습니다.');
    if (!targets.length) throw new Error('받을 사용자를 선택해 주세요.');
    for (const target of targets) {
      const userId = typeof target === 'string' ? target : target.userId;
      const payload = {
        code: source.code,
        dependencies: source.dependencies || {},
        preview: source.image || null,
        sourceName: source.objectName,
        scope: source.scope || 'thread',
        targetMode: target.targetMode || 'current',
        targetObjectId: target.targetObjectId || null,
        baseObjectId: target.baseObjectId || null,
        newObjectName: target.newObjectName || `${source.objectName} 작업`,
      };
      studio.sendTo(userId, { type: 'APPLY_CODE', payload });
    }
    studio.setNotice(`${targets.length}명에게 코드를 전송했습니다.`);
    return { count: targets.length };
  }

  studio.sendSelectedCode = async function enhancedSendSelectedCode({ scope = 'object', objectId, targets = [] }) {
    if (this.role !== 'leader') throw new Error('대표만 코드를 전송할 수 있습니다.');
    const source = await this.bridge('GET_SOURCE_CODE', { scope, objectId });
    return sendPreparedCode(source, targets);
  };


  studio.handleCommand = async function patchedHandleCommand(command, payload = {}) {
    initFeatureState();
    switch (command) {
      case 'SEND_CHAT': return sendChat(payload);
      case 'SET_CHAT_SETTINGS': {
        if (this.role !== 'leader') throw new Error('관리자만 설정할 수 있습니다.');
        this.chatCooldownMs = Math.max(0, Math.min(60000, Number(payload.cooldownMs) || 0));
        for (const id of this.peerIds()) sendPolicy(id);
        patchFeatureUi(); this.notifyState();
        return true;
      }
      case 'SET_PARTICIPANT_POLICY': {
        if (this.role !== 'leader') throw new Error('관리자만 설정할 수 있습니다.');
        const current = policyFor(payload.userId);
        this.participantPolicies.set(payload.userId, { ...current, peerChatAllowed: Boolean(payload.peerChatAllowed) });
        sendPolicy(payload.userId);
        patchFeatureUi(); this.notifyState();
        return true;
      }
      case 'SEND_ANNOUNCEMENT': {
        if (this.role !== 'leader') throw new Error('관리자만 공지할 수 있습니다.');
        const text = String(payload.text || '').trim();
        this.announcement = text ? { id: randomId(), text: text.slice(0, 500), at: Date.now() } : null;
        this.sendAll({ type: 'ANNOUNCEMENT', announcement: this.announcement });
        patchFeatureUi(); this.notifyUiEvent({ type: 'announcement', announcement: this.announcement }); this.notifyState();
        return true;
      }
      case 'GET_CURRENT_CODE_IMAGE': {
        if (this.role !== 'leader') throw new Error('관리자만 사용할 수 있습니다.');
        return this.bridge('GET_CONTEXT_CODE', {});
      }
      case 'SEND_MEDIA': {
        if (this.role !== 'leader') throw new Error('관리자만 전송할 수 있습니다.');
        const userIds = [...new Set((payload.userIds || []).filter(Boolean))];
        if (!userIds.length) throw new Error('받을 사용자를 선택해 주세요.');
        const route = payload.route === 'chat' ? 'chat' : 'focus';
        if (route === 'chat' && payload.all) {
          const message = makeTextMessage({
            from: this.userId, text: payload.note || '관리자가 코드 이미지를 보냈습니다.', kind: 'image',
            dataUrl: payload.dataUrl || '', title: payload.title || '선택 코드', conversationId: 'all', toUserIds: userIds,
          });
          pushChat(message, { unread: false });
          for (const userId of userIds) this.sendTo(userId, { type: 'MANAGER_MEDIA', dataUrl: payload.dataUrl, route, note: payload.note || '', title: payload.title || '선택 코드', message });
        } else {
          for (const userId of userIds) {
            const message = route === 'chat' ? makeTextMessage({
              from: this.userId, text: payload.note || '관리자가 코드 이미지를 보냈습니다.', kind: 'image',
              dataUrl: payload.dataUrl || '', title: payload.title || '선택 코드', conversationId: leaderConversation(userId), toUserIds: [userId],
            }) : null;
            if (message) pushChat(message, { unread: false });
            this.sendTo(userId, { type: 'MANAGER_MEDIA', dataUrl: payload.dataUrl, route, note: payload.note || '', title: payload.title || '선택 코드', message });
          }
        }
        return { count: userIds.length };
      }
      case 'REQUEST_PARTICIPANT_ENT': {
        if (this.role !== 'leader') throw new Error('관리자만 가져올 수 있습니다.');
        if (!payload.userId) throw new Error('참여자를 선택해 주세요.');
        const requestId = randomId();
        this.sendTo(payload.userId, { type: 'PROJECT_EXPORT_REQUEST', requestId });
        return { requestId };
      }
      case 'APPLY_SHARED_CODE': {
        if (this.role !== 'leader') throw new Error('관리자만 적용할 수 있습니다.');
        const share = this.codeShares.get(payload.shareId);
        if (!share) throw new Error('전송된 코드를 찾을 수 없습니다.');
        return this.bridge('APPLY_CODE', {
          code: share.code, dependencies: share.dependencies, sourceName: share.sourceName,
          targetMode: payload.targetMode || 'current', targetObjectId: payload.targetObjectId || null,
          newObjectName: payload.newObjectName || `${share.sourceName} 받음`,
        });
      }
      case 'RESTORE_SCREEN':
        this.viewerOverride = null;
        if (this.latestFrames?.screen) loadFeatureViewer(this.latestFrames.screen);
        patchFeatureUi(); this.notifyState(); return true;
      case 'MARK_CHAT_READ':
        this.chatUnread = 0; patchFeatureUi(); this.notifyState(); return true;
      case 'SEND_FRAME':
        return this.handleCommand('SEND_MEDIA', { ...payload, route: payload.route || 'focus' });
    }
    return original.handleCommand(command, payload);
  };

  studio.publicState = function patchedPublicState() {
    initFeatureState();
    const state = original.publicState();
    if (!state.active) return state;
    state.chat = {
      unread: this.chatUnread,
      cooldownMs: this.chatCooldownMs,
      peerChatAllowed: this.peerChatAllowed,
      messages: this.chatMessages.slice(-100),
    };
    state.participantPolicies = Object.fromEntries([...this.participantPolicies.entries()].map(([id, value]) => [id, value]));
    state.announcement = this.announcement;
    state.screenShareStartedAt = this.screenShareStartedAt || null;
    state.viewerOverride = this.viewerOverride ? { title: this.viewerOverride.title, at: this.viewerOverride.at } : null;
    state.codeShares = this.codeShareOrder.slice(0, 30).map((id) => {
      const share = this.codeShares.get(id);
      return share ? { id: share.id, from: share.from, fromName: share.fromName, sourceName: share.sourceName, image: share.image, at: share.at } : null;
    }).filter(Boolean);
    return state;
  };

  studio.cleanParticipant = function patchedCleanParticipant(participant) {
    const base = {
      id: participant.id, name: participant.name, role: participant.role,
      peerState: participant.peerState, lastSeen: participant.lastSeen,
    };
    if (this.mode === 'mode2') {
      base.summary = participant.summary || null;
      base.codeView = participant.codeView || null;
    }
    base.peerChatAllowed = Boolean(this.participantPolicies?.get(participant.id)?.peerChatAllowed);
    return base;
  };

  function contextMenuReference(menu) {
    const containers = [...menu.querySelectorAll('div')];
    const targetList = containers.find((el) => {
      const style = el.style;
      const directItems = [...el.children].filter((child) => child.tagName === 'DIV');
      const hasCodeItem = directItems.some((child) => /^코드 (복제|복사|잘라내기|삭제)하기$/.test(child.textContent?.trim() || ''));
      return hasCodeItem && style.height === '100%' && style.overflowY === 'visible';
    }) || containers.find((el) => [...el.children].some((child) => child.tagName === 'DIV' && /^코드 (복제|복사|잘라내기|삭제)하기$/.test(child.textContent?.trim() || '')));
    if (!targetList) return null;
    const reference = [...targetList.children].find((el) => el.tagName === 'DIV' && /^코드 (복제|복사|잘라내기|삭제)하기$/.test(el.textContent?.trim() || ''))
      || [...targetList.children].find((el) => el.tagName === 'DIV' && el.className && el.textContent?.trim());
    return reference ? { reference, targetList } : null;
  }

  function closeEntryContextMenu(menu) {
    const popup = menu.closest('[role="menu"]');
    if (popup) {
      try { popup.remove(); return; } catch (_) {}
    }
    try { document.body.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true })); } catch (_) {}
  }

  function showLeaderCodeSendPicker(source) {
    const root = studio.ui?.shadow;
    const picker = root?.getElementById('elsCodeSendPicker');
    const list = root?.getElementById('elsCodeRecipients');
    const title = root?.getElementById('elsCodePickerTitle');
    if (!picker || !list) return;
    studio.pendingContextCode = source;
    const people = [...studio.participants.values()].filter((p) => p.id !== studio.userId);
    if (title) title.textContent = `${source.objectName || '선택 코드'} 보내기`;
    list.innerHTML = people.length
      ? `<label class="els-code-recipient all"><input id="elsCodeAll" type="checkbox" checked><span><b>모두</b><small>${people.length}명</small></span></label>${people.map((p) => `<label class="els-code-recipient"><input type="checkbox" data-code-user="${esc(p.id)}"><span><b>${esc(p.name || '참여자')}</b><small>${p.peerState === 'connected' ? '연결됨' : '연결 중'}</small></span></label>`).join('')}`
      : '<div class="els-picker-empty">연결된 참가자가 없습니다.</div>';
    const all = root.getElementById('elsCodeAll');
    all?.addEventListener('change', () => {
      if (all.checked) root.querySelectorAll('[data-code-user]').forEach((el) => { el.checked = false; });
    });
    root.querySelectorAll('[data-code-user]').forEach((el) => el.addEventListener('change', () => {
      if (el.checked && all) all.checked = false;
    }));
    picker.hidden = false;
  }

  function installContextMenuObserver() {
    if (studio.contextMenuObserver) return;
    const inject = (root = document) => {
      if (!studio.active || studio.mode !== 'mode1') return;
      const menus = [];
      if (root.matches?.('.rcs-inner-container')) menus.push(root);
      root.querySelectorAll?.('.rcs-inner-container').forEach((menu) => menus.push(menu));
      for (const menu of menus) {
        if (menu.querySelector('[data-entry-live-send-code]')) continue;
        const menuRef = contextMenuReference(menu);
        const reference = menuRef?.reference;
        const targetList = menuRef?.targetList;
        if (!reference || !targetList) continue;
        const item = document.createElement('div');
        item.dataset.entryLiveSendCode = '1';
        item.className = reference.className;
        item.textContent = studio.role === 'leader' ? '참가자에게 코드 보내기' : '관리자에게 코드 전송';
        item.addEventListener('click', async (event) => {
          event.preventDefault();
          event.stopPropagation();
          event.stopImmediatePropagation();
          try {
            const source = await studio.bridge('GET_CONTEXT_CODE', {});
            if (studio.role === 'leader') {
              showLeaderCodeSendPicker(source);
            } else {
              const shareId = randomId();
              studio.sendTo(studio.leaderId, {
                type: 'PARTICIPANT_CODE_SHARE', shareId, sourceName: source.objectName,
                code: source.code, dependencies: source.dependencies || {}, image: source.image || null,
              });
              studio.setNotice('관리자에게 코드를 전송했습니다.');
            }
            closeEntryContextMenu(menu);
          } catch (error) {
            studio.setNotice(error?.message || String(error), 'error');
          }
        }, true);
        // .rcs-inner-container 안의 height:100%; overflow-y:visible 실제 메뉴 목록 div에 직접 추가한다.
        targetList.appendChild(item);
      }
    };
    studio.contextMenuObserver = new MutationObserver((records) => {
      for (const record of records) for (const node of record.addedNodes) if (node.nodeType === 1) inject(node);
    });
    studio.contextMenuObserver.observe(document.documentElement, { childList: true, subtree: true });
    inject(document);
  }

  function roleTemplate() {
    if (studio.role === 'leader') {
      return `<section class="els-main els-leader" id="elsMain">
        <header id="elsDrag"><div><strong>Entry Live Studio</strong><span id="elsStatus">관리자</span></div><button id="elsCollapse" aria-label="접기">−</button></header>
        <div class="els-leader-body" id="elsLeaderBody">
          <button id="elsScreen" class="els-primary">화면 송출</button>
          <button id="elsDraw">그리기</button>
          <button id="elsErase">지우개</button>
          <button id="elsClearDraw">전체 지우기</button>
          <button id="elsManager">사용자 관리</button>
          <div class="els-announce-inline"><input id="elsAnnounceInput" maxlength="500" placeholder="화면 상단 공지"><button id="elsAnnounceSend">공지</button></div>
        </div>
      </section>`;
    }
    return `<section class="els-main els-viewer" id="elsMain">
      <header id="elsDrag"><div><strong>대표 화면</strong><span id="elsStatus">연결 중</span></div></header>
      <div class="els-stage" id="elsStage"><canvas id="viewerCanvas"></canvas><canvas id="annotCanvas"></canvas><div class="els-empty" id="elsEmpty">대표 화면을 기다리는 중</div>
        <aside class="els-code-delivery" id="elsCodeDelivery" hidden><div><strong id="elsCodeTitle">대표 코드</strong><button id="elsCodeClose">×</button></div><div class="els-code-image-wrap"><img id="elsCodeImage" alt="전송된 코드"></div></aside>
      </div>
      <footer><span id="elsViewerDesc">대표 화면 공유 중</span><button id="elsRestore" hidden>대표 화면 다시 보기</button></footer>
      <i class="els-resize nw" data-resize="nw"></i><i class="els-resize ne" data-resize="ne"></i><i class="els-resize sw" data-resize="sw"></i><i class="els-resize se" data-resize="se"></i>
    </section>`;
  }

  function featureCss() {
    return `
      *{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}[hidden]{display:none!important}
      .els-main{position:fixed;z-index:2147483600;color:#172033;background:#fff;border:1px solid #dce3ed;border-radius:18px;box-shadow:0 18px 52px rgba(23,32,51,.23);font:13px/1.45 system-ui,-apple-system,"Noto Sans KR",sans-serif;overflow:hidden}
      .els-main header{height:48px;display:flex;align-items:center;justify-content:space-between;padding:0 10px 0 14px;border-bottom:1px solid #edf0f5;background:#fff;cursor:grab;touch-action:none;user-select:none}.els-main header:active{cursor:grabbing}.els-main header div{display:flex;align-items:center;gap:8px;min-width:0}.els-main header strong{font-size:14px}.els-main header span{font-size:11px;color:#7a8597;white-space:nowrap}.els-main header button{width:32px;height:32px;border:0;border-radius:9px;background:#f1f4f8}
      .els-viewer{right:78px;bottom:18px;width:min(720px,calc(100vw - 105px));height:min(491px,calc(100vh - 20px));min-width:300px;max-width:calc(100vw - 12px);display:grid;grid-template-rows:48px minmax(0,1fr) 38px}.els-stage{position:relative;min-height:0;background:#f3f5f8;overflow:hidden}.els-stage canvas{position:absolute;inset:0;width:100%;height:100%}.els-stage #annotCanvas{pointer-events:none}.els-empty{position:absolute;inset:0;display:grid;place-items:center;color:#8d97a7}.els-stage.has-frame .els-empty{display:none}.els-viewer footer{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:0 10px;background:#fff;border-top:1px solid #edf0f5;color:#667184;font-size:11px}.els-viewer footer button{border:1px solid #d8dfea;background:#fff;border-radius:8px;padding:5px 8px;color:#5143d7}
      .els-resize{position:absolute;width:20px;height:20px;z-index:5}.els-resize.nw{left:-5px;top:-5px;cursor:nwse-resize}.els-resize.ne{right:-5px;top:-5px;cursor:nesw-resize}.els-resize.sw{left:-5px;bottom:-5px;cursor:nesw-resize}.els-resize.se{right:-5px;bottom:-5px;cursor:nwse-resize}
      .els-leader{right:76px;bottom:18px;width:min(590px,calc(100vw - 100px))}.els-leader-body{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:7px;padding:10px}.els-leader-body>button,.els-announce-inline button{border:1px solid #dbe2ec;border-radius:10px;padding:9px 8px;background:#fff;color:#344054;white-space:nowrap}.els-leader-body .els-primary{border-color:#6758ee;background:#6758ee;color:#fff}.els-leader-body .active{border-color:#6758ee;background:#efedff;color:#5041d9}.els-announce-inline{grid-column:1/-1;display:grid;grid-template-columns:1fr auto;gap:6px}.els-announce-inline input{min-width:0;border:1px solid #dbe2ec;border-radius:10px;padding:9px 10px;outline:none}
      .els-chat-launch{position:fixed;right:18px;bottom:18px;z-index:2147483643;width:48px;height:48px;border:1px solid #d8e0eb;border-radius:15px;background:#fff;box-shadow:0 12px 32px rgba(23,32,51,.24);display:grid;place-items:center;touch-action:none}.els-chat-launch svg{width:23px;height:23px;fill:none;stroke:#3d4758;stroke-width:2}.els-badge{position:absolute;right:-6px;top:-6px;min-width:21px;height:21px;padding:0 5px;border-radius:11px;display:grid;place-items:center;background:#e43e56;color:#fff;font:bold 11px system-ui;border:2px solid #fff}
      .els-chat{position:fixed;right:18px;bottom:76px;z-index:2147483642;width:min(520px,calc(100vw - 20px));height:min(520px,72vh);display:grid;grid-template-rows:48px 1fr;background:#fff;border:1px solid #dce3ed;border-radius:17px;box-shadow:0 18px 50px rgba(23,32,51,.25);overflow:hidden;font:13px/1.4 system-ui,-apple-system,"Noto Sans KR",sans-serif}.els-chat-head{display:flex;align-items:center;justify-content:space-between;padding:0 10px 0 14px;border-bottom:1px solid #edf0f5}.els-chat-head button{border:0;background:#f2f4f8;border-radius:8px;width:30px;height:30px}.els-chat-body{min-height:0;display:grid;grid-template-columns:150px minmax(0,1fr)}.els-chat-rooms{min-height:0;overflow:auto;padding:7px;background:#f4f6f9;border-right:1px solid #e8ecf2}.els-room{width:100%;display:flex;align-items:center;gap:8px;margin:0 0 5px;padding:9px 8px;border:0;border-radius:11px;background:transparent;color:#465165;text-align:left}.els-room:hover{background:#fff}.els-room.active{background:#fff;color:#5143d7;box-shadow:0 2px 8px rgba(31,43,66,.08)}.els-room-avatar{width:31px;height:31px;flex:0 0 auto;border-radius:10px;display:grid;place-items:center;background:#e6eaf1;color:#677184;font-weight:800}.els-room.active .els-room-avatar{background:#6758ee;color:#fff}.els-room-copy{min-width:0}.els-room-copy b,.els-room-copy small{display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.els-room-copy small{margin-top:2px;font-size:9px;color:#8a94a3}.els-conversation{min-width:0;min-height:0;display:grid;grid-template-rows:42px 1fr auto;background:#f8f9fb}.els-conversation-head{display:flex;align-items:center;padding:0 11px;background:#fff;border-bottom:1px solid #edf0f5;font-weight:700}.els-chat-list{overflow:auto;padding:10px}.els-msg{max-width:88%;margin:0 0 8px;padding:8px 10px;border:1px solid #e3e7ee;border-radius:12px;background:#fff;color:#283447}.els-msg.mine{margin-left:auto;background:#eeecff;border-color:#d9d4ff}.els-msg small{display:block;margin-bottom:3px;color:#8791a1;font-size:10px}.els-msg img{display:block;max-width:100%;max-height:220px;margin-top:7px;border-radius:8px;background:#eef1f5;cursor:zoom-in}.els-chat-compose{padding:9px;border-top:1px solid #edf0f5;background:#fff}.els-compose-row{display:grid;grid-template-columns:1fr auto;gap:6px}.els-compose-row input{min-width:0;border:1px solid #dbe2ec;border-radius:10px;padding:9px 10px;background:#fff;outline:none}.els-compose-row button{border:0;border-radius:10px;padding:0 14px;background:#6758ee;color:#fff}
      .els-announcement{position:fixed;left:50%;top:14px;z-index:2147483644;transform:translateX(-50%);max-width:min(900px,calc(100vw - 28px));padding:10px 16px;border:1px solid #d9def0;border-radius:12px;background:rgba(255,255,255,.97);box-shadow:0 10px 30px rgba(23,32,51,.17);color:#273246;font:600 13px/1.4 system-ui,-apple-system,"Noto Sans KR",sans-serif;text-align:center}
      .els-code-delivery{position:absolute;inset:4%;z-index:8;display:grid;grid-template-rows:36px minmax(0,1fr);background:rgba(255,255,255,.985);border:1px solid #dce3ed;border-radius:14px;box-shadow:0 14px 36px rgba(0,0,0,.22);overflow:hidden}.els-code-delivery>div:first-child{display:flex;align-items:center;justify-content:space-between;padding:0 8px 0 11px;border-bottom:1px solid #edf0f4}.els-code-delivery button{width:28px;height:28px;border:0;border-radius:7px;background:#f1f3f7}.els-code-image-wrap{min-height:0;display:grid;place-items:center;overflow:auto;background:#fff;padding:4px}.els-code-delivery img{display:block;max-width:100%;max-height:100%;width:auto;height:auto;object-fit:contain;background:transparent;cursor:zoom-in}
      .els-code-picker{position:fixed;left:50%;top:50%;z-index:2147483645;transform:translate(-50%,-50%);width:min(390px,calc(100vw - 24px));max-height:min(560px,80vh);display:grid;grid-template-rows:48px minmax(80px,1fr) auto;background:#fff;border:1px solid #dce3ed;border-radius:17px;box-shadow:0 24px 70px rgba(23,32,51,.3);overflow:hidden;font:13px/1.4 system-ui,-apple-system,"Noto Sans KR",sans-serif}.els-code-picker header{display:flex;align-items:center;justify-content:space-between;padding:0 10px 0 14px;border-bottom:1px solid #edf0f5}.els-code-picker header button{width:30px;height:30px;border:0;border-radius:8px;background:#f2f4f8}.els-code-recipients{overflow:auto;padding:8px}.els-code-recipient{display:flex;align-items:center;gap:9px;padding:9px;border-radius:11px}.els-code-recipient:hover{background:#f7f8fb}.els-code-recipient input{width:auto}.els-code-recipient span{min-width:0}.els-code-recipient b,.els-code-recipient small{display:block}.els-code-recipient small{font-size:10px;color:#8791a1}.els-code-picker footer{display:grid;grid-template-columns:1fr 1.4fr;gap:7px;padding:9px;border-top:1px solid #edf0f5}.els-code-picker footer button{border:1px solid #dbe2ec;border-radius:10px;padding:9px;background:#fff}.els-code-picker footer .primary{border-color:#6758ee;background:#6758ee;color:#fff}.els-picker-empty{padding:28px 8px;text-align:center;color:#8a94a3}
      .els-lightbox{position:fixed;inset:0;z-index:2147483646;display:grid;grid-template-rows:52px 1fr;background:rgba(10,14,22,.88);backdrop-filter:blur(3px)}.els-lightbox-head{display:flex;align-items:center;justify-content:space-between;padding:0 16px;color:#fff}.els-lightbox-head button{width:34px;height:34px;border:1px solid rgba(255,255,255,.25);border-radius:10px;background:rgba(255,255,255,.1);color:#fff}.els-lightbox-body{min-height:0;display:grid;place-items:center;padding:12px 20px 24px}.els-lightbox img{display:block;max-width:96vw;max-height:calc(100vh - 92px);object-fit:contain;background:#fff;border-radius:10px}
      @media(max-width:680px){.els-viewer{right:64px;bottom:10px;width:calc(100vw - 76px);min-width:230px}.els-leader{right:64px;bottom:10px;width:calc(100vw - 76px)}.els-leader-body{grid-template-columns:repeat(2,minmax(0,1fr))}.els-leader-body>button:nth-child(5){grid-column:1/-1}.els-chat{width:calc(100vw - 16px)}.els-chat-body{grid-template-columns:112px minmax(0,1fr)}}
    `;
  }

  studio.mountUi = function customMountUi(force = false) {
    if (force) original.unmountUi();
    if (!this.active || this.mode !== 'mode1') return;
    if (this.ui?.host?.isConnected) { patchFeatureUi(); return; }
    const host = document.createElement('div');
    host.id = 'entry-live-studio-host';
    const shadow = host.attachShadow({ mode: 'open' });
    document.documentElement.appendChild(host);
    this.ui = {
      host, shadow, collapsed: false, viewKind: 'screen', leaderView: 'stream',
      selectedParticipantId: null, zoom: 1, panX: 0, panY: 0, tool: 'pan', panelX: null, panelY: null,
      viewerUserSized: false,
    };
    shadow.innerHTML = `<style>${featureCss()}</style>${roleTemplate()}
      <button class="els-chat-launch" id="elsChatLaunch" aria-label="채팅"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 5.5h14v10H9l-4 3v-13Z"></path><path d="M8 9h8M8 12h5"></path></svg><span class="els-badge" id="elsChatBadge" hidden>0</span></button>
      <section class="els-chat" id="elsChat" hidden><div class="els-chat-head"><strong>채팅</strong><button id="elsChatClose">×</button></div><div class="els-chat-body"><nav class="els-chat-rooms" id="elsChatRooms"></nav><section class="els-conversation"><div class="els-conversation-head" id="elsChatRoomTitle">대화</div><div class="els-chat-list" id="elsChatList"></div><div class="els-chat-compose"><div class="els-compose-row"><input id="elsChatInput" maxlength="2000" autocomplete="off" placeholder="메시지 입력"><button id="elsChatSend">전송</button></div></div></section></div></section>
      <div class="els-announcement" id="elsAnnouncement" hidden></div>
      <section class="els-code-picker" id="elsCodeSendPicker" hidden><header><strong id="elsCodePickerTitle">코드 보내기</strong><button id="elsCodePickerClose">×</button></header><div class="els-code-recipients" id="elsCodeRecipients"></div><footer><button id="elsCodePickerCancel">취소</button><button id="elsCodeSendConfirm" class="primary">선택한 참가자에게 전송</button></footer></section>
      <div class="els-lightbox" id="elsLightbox" hidden><div class="els-lightbox-head"><strong id="elsLightboxTitle">이미지</strong><button id="elsLightboxClose">×</button></div><div class="els-lightbox-body" id="elsLightboxBody"><img id="elsLightboxImage" alt="크게 보기"></div></div>`;
    bindFeatureUi();
    patchFeatureUi();
    if (this.role === 'leader') this.ensureLeaderDrawingCanvas();
    if (this.role !== 'leader' && this.latestFrames?.screen) loadFeatureViewer(this.latestFrames.screen);
    ensureFeatureTimer();
  };

  studio.unmountUi = function featureUnmountUi() {
    if (this.featureTimer) clearInterval(this.featureTimer);
    this.featureTimer = null;
    return original.unmountUi();
  };

  studio.renderUi = function noRebuildRender() { patchFeatureUi(); };
  studio.updateUi = function noRebuildUpdate() { patchFeatureUi(); };
  studio.setControlsVisible = function noBlinkControls() {};
  studio.patchFloatingNotice = function noticeWithoutRebuild() {};
  studio.patchCodePreview = function safePatchCode(id, dataUrl, alt) {
    const preview = this.ui?.shadow?.getElementById(id);
    if (!preview) return;
    original.patchCodePreview(id, dataUrl, alt);
  };
  studio.bindUiEvents = function noopBind() {};

  const originalLoadViewerFrame = studio.loadViewerFrame.bind(studio);
  studio.loadViewerFrame = async function patchedViewerFrame(kind, dataUrl, preserve = false) {
    if (this.mode === 'mode1' && this.role !== 'leader' && kind === 'screen') {
      if (this.viewerOverride) return;
      loadFeatureViewer(dataUrl);
      return;
    }
    if (this.mode === 'mode1' && this.role !== 'leader' && kind === 'code') return;
    return originalLoadViewerFrame(kind, dataUrl, preserve);
  };

  function ensureFeatureTimer() {
    if (studio.featureTimer) return;
    studio.featureTimer = setInterval(() => {
      if (!studio.active || !studio.ui?.shadow) return;
      patchShareTimer();
    }, 1000);
  }

  function bindFeatureUi() {
    const root = studio.ui?.shadow;
    if (!root) return;
    root.getElementById('elsCollapse')?.addEventListener('click', () => {
      const body = root.getElementById('elsLeaderBody');
      const button = root.getElementById('elsCollapse');
      if (!body) return;
      const hidden = !body.hidden;
      body.hidden = hidden; button.textContent = hidden ? '+' : '−';
    });
    root.getElementById('elsScreen')?.addEventListener('click', () => studio.handleCommand('SET_SCREEN', { enabled: !studio.screenEnabled }));
    root.getElementById('elsDraw')?.addEventListener('click', () => selectLeaderDrawTool('draw'));
    root.getElementById('elsErase')?.addEventListener('click', () => selectLeaderDrawTool('erase'));
    root.getElementById('elsClearDraw')?.addEventListener('click', () => { studio.clearLeaderDrawing(); studio.setNotice('그림을 모두 지웠습니다.'); });
    root.getElementById('elsManager')?.addEventListener('click', () => studio.handleCommand('OPEN_MANAGER', {}));
    root.getElementById('elsAnnounceSend')?.addEventListener('click', async () => {
      const input = root.getElementById('elsAnnounceInput');
      try { await studio.handleCommand('SEND_ANNOUNCEMENT', { text: input?.value || '' }); if (input) input.value = ''; }
      catch (error) { studio.setNotice(error.message, 'error'); }
    });
    root.getElementById('elsRestore')?.addEventListener('click', () => studio.handleCommand('RESTORE_SCREEN', {}));
    root.getElementById('elsCodeClose')?.addEventListener('click', () => { const el = root.getElementById('elsCodeDelivery'); if (el) el.hidden = true; });
    root.getElementById('elsCodeImage')?.addEventListener('click', (event) => openImageLightbox(event.currentTarget.src, root.getElementById('elsCodeTitle')?.textContent || '코드'));
    root.getElementById('elsCodePickerClose')?.addEventListener('click', closeCodePicker);
    root.getElementById('elsCodePickerCancel')?.addEventListener('click', closeCodePicker);
    root.getElementById('elsCodeSendConfirm')?.addEventListener('click', async () => {
      try {
        const source = studio.pendingContextCode;
        if (!source) throw new Error('보낼 코드를 찾지 못했습니다.');
        const all = root.getElementById('elsCodeAll')?.checked;
        const ids = all ? studio.peerIds() : [...root.querySelectorAll('[data-code-user]:checked')].map((el) => el.dataset.codeUser);
        if (!ids.length) throw new Error('받을 참가자를 선택해 주세요.');
        await sendPreparedCode(source, ids.map((userId) => ({ userId, targetMode: 'current' })));
        closeCodePicker();
      } catch (error) { studio.setNotice(error?.message || String(error), 'error'); }
    });
    root.getElementById('elsLightboxClose')?.addEventListener('click', closeImageLightbox);
    root.getElementById('elsLightbox')?.addEventListener('click', (event) => { if (event.target.id === 'elsLightbox' || event.target.id === 'elsLightboxBody') closeImageLightbox(); });
    bindMainDragAndResize();
    bindChatUi();
  }

  function selectLeaderDrawTool(tool) {
    const already = studio.drawingEnabled && studio.leaderDrawTool === tool;
    if (already) {
      studio.toggleLeaderDrawing(false);
    } else {
      studio.setLeaderDrawTool?.(tool);
      studio.toggleLeaderDrawing(true);
    }
    patchFeatureUi();
  }

  function closeCodePicker() {
    const picker = studio.ui?.shadow?.getElementById('elsCodeSendPicker');
    if (picker) picker.hidden = true;
    studio.pendingContextCode = null;
  }

  function openImageLightbox(src, title = '이미지') {
    if (!src) return;
    const root = studio.ui?.shadow;
    const box = root?.getElementById('elsLightbox');
    const image = root?.getElementById('elsLightboxImage');
    if (!box || !image) return;
    image.src = src;
    root.getElementById('elsLightboxTitle').textContent = title || '이미지';
    box.hidden = false;
  }

  function closeImageLightbox() {
    const root = studio.ui?.shadow;
    const box = root?.getElementById('elsLightbox');
    const image = root?.getElementById('elsLightboxImage');
    if (box) box.hidden = true;
    if (image) image.removeAttribute('src');
  }

  function bindMainDragAndResize() {
    const root = studio.ui?.shadow;
    const panel = root?.getElementById('elsMain');
    const header = root?.getElementById('elsDrag');
    if (!panel || !header) return;
    let drag = null;
    header.addEventListener('pointerdown', (event) => {
      if (event.target.closest('button')) return;
      const rect = panel.getBoundingClientRect();
      drag = { dx: event.clientX - rect.left, dy: event.clientY - rect.top };
      header.setPointerCapture(event.pointerId);
    });
    header.addEventListener('pointermove', (event) => {
      if (!drag) return;
      const x = Math.max(0, Math.min(innerWidth - panel.offsetWidth, event.clientX - drag.dx));
      const y = Math.max(0, Math.min(innerHeight - panel.offsetHeight, event.clientY - drag.dy));
      panel.style.left = `${x}px`; panel.style.top = `${y}px`; panel.style.right = 'auto'; panel.style.bottom = 'auto';
      studio.ui.panelX = x; studio.ui.panelY = y;
    });
    const end = () => { drag = null; };
    header.addEventListener('pointerup', end); header.addEventListener('pointercancel', end); header.addEventListener('lostpointercapture', end);

    root.querySelectorAll('[data-resize]').forEach((handle) => {
      let resize = null;
      handle.addEventListener('pointerdown', (event) => {
        event.preventDefault(); event.stopPropagation();
        const rect = panel.getBoundingClientRect();
        const chromeHeight = 86;
        resize = { rect, corner: handle.dataset.resize, contentAspect: studio.viewerFrameAspect || rect.width / Math.max(1, rect.height - chromeHeight), chromeHeight };
        handle.setPointerCapture(event.pointerId);
      });
      handle.addEventListener('pointermove', (event) => {
        if (!resize) return;
        const { rect, corner, contentAspect, chromeHeight } = resize;
        const horizontal = corner.includes('e') ? event.clientX - rect.right : rect.left - event.clientX;
        let width = Math.max(300, Math.min(innerWidth - 8, rect.width + horizontal));
        let height = width / contentAspect + chromeHeight;
        const maxHeight = innerHeight - 8;
        if (height > maxHeight) { height = maxHeight; width = Math.max(300, (height - chromeHeight) * contentAspect); }
        let left = corner.includes('w') ? rect.right - width : rect.left;
        let top = corner.includes('n') ? rect.bottom - height : rect.top;
        left = Math.max(0, Math.min(innerWidth - width, left));
        top = Math.max(0, Math.min(innerHeight - height, top));
        Object.assign(panel.style, { width: `${width}px`, height: `${height}px`, left: `${left}px`, top: `${top}px`, right: 'auto', bottom: 'auto' });
        studio.ui.viewerUserSized = true;
      });
      const stop = () => { resize = null; };
      handle.addEventListener('pointerup', stop); handle.addEventListener('pointercancel', stop); handle.addEventListener('lostpointercapture', stop);
    });
  }

  function bindChatUi() {
    const root = studio.ui?.shadow;
    const launch = root?.getElementById('elsChatLaunch');
    const panel = root?.getElementById('elsChat');
    if (!launch || !panel) return;
    let moved = false, drag = null;
    launch.addEventListener('pointerdown', (event) => {
      const rect = launch.getBoundingClientRect(); moved = false;
      drag = { x: event.clientX - rect.left, y: event.clientY - rect.top, sx: event.clientX, sy: event.clientY };
      launch.setPointerCapture(event.pointerId);
    });
    launch.addEventListener('pointermove', (event) => {
      if (!drag) return;
      if (Math.hypot(event.clientX - drag.sx, event.clientY - drag.sy) > 4) moved = true;
      if (!moved) return;
      const x = Math.max(0, Math.min(innerWidth - launch.offsetWidth, event.clientX - drag.x));
      const y = Math.max(0, Math.min(innerHeight - launch.offsetHeight, event.clientY - drag.y));
      launch.style.left = `${x}px`; launch.style.top = `${y}px`; launch.style.right = 'auto'; launch.style.bottom = 'auto';
      studio.chatPos = { x, y };
      positionChatPanel();
    });
    launch.addEventListener('pointerup', () => {
      if (!drag) return;
      drag = null;
      if (!moved) toggleChat(!studio.chatOpen);
    });
    launch.addEventListener('pointercancel', () => { drag = null; });
    root.getElementById('elsChatClose')?.addEventListener('click', () => toggleChat(false));
    root.getElementById('elsChatRooms')?.addEventListener('click', (event) => {
      const room = event.target.closest('[data-chat-room]');
      if (!room) return;
      studio.activeChatRoom = room.dataset.chatRoom;
      renderChat();
    });
    const send = async () => {
      const input = root.getElementById('elsChatInput');
      const text = input?.value || '';
      try {
        const room = currentChatRoom();
        if (!room) throw new Error('대화방을 선택해 주세요.');
        if (studio.role === 'leader') {
          await studio.handleCommand('SEND_CHAT', { text, conversationId: room.id });
        } else {
          await studio.handleCommand('SEND_CHAT', { text, targetUserId: room.targetUserId });
        }
        if (input) input.value = '';
        renderChat();
      } catch (error) { studio.setNotice(error.message, 'error'); }
    };
    root.getElementById('elsChatSend')?.addEventListener('click', send);
    root.getElementById('elsChatInput')?.addEventListener('keydown', (event) => { if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) { event.preventDefault(); send(); } });
    root.getElementById('elsChatList')?.addEventListener('click', (event) => {
      const image = event.target.closest('img');
      if (image) openImageLightbox(image.src, image.alt || '채팅 이미지');
    });
  }

  function chatRooms() {
    if (studio.role === 'leader') {
      return [
        { id: 'all', label: '전체', sub: '모든 참가자', targetUserId: 'all' },
        ...[...studio.participants.values()].filter((p) => p.id !== studio.userId).map((p) => ({
          id: leaderConversation(p.id), label: p.name || '참여자', sub: p.peerState === 'connected' ? '개인 대화' : '연결 중', targetUserId: p.id,
        })),
      ];
    }
    const rooms = [{ id: leaderConversation(studio.userId), label: '관리자', sub: '관리자와 개인 대화', targetUserId: studio.leaderId }];
    if (studio.peerChatAllowed) {
      rooms.push({ id: 'all', label: '전체', sub: '참가자 전체 대화', targetUserId: 'all' });
      for (const peer of studio.chatPeers || []) {
        rooms.push({ id: peerConversation(studio.userId, peer.id), label: peer.name || '참여자', sub: '개인 대화', targetUserId: peer.id });
      }
    }
    return rooms;
  }

  function currentChatRoom() {
    const rooms = chatRooms();
    if (!rooms.some((room) => room.id === studio.activeChatRoom)) studio.activeChatRoom = rooms[0]?.id || null;
    return rooms.find((room) => room.id === studio.activeChatRoom) || null;
  }

  function positionChatPanel() {
    const root = studio.ui?.shadow;
    const launch = root?.getElementById('elsChatLaunch');
    const panel = root?.getElementById('elsChat');
    if (!launch || !panel || panel.hidden) return;
    const r = launch.getBoundingClientRect();
    const width = Math.min(520, innerWidth - 20);
    const height = Math.min(520, innerHeight * .72);
    const left = Math.max(8, Math.min(innerWidth - width - 8, r.right - width));
    const top = Math.max(8, Math.min(innerHeight - height - 8, r.top - height - 8));
    Object.assign(panel.style, { left: `${left}px`, top: `${top}px`, right: 'auto', bottom: 'auto' });
  }

  function toggleChat(open) {
    const root = studio.ui?.shadow;
    const panel = root?.getElementById('elsChat');
    if (!panel) return;
    studio.chatOpen = Boolean(open);
    panel.hidden = !studio.chatOpen;
    if (studio.chatOpen) {
      currentChatRoom();
      studio.chatUnread = 0;
      renderChat(); positionChatPanel();
      studio.notifyState?.();
    }
    patchFeatureUi();
  }

  function renderChat() {
    const root = studio.ui?.shadow;
    const roomsEl = root?.getElementById('elsChatRooms');
    const list = root?.getElementById('elsChatList');
    const title = root?.getElementById('elsChatRoomTitle');
    if (!roomsEl || !list || !title) return;
    const rooms = chatRooms();
    const room = currentChatRoom();
    roomsEl.innerHTML = rooms.map((item) => `<button class="els-room ${item.id === studio.activeChatRoom ? 'active' : ''}" data-chat-room="${esc(item.id)}"><span class="els-room-avatar">${esc((item.label || '?').slice(0,1))}</span><span class="els-room-copy"><b>${esc(item.label)}</b><small>${esc(item.sub || '')}</small></span></button>`).join('') || '<div class="els-picker-empty">대화 상대가 없습니다.</div>';
    title.textContent = room?.label || '대화';
    const messages = studio.chatMessages.filter((msg) => conversationForIncoming(msg) === room?.id);
    list.innerHTML = messages.map((msg) => `<article class="els-msg ${msg.from === studio.userId ? 'mine' : ''}"><small>${esc(msg.fromName || participantName(msg.from))}${msg.targetLabel ? ` · ${esc(msg.targetLabel)}` : ''}</small>${msg.text ? `<div>${esc(msg.text)}</div>` : ''}${msg.dataUrl ? `<img src="${msg.dataUrl}" alt="${esc(msg.title || '첨부 이미지')}">` : ''}</article>`).join('') || '<div style="padding:30px 8px;text-align:center;color:#9099a8">메시지가 없습니다.</div>';
    list.scrollTop = list.scrollHeight;
  }

  function patchShareTimer() {
    const root = studio.ui?.shadow;
    if (!root) return;
    const elapsed = studio.screenEnabled && studio.screenShareStartedAt ? formatDuration(Date.now() - studio.screenShareStartedAt) : '';
    const status = root.getElementById('elsStatus');
    if (status) {
      if (studio.connectionStatus !== 'online') status.textContent = '연결 중';
      else if (studio.role === 'leader') status.textContent = `${studio.participants.size}명 연결${elapsed ? ` · 송출 ${elapsed}` : ''}`;
      else status.textContent = studio.screenEnabled && elapsed ? `공유 ${elapsed}` : '연결됨';
    }
    const desc = root.getElementById('elsViewerDesc');
    if (desc) {
      if (studio.viewerOverride) desc.textContent = `${studio.viewerOverride.title || '대표 표시'} · 화면 공유 일시 중지`;
      else if (!studio.screenEnabled) desc.textContent = '대표 화면 공유 중지';
      else desc.textContent = `대표 화면 공유 중${elapsed ? ` · ${elapsed}` : ''}`;
    }
  }

  function patchFeatureUi() {
    initFeatureState();
    const root = studio.ui?.shadow;
    if (!root) return;
    patchShareTimer();
    const screen = root.getElementById('elsScreen');
    if (screen) { screen.textContent = studio.screenEnabled ? '송출 중' : '송출 시작'; screen.classList.toggle('els-primary', studio.screenEnabled); }
    const draw = root.getElementById('elsDraw');
    const erase = root.getElementById('elsErase');
    if (draw) draw.classList.toggle('active', Boolean(studio.drawingEnabled && studio.leaderDrawTool !== 'erase'));
    if (erase) erase.classList.toggle('active', Boolean(studio.drawingEnabled && studio.leaderDrawTool === 'erase'));
    const badge = root.getElementById('elsChatBadge');
    if (badge) { badge.hidden = !studio.chatUnread; badge.textContent = studio.chatUnread > 99 ? '99+' : String(studio.chatUnread); }
    const announcement = root.getElementById('elsAnnouncement');
    if (announcement) { announcement.hidden = !studio.announcement?.text; announcement.textContent = studio.announcement?.text || ''; }
    const restore = root.getElementById('elsRestore');
    if (restore) restore.hidden = !studio.viewerOverride;
    if (studio.chatOpen) renderChat();
  }

  function fitViewerPanelToFrame(image) {
    const root = studio.ui?.shadow;
    const panel = root?.getElementById('elsMain');
    if (!panel || studio.role === 'leader' || !image?.naturalWidth || !image?.naturalHeight) return;
    studio.viewerFrameAspect = image.naturalWidth / image.naturalHeight;
    if (studio.ui?.viewerUserSized) return;
    const chromeHeight = 86;
    let width = Math.min(panel.getBoundingClientRect().width || 720, innerWidth - 12);
    let height = width / studio.viewerFrameAspect + chromeHeight;
    const maxHeight = innerHeight - 12;
    if (height > maxHeight) { height = maxHeight; width = Math.max(300, (height - chromeHeight) * studio.viewerFrameAspect); }
    panel.style.width = `${width}px`;
    panel.style.height = `${height}px`;
  }

  function loadFeatureViewer(dataUrl) {
    const root = studio.ui?.shadow;
    const canvas = root?.getElementById('viewerCanvas');
    const stage = root?.getElementById('elsStage');
    if (!canvas || !stage || !dataUrl) return;
    const seq = (studio.featureFrameSeq = (studio.featureFrameSeq || 0) + 1);
    const img = new Image();
    img.onload = () => {
      if (seq !== studio.featureFrameSeq || !canvas.isConnected) return;
      fitViewerPanelToFrame(img);
      canvas.width = img.naturalWidth || 1280; canvas.height = img.naturalHeight || 720;
      canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
      stage.classList.add('has-frame');
    };
    img.src = dataUrl;
  }

  function showCodeDelivery() {
    const root = studio.ui?.shadow;
    const card = root?.getElementById('elsCodeDelivery');
    const image = root?.getElementById('elsCodeImage');
    const title = root?.getElementById('elsCodeTitle');
    if (!card || !studio.lastCodeDelivery) return;
    if (title) title.textContent = studio.lastCodeDelivery.sourceName || '대표 코드';
    if (image) {
      const src = studio.lastCodeDelivery.image?.dataUrl || '';
      image.hidden = !src; if (src) image.src = src;
    }
    card.hidden = false;
  }

  addEventListener('pagehide', () => studio.contextMenuObserver?.disconnect?.());
})();
