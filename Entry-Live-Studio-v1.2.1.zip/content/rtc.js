(function () {
  const CHUNK_SIZE = 4000;

  class EntryCollabPeerHub {
    constructor({ selfId, mode, leaderId, bus, iceServers, onData, onState }) {
      this.selfId = selfId;
      this.mode = mode;
      this.leaderId = leaderId;
      this.bus = bus;
      this.iceServers = iceServers?.length
        ? iceServers
        : [
            { urls: 'stun:stun.cloudflare.com:3478' },
            { urls: 'stun:stun.l.google.com:19302' },
          ];
      this.onData = onData || (() => {});
      this.onState = onState || (() => {});
      this.peers = new Map();
      this.incomingChunks = new Map();
      this.fallbackChunks = new Map();
    }

    shouldConnect(peerId) {
      if (!peerId || peerId === this.selfId) return false;
      if (this.mode === 'mode1') {
        return this.selfId === this.leaderId || peerId === this.leaderId;
      }
      return true;
    }

    isInitiator(peerId) {
      if (this.mode === 'mode1') return this.selfId === this.leaderId;
      return this.selfId.localeCompare(peerId) < 0;
    }

    async seePeer(peerId) {
      if (!this.shouldConnect(peerId) || this.peers.has(peerId)) return;
      const peer = this.createPeer(peerId);
      if (this.isInitiator(peerId)) {
        const channel = peer.pc.createDataChannel('entry-live', { ordered: true });
        this.bindChannel(peer, channel);
        const offer = await peer.pc.createOffer();
        await peer.pc.setLocalDescription(offer);
        this.signal(peerId, { description: peer.pc.localDescription });
      }
    }

    createPeer(peerId) {
      const pc = new RTCPeerConnection({ iceServers: this.iceServers });
      const peer = { id: peerId, pc, channel: null, candidateQueue: [], sendQueue: [], pumping: false };
      this.peers.set(peerId, peer);
      pc.onicecandidate = ({ candidate }) => {
        if (candidate) this.signal(peerId, { candidate });
      };
      pc.ondatachannel = ({ channel }) => this.bindChannel(peer, channel);
      pc.onconnectionstatechange = () => {
        this.onState(peerId, pc.connectionState);
        if (['failed', 'closed'].includes(pc.connectionState)) this.dropPeer(peerId);
      };
      return peer;
    }

    bindChannel(peer, channel) {
      peer.channel = channel;
      channel.binaryType = 'arraybuffer';
      channel.bufferedAmountLowThreshold = 128 * 1024;
      channel.onopen = () => {
        this.onState(peer.id, 'connected');
        this.pump(peer);
      };
      channel.onclose = () => this.onState(peer.id, 'disconnected');
      channel.onerror = () => this.onState(peer.id, 'failed');
      channel.onmessage = ({ data }) => this.receiveChunk(peer.id, data);
    }

    async handleSignal(payload) {
      if (!payload || payload.to !== this.selfId || !this.shouldConnect(payload.from)) return;
      let peer = this.peers.get(payload.from);
      if (!peer) peer = this.createPeer(payload.from);
      try {
        if (payload.description) {
          await peer.pc.setRemoteDescription(payload.description);
          for (const candidate of peer.candidateQueue.splice(0)) {
            await peer.pc.addIceCandidate(candidate);
          }
          if (payload.description.type === 'offer') {
            const answer = await peer.pc.createAnswer();
            await peer.pc.setLocalDescription(answer);
            this.signal(payload.from, { description: peer.pc.localDescription });
          }
        } else if (payload.candidate) {
          if (peer.pc.remoteDescription) await peer.pc.addIceCandidate(payload.candidate);
          else peer.candidateQueue.push(payload.candidate);
        }
      } catch (_) {
        this.onState(payload.from, 'failed');
      }
    }

    signal(to, signal) {
      this.bus.send('signal', { from: this.selfId, to, ...signal });
    }

    fragments(packet) {
      const raw = JSON.stringify(packet);
      const id = `${this.selfId}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
      const total = Math.max(1, Math.ceil(raw.length / CHUNK_SIZE));
      const parts = [];
      for (let i = 0; i < total; i++) {
        parts.push(JSON.stringify({ c: 1, id, i, n: total, d: raw.slice(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE) }));
      }
      return parts;
    }

    sendTo(peerId, packet) {
      const peer = this.peers.get(peerId);
      const parts = this.fragments(packet);
      if (peer?.channel?.readyState === 'open') {
        peer.sendQueue.push(...parts);
        this.pump(peer);
        return 'p2p';
      }
      for (const part of parts) this.bus.send('relay', { from: this.selfId, to: peerId, part });
      return 'relay';
    }

    broadcast(packet, peerIds) {
      const ids = peerIds || [...this.peers.keys()];
      for (const peerId of ids) this.sendTo(peerId, packet);
    }

    async pump(peer) {
      if (peer.pumping || peer.channel?.readyState !== 'open') return;
      peer.pumping = true;
      try {
        while (peer.sendQueue.length && peer.channel?.readyState === 'open') {
          if (peer.channel.bufferedAmount > 512 * 1024) {
            await new Promise((resolve) => {
              const done = () => {
                peer.channel.removeEventListener('bufferedamountlow', done);
                resolve();
              };
              peer.channel.addEventListener('bufferedamountlow', done, { once: true });
              setTimeout(done, 1500);
            });
          }
          peer.channel.send(peer.sendQueue.shift());
        }
      } finally {
        peer.pumping = false;
      }
    }

    receiveRelay(payload) {
      if (payload?.to !== this.selfId || !payload.part) return;
      this.receiveChunk(payload.from, payload.part, this.fallbackChunks);
    }

    receiveChunk(from, raw, store = this.incomingChunks) {
      let chunk;
      try {
        chunk = JSON.parse(raw);
      } catch (_) {
        return;
      }
      if (!chunk?.c) return;
      let item = store.get(chunk.id);
      if (!item) {
        item = { from, n: chunk.n, parts: new Array(chunk.n), received: 0, createdAt: Date.now() };
        store.set(chunk.id, item);
      }
      if (item.parts[chunk.i] === undefined) {
        item.parts[chunk.i] = chunk.d;
        item.received++;
      }
      if (item.received === item.n) {
        store.delete(chunk.id);
        try {
          this.onData(from, JSON.parse(item.parts.join('')));
        } catch (_) {}
      }
      const cutoff = Date.now() - 60000;
      for (const [id, value] of store) if (value.createdAt < cutoff) store.delete(id);
    }

    setTopology(mode, leaderId) {
      this.mode = mode;
      this.leaderId = leaderId;
      for (const peerId of [...this.peers.keys()]) {
        if (!this.shouldConnect(peerId)) this.dropPeer(peerId);
      }
    }

    dropPeer(peerId) {
      const peer = this.peers.get(peerId);
      if (!peer) return;
      try { peer.channel?.close(); } catch (_) {}
      try { peer.pc?.close(); } catch (_) {}
      this.peers.delete(peerId);
    }

    close() {
      for (const peerId of [...this.peers.keys()]) this.dropPeer(peerId);
      this.incomingChunks.clear();
      this.fallbackChunks.clear();
    }
  }

  globalThis.EntryCollabPeerHub = EntryCollabPeerHub;
})();
