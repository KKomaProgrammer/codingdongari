(function () {
  if (globalThis.__ENTRY_LIVE_STUDIO_CONTENT__) return;
  globalThis.__ENTRY_LIVE_STUDIO_CONTENT__ = true;

  const PAGE_REQUEST = 'ENTRY_LIVE_STUDIO_REQUEST';
  const PAGE_RESPONSE = 'ENTRY_LIVE_STUDIO_RESPONSE';
  const MAX_VIEWERS = 4;

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const randomId = () => crypto.randomUUID?.() || `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`;
  const escapeHtml = (value) => String(value ?? '').replace(/[&<>'"]/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;',
  })[c]);

  function fastHash(value) {
    const text = typeof value === 'string' ? value : JSON.stringify(value);
    let hash = 2166136261;
    for (let i = 0; i < text.length; i++) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(36);
  }

  class EntryLiveStudio {
    constructor() {
      this.active = false;
      this.bridgePending = new Map();
      this.participants = new Map();
      this.objectVersions = new Map();
      this.lastObjectHashes = new Map();
      this.lastMediaHashes = new Map();
      this.lastSummaryHash = '';
      this.lastSelectedCodeHash = '';
      this.latestFrames = { screen: null, code: null, feedback: null };
      this.ui = null;
      this.captureBusy = false;
      this.lamport = 0;
      this.startedAt = Date.now();
      this.screenEnabled = true;
      this.screenShareStartedAt = Date.now();
      this.leaderDrawTool = 'draw';
      this.fullStateReceived = false;
      this.timers = new Set();
      this.uiLocks = new Set();
      this.deferredUiEvents = new Map();
      this.pendingStateNotify = false;
      this.pendingUiRender = false;
      this.lastFloatingSignature = '';
      this.lastEndReason = '';
      this.leaderSeenAt = 0;
      this.viewerFrameSequence = 0;
      this.installBridgeListener();
      this.installRuntimeListener();
    }

    installBridgeListener() {
      window.addEventListener('message', (event) => {
        if (event.source !== window || event.data?.source !== PAGE_RESPONSE) return;
        const pending = this.bridgePending.get(event.data.requestId);
        if (!pending) return;
        this.bridgePending.delete(event.data.requestId);
        clearTimeout(pending.timer);
        if (event.data.ok) pending.resolve(event.data.result);
        else pending.reject(new Error(event.data.error || '엔트리 처리 실패'));
      });
    }

    bridge(action, payload = {}, timeout = 30000) {
      const requestId = randomId();
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          this.bridgePending.delete(requestId);
          reject(new Error('엔트리 응답 시간이 초과되었습니다.'));
        }, timeout);
        this.bridgePending.set(requestId, { resolve, reject, timer });
        window.postMessage({ source: PAGE_REQUEST, requestId, action, payload }, '*');
      });
    }

    installRuntimeListener() {
      chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
        if (message.type === 'ENTRY_LIVE_CAPTURE_FRAME') {
          if (this.active && this.mode === 'mode1' && this.role === 'leader' && this.screenEnabled) {
            this.latestFrames.screen = message.dataUrl;
            this.sendAll({ type: 'SCREEN_FRAME', dataUrl: message.dataUrl, stamp: Date.now(), startedAt: this.screenShareStartedAt || this.startedAt });
            this.notifyUiEvent({ type: 'leader-screen', dataUrl: message.dataUrl });
          }
          sendResponse({ ok: true });
          return;
        }
        if (message.type === 'ENTRY_LIVE_GET_STATE') {
          sendResponse(this.publicState());
          return;
        }
        if (message.type !== 'ENTRY_LIVE_COMMAND') return;
        this.handleCommand(message.command, message.payload || {})
          .then((result) => sendResponse({ ok: true, result }))
          .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
        return true;
      });
    }

    async loadIdentity() {
      const stored = await chrome.storage.local.get(['entryLiveUserId', 'entryLiveSettings']);
      if (!stored.entryLiveUserId) {
        stored.entryLiveUserId = randomId();
        await chrome.storage.local.set({ entryLiveUserId: stored.entryLiveUserId });
      }
      return { userId: stored.entryLiveUserId, settings: stored.entryLiveSettings || {} };
    }

    async start(config) {
      if (this.active) await this.stop();
      await this.bridge('PING');
      const identity = await this.loadIdentity();
      const defaults = {
        captureInterval: 1000,
        captureQuality: 58,
        displayMode: 'floating',
        shareControls: false,
      };
      this.config = { ...defaults, ...identity.settings, ...config };
      this.userId = identity.userId;
      this.mode = this.config.mode === 'mode2' ? 'mode2' : 'mode1';
      this.role = this.mode === 'mode1' ? this.config.role || 'participant' : 'member';
      this.ownerId = this.config.ownerId || (this.config.creator ? this.userId : null);
      this.leaderId = this.mode === 'mode1'
        ? (this.role === 'leader' ? this.userId : this.config.leaderId)
        : this.ownerId;
      this.startedAt = Date.now();
      this.active = true;
      this.lastEndReason = '';
      this.leaderSeenAt = this.mode === 'mode1' && this.role !== 'leader' ? Date.now() : 0;
      this.screenEnabled = this.config.screenEnabled !== false;
      this.screenShareStartedAt = this.screenEnabled && this.role === 'leader' ? Date.now() : null;
      this.leaderDrawTool = 'draw';
      this.fullStateReceived = Boolean(this.config.creator);
      this.participants.clear();
      this.lastObjectHashes.clear();
      this.lastMediaHashes.clear();
      this.objectVersions.clear();
      this.uiLocks.clear();
      this.deferredUiEvents.clear();
      this.pendingStateNotify = false;
      this.pendingUiRender = false;
      this.lastFloatingSignature = '';
      this.lamport = 0;

      const iceServers = [
        { urls: 'stun:stun.cloudflare.com:3478' },
        { urls: 'stun:stun.l.google.com:19302' },
      ];
      if (this.config.turnUrl) {
        iceServers.push({
          urls: this.config.turnUrl,
          username: this.config.turnUsername || '',
          credential: this.config.turnCredential || '',
        });
      }

      this.bus = new EntryCollabRealtime({
        url: this.config.serverUrl,
        key: this.config.anonKey,
        room: this.config.room,
        userId: this.userId,
        onEvent: (event, payload, sender) => this.onBusEvent(event, payload, sender),
        onStatus: (status, detail) => {
          this.connectionStatus = status;
          this.statusDetail = detail || '';
          if (status === 'online') this.announce();
          this.updateUi();
          this.notifyState();
        },
      });
      this.hub = new EntryCollabPeerHub({
        selfId: this.userId,
        mode: this.mode,
        leaderId: this.leaderId,
        bus: this.bus,
        iceServers,
        onData: (from, packet) => this.onData(from, packet),
        onState: (peerId, state) => this.onPeerState(peerId, state),
      });
      this.bus.connect();
      this.mountUi();
      await this.refreshOwnSummary(true);

      this.every(() => this.announce(), 4000);
      this.every(() => this.pruneParticipants(), 3000);
      if (this.mode === 'mode1') {
        this.every(() => this.refreshOwnSummary(false), 1200);
        this.every(() => this.captureFrame(), Math.max(650, Number(this.config.captureInterval) || 1000));
      } else {
        this.every(() => this.syncCollaborativeChanges(), 600);
        setTimeout(() => this.requestFullState(), 1800);
      }
      const nextStoredSettings = {
        ...identity.settings,
        displayMode: this.config.displayMode,
        captureInterval: this.config.captureInterval,
        captureQuality: this.config.captureQuality,
        shareControls: this.config.shareControls,
        turnUrl: this.config.turnUrl || '',
        turnUsername: this.config.turnUsername || '',
        turnCredential: this.config.turnCredential || '',
        lastName: this.config.name || '',
      };
      delete nextStoredSettings.serverUrl;
      delete nextStoredSettings.anonKey;
      await chrome.storage.local.set({ entryLiveSettings: nextStoredSettings });
      this.notifyState();
      return this.publicState();
    }

    every(callback, interval) {
      const timer = setInterval(() => {
        if (!this.active) return;
        Promise.resolve(callback()).catch((error) => this.setNotice(error.message, 'error'));
      }, interval);
      this.timers.add(timer);
      return timer;
    }

    announce() {
      if (!this.active || !this.bus) return;
      this.bus.send('hello', {
        user: {
          id: this.userId,
          name: this.config.name || '참여자',
          role: this.role,
          mode: this.mode,
          leaderId: this.leaderId,
          ownerId: this.ownerId,
          startedAt: this.startedAt,
          projectId: this.ownSummary?.projectId || null,
        },
      });
    }

    async onBusEvent(event, payload, sender) {
      if (!this.active) return;
      if (
        event === 'session-end' && this.mode === 'mode1' && this.role !== 'leader'
        && sender === this.leaderId
      ) {
        await this.stop(payload?.reason || '대표가 나가 연결이 종료되었습니다.');
        return;
      }
      let discoveredFromTransport = false;
      if (
        this.mode === 'mode1' && this.role !== 'leader' && !this.leaderId
        && ['signal', 'relay'].includes(event)
        && payload?.to === this.userId && payload?.from
      ) {
        this.leaderId = payload.from;
        this.leaderSeenAt = Date.now();
        this.hub.setTopology('mode1', this.leaderId);
        this.announce();
        discoveredFromTransport = true;
      }
      if (event === 'signal') {
        await this.hub.handleSignal(payload);
        if (discoveredFromTransport) await this.refreshOwnSummary(true);
        return;
      }
      if (event === 'relay') {
        this.hub.receiveRelay(payload);
        if (discoveredFromTransport) await this.refreshOwnSummary(true);
        return;
      }
      if (event === 'room-full' && payload?.to === this.userId) {
        this.setNotice('이 방은 대표 포함 5명이 모두 접속했습니다.', 'error');
        return;
      }
      if (event === 'representative-change') {
        return this.applyRepresentativeChange(payload);
      }
      if (event !== 'hello' || !payload?.user || payload.user.id === this.userId) return;
      const user = payload.user;
      if (user.mode !== this.mode) return;
      if (this.mode === 'mode1') {
        const discoveredLeader = this.role !== 'leader' && !this.leaderId && user.role === 'leader';
        if (discoveredLeader) {
          this.leaderId = user.id;
          this.leaderSeenAt = Date.now();
          this.hub.setTopology('mode1', this.leaderId);
          this.announce();
        }
        if (this.role === 'leader' && user.role !== 'leader') {
          const activeViewers = [...this.participants.values()].filter(
            (item) => item.role !== 'leader' && Date.now() - item.lastSeen < 12000
          );
          if (!this.participants.has(user.id) && activeViewers.length >= MAX_VIEWERS) {
            this.bus.send('room-full', { to: user.id });
            return;
          }
        }
        if (user.id !== this.leaderId && this.userId !== this.leaderId) return;
        if (user.id === this.leaderId) this.leaderSeenAt = Date.now();
      }
      const previous = this.participants.get(user.id) || {};
      const isNewParticipant = !previous.id;
      this.participants.set(user.id, { ...previous, ...user, lastSeen: Date.now(), peerState: previous.peerState || 'connecting' });
      await this.hub.seePeer(user.id);
      if (this.mode === 'mode1' && this.role !== 'leader' && user.id === this.leaderId) {
        await this.refreshOwnSummary(true);
      }
      if (isNewParticipant) {
        this.updateUi();
        this.notifyState();
      }

      if (this.mode === 'mode2' && !previous.id) {
        setTimeout(() => this.requestFullState(), 500);
      }
    }

    onPeerState(peerId, state) {
      const participant = this.participants.get(peerId);
      if (participant) {
        participant.peerState = state;
        participant.lastSeen = Date.now();
      }
      if (peerId === this.leaderId && state === 'connected') this.leaderSeenAt = Date.now();
      this.updateUi();
      this.notifyState();
    }

    async pruneParticipants() {
      const cutoff = Date.now() - 14000;
      let changed = false;
      let leaderExpired = false;
      for (const [id, participant] of this.participants) {
        if (participant.lastSeen < cutoff) {
          this.participants.delete(id);
          this.hub.dropPeer(id);
          if (this.mode === 'mode1' && this.role !== 'leader' && id === this.leaderId) leaderExpired = true;
          changed = true;
        }
      }
      if (
        this.mode === 'mode1' && this.role !== 'leader' && this.leaderId
        && this.leaderSeenAt && this.leaderSeenAt < cutoff
      ) leaderExpired = true;
      if (leaderExpired) {
        await this.stop('대표 연결이 끊겨 세션을 종료했습니다.');
        return;
      }
      if (changed) {
        this.updateUi();
        this.notifyState();
      }
    }

    peerIds() {
      return [...this.participants.keys()];
    }

    sendTo(peerId, packet) {
      if (!peerId || peerId === this.userId) return;
      this.hub.sendTo(peerId, packet);
    }

    sendAll(packet, ids) {
      this.hub.broadcast(packet, ids || this.peerIds());
    }

    async onData(from, packet) {
      if (!packet?.type) return;
      const participant = this.participants.get(from);
      if (participant) participant.lastSeen = Date.now();
      if (from === this.leaderId) this.leaderSeenAt = Date.now();
      switch (packet.type) {
        case 'STATE_SUMMARY':
          if (this.role !== 'leader') return;
          this.acceptParticipantSummary(from, packet);
          break;
        case 'CODE_SNAPSHOT':
          if (this.role !== 'leader') return;
          await this.acceptCodeSnapshot(from, packet.codeView);
          break;
        case 'REQUEST_CODE_SNAPSHOT':
          await this.sendCodeSnapshot(from, packet.objectId);
          break;
        case 'SCREEN_FRAME':
          if (from !== this.leaderId) return;
          this.screenEnabled = true;
          this.screenShareStartedAt = packet.startedAt || this.screenShareStartedAt || Date.now();
          this.latestFrames.screen = packet.dataUrl;
          this.loadViewerFrame('screen', packet.dataUrl, true);
          this.notifyUiEvent({ type: 'frame', kind: 'screen', dataUrl: packet.dataUrl });
          break;
        case 'SCREEN_STATUS':
          if (from !== this.leaderId) return;
          this.screenEnabled = Boolean(packet.enabled);
          this.screenShareStartedAt = this.screenEnabled ? (packet.startedAt || this.screenShareStartedAt || Date.now()) : null;
          this.updateUi();
          this.notifyState();
          break;
        case 'LEADER_CODE':
          if (from !== this.leaderId) return;
          this.latestFrames.code = packet.codeView?.image?.dataUrl || null;
          this.leaderCodeView = packet.codeView;
          if (this.ui?.viewKind === 'code') this.loadViewerFrame('code', this.latestFrames.code, true);
          this.notifyUiEvent({ type: 'frame', kind: 'code', dataUrl: this.latestFrames.code, meta: packet.codeView });
          break;
        case 'FEEDBACK_FRAME':
          if (this.role !== 'leader') return;
          this.latestFrames.feedback = packet.dataUrl;
          this.notifyUiEvent({
            type: 'feedback',
            from,
            fromName: this.participants.get(from)?.name || '참여자',
            dataUrl: packet.dataUrl,
            note: packet.note || '',
          });
          this.setNotice(`${this.participants.get(from)?.name || '참여자'}의 표시 화면을 받았습니다.`);
          break;
        case 'APPLY_CODE': {
          const applied = await this.bridge('APPLY_CODE', packet.payload);
          this.sendTo(from, { type: 'ACK', action: 'APPLY_CODE', ok: true, applied });
          this.setNotice(`${packet.payload.sourceName || '대표'}의 코드를 받았습니다.`);
          await this.refreshOwnSummary(true);
          break;
        }
        case 'MANAGER_FRAME':
          this.latestFrames.screen = packet.dataUrl;
          this.loadViewerFrame('screen', packet.dataUrl);
          this.setNotice('대표가 표시한 화면을 받았습니다.');
          break;
        case 'ACK':
          this.notifyUiEvent({ type: 'ack', from, packet });
          break;
        case 'FULL_PROJECT_REQUEST':
          await this.answerFullStateRequest(from);
          break;
        case 'FULL_PROJECT':
          await this.acceptFullProject(from, packet);
          break;
        case 'SYNC_OBJECT':
          await this.acceptObjectSync(packet);
          break;
        case 'REMOVE_OBJECT':
          await this.acceptObjectRemoval(packet);
          break;
        case 'SYNC_GLOBALS':
          await this.acceptGlobalsSync(packet);
          break;
      }
    }

    async refreshOwnSummary(forceCode) {
      if (!this.active) return;
      const summary = await this.bridge('GET_SUMMARY');
      this.ownSummary = summary;
      const summaryHash = fastHash(summary);
      const summaryChanged = forceCode || summaryHash !== this.lastSummaryHash;
      if (summaryChanged && (this.role === 'leader' || this.mode === 'mode2')) {
        this.notifyUiEvent({ type: 'own-summary', summary });
      } else if (summaryChanged && this.leaderId) {
        this.sendTo(this.leaderId, { type: 'STATE_SUMMARY', summary });
      }

      const selectedId = summary.selectedObjectId;
      const selectedMeta = summary.objects.find((object) => object.id === selectedId);
      const codeMarker = `${selectedId}:${selectedMeta?.blockCount || 0}:${summaryHash}`;
      if (forceCode || codeMarker !== this.lastSelectedCodeHash) {
        this.lastSelectedCodeHash = codeMarker;
        if (selectedId) {
          const codeView = await this.bridge(this.role === 'leader' ? 'GET_CODE_VIEW' : 'GET_CODE_DATA', { objectId: selectedId });
          if (this.role === 'leader') {
            this.ownCodeView = codeView;
            this.patchCodePreview('ownCodePreview', codeView?.image?.dataUrl, '현재 코드');
            this.notifyUiEvent({ type: 'leader-code', codeView });
          } else if (this.mode === 'mode1') {
            this.sendTo(this.leaderId, { type: 'CODE_SNAPSHOT', codeView });
          }
        }
      }
      this.lastSummaryHash = summaryHash;
      if (summaryChanged) {
        if (this.role === 'leader' || this.mode === 'mode2') this.updateUi();
        this.notifyState();
      }
    }

    acceptParticipantSummary(from, packet) {
      const participant = this.participants.get(from) || { id: from, name: '참여자' };
      participant.summary = packet.summary;
      participant.lastSeen = Date.now();
      this.participants.set(from, participant);
      this.notifyUiEvent({ type: 'participant-summary', participant: this.cleanParticipant(participant) });
      this.updateUi();
      this.notifyState();
    }

    async acceptCodeSnapshot(from, codeView) {
      if (codeView?.code && !codeView.image?.dataUrl) {
        codeView = { ...codeView, image: await this.bridge('RENDER_CODE', { code: codeView.code }) };
      }
      const participant = this.participants.get(from) || { id: from, name: '참여자' };
      participant.codeView = codeView;
      participant.lastSeen = Date.now();
      this.participants.set(from, participant);
      if (from === this.ui?.selectedParticipantId && codeView?.objectId === this.ui?.selectedParticipantObjectId) {
        this.patchCodePreview('participantCodePreview', codeView?.image?.dataUrl, '참여자 코드');
      }
      this.notifyUiEvent({ type: 'participant-code', participantId: from, codeView });
      this.notifyState();
    }

    async sendCodeSnapshot(to, objectId) {
      const codeView = await this.bridge('GET_CODE_DATA', { objectId });
      this.sendTo(to, { type: 'CODE_SNAPSHOT', codeView });
    }

    async captureFrame() {
      if (!this.active || this.mode !== 'mode1' || this.role !== 'leader' || !this.screenEnabled || this.captureBusy) return;
      if (this.config.captureBackend === 'tab' && this.config.displayMode !== 'floating') return;
      if (!this.peerIds().length) return;
      this.captureBusy = true;
      try {
        if (!this.config.shareControls) this.setControlsVisible(false);
        await sleep(45);
        const result = await chrome.runtime.sendMessage({
          type: 'ENTRY_LIVE_CAPTURE',
          quality: this.config.captureQuality,
        });
        if (result?.ok && result.dataUrl) {
          this.latestFrames.screen = result.dataUrl;
          this.sendAll({ type: 'SCREEN_FRAME', dataUrl: result.dataUrl, stamp: Date.now(), startedAt: this.screenShareStartedAt || this.startedAt });
          if (this.config.displayMode !== 'floating') this.notifyUiEvent({ type: 'leader-screen', dataUrl: result.dataUrl });
        }
      } finally {
        this.setControlsVisible(true);
        this.captureBusy = false;
      }
    }

    setControlsVisible(visible) {
      if (this.ui?.host) this.ui.host.style.visibility = visible ? 'visible' : 'hidden';
    }

    async sendSelectedCode({ scope = 'object', objectId, targets = [] }) {
      if (this.role !== 'leader') throw new Error('대표만 코드를 전송할 수 있습니다.');
      const source = await this.bridge('GET_SOURCE_CODE', { scope, objectId });
      if (!targets.length) throw new Error('받을 사용자를 선택해 주세요.');
      for (const target of targets) {
        const userId = typeof target === 'string' ? target : target.userId;
        const payload = {
          code: source.code,
          sourceName: source.objectName,
          scope,
          targetMode: target.targetMode || 'current',
          targetObjectId: target.targetObjectId || null,
          baseObjectId: target.baseObjectId || null,
          newObjectName: target.newObjectName || `${source.objectName} 작업`,
        };
        this.sendTo(userId, { type: 'APPLY_CODE', payload });
      }
      this.setNotice(`${targets.length}명에게 코드를 전송했습니다.`);
      return { count: targets.length };
    }

    requestParticipantCode(userId, objectId) {
      this.sendTo(userId, { type: 'REQUEST_CODE_SNAPSHOT', objectId });
    }

    async changeRepresentative(nextLeaderId) {
      if (this.mode !== 'mode1' || this.role !== 'leader') throw new Error('현재 대표만 변경할 수 있습니다.');
      if (!this.participants.has(nextLeaderId)) throw new Error('접속 중인 사용자를 선택해 주세요.');
      this.bus.send('representative-change', { from: this.userId, nextLeaderId, at: Date.now() });
      await this.applyRepresentativeChange({ nextLeaderId });
      return true;
    }

    async applyRepresentativeChange(payload) {
      if (!payload?.nextLeaderId) return;
      this.leaderId = payload.nextLeaderId;
      this.role = this.userId === this.leaderId ? 'leader' : 'participant';
      for (const participant of this.participants.values()) {
        participant.role = participant.id === this.leaderId ? 'leader' : 'participant';
      }
      this.hub.setTopology('mode1', this.leaderId);
      for (const id of this.peerIds()) await this.hub.seePeer(id);
      this.mountUi(true);
      this.announce();
      await this.refreshOwnSummary(true);
      this.setNotice(this.role === 'leader' ? '이제 내가 대표입니다.' : '대표가 변경되었습니다.');
      this.notifyState();
    }

    async syncCollaborativeChanges() {
      if (!this.active || this.mode !== 'mode2' || (!this.fullStateReceived && !this.config.creator)) return;
      const snapshot = await this.bridge('GET_COLLAB_SNAPSHOT');
      if (!this.collabBaseline) {
        this.collabBaseline = true;
        for (const object of snapshot.objects) {
          this.lastObjectHashes.set(object.id, fastHash(object));
          this.lastMediaHashes.set(object.id, fastHash({ sprite: object.sprite, selectedPictureId: object.selectedPictureId }));
        }
        this.lastGlobalsHash = fastHash(snapshot.globals);
        this.lastScenesHash = fastHash(snapshot.globals?.scenes || []);
        return;
      }
      const liveIds = new Set(snapshot.objects.map((object) => object.id));
      let needsFullSync = false;
      for (const object of snapshot.objects) {
        const hash = fastHash(object);
        if (this.lastObjectHashes.get(object.id) === hash) continue;
        const mediaHash = fastHash({ sprite: object.sprite, selectedPictureId: object.selectedPictureId });
        if (this.lastMediaHashes.has(object.id) && this.lastMediaHashes.get(object.id) !== mediaHash) needsFullSync = true;
        this.lastMediaHashes.set(object.id, mediaHash);
        this.lastObjectHashes.set(object.id, hash);
        const version = this.nextVersion();
        this.objectVersions.set(object.id, version);
        this.sendAll({ type: 'SYNC_OBJECT', object, version });
      }
      for (const objectId of [...this.lastObjectHashes.keys()]) {
        if (liveIds.has(objectId)) continue;
        this.lastObjectHashes.delete(objectId);
        this.lastMediaHashes.delete(objectId);
        const version = this.nextVersion();
        this.objectVersions.set(objectId, version);
        this.sendAll({ type: 'REMOVE_OBJECT', objectId, version });
      }
      const globalsHash = fastHash(snapshot.globals);
      const scenesHash = fastHash(snapshot.globals?.scenes || []);
      if (this.lastScenesHash && scenesHash !== this.lastScenesHash) needsFullSync = true;
      this.lastScenesHash = scenesHash;
      if (globalsHash !== this.lastGlobalsHash) {
        this.lastGlobalsHash = globalsHash;
        this.sendAll({ type: 'SYNC_GLOBALS', globals: snapshot.globals, version: this.nextVersion() });
      }
      if (needsFullSync && Date.now() - (this.lastAutomaticFullSync || 0) > 2500) {
        this.lastAutomaticFullSync = Date.now();
        const project = await this.bridge('GET_FULL_PROJECT', {}, 60000);
        this.sendAll({ type: 'FULL_PROJECT', project, version: this.nextVersion(), force: true });
      }
    }

    nextVersion() {
      return { clock: ++this.lamport, actor: this.userId };
    }

    versionIsNewer(incoming, current) {
      if (!current) return true;
      if ((incoming?.clock || 0) !== (current.clock || 0)) return (incoming?.clock || 0) > (current.clock || 0);
      return String(incoming?.actor || '').localeCompare(String(current.actor || '')) > 0;
    }

    async acceptObjectSync(packet) {
      if (this.mode !== 'mode2' || !packet.object?.id) return;
      this.lamport = Math.max(this.lamport, packet.version?.clock || 0) + 1;
      const current = this.objectVersions.get(packet.object.id);
      if (!this.versionIsNewer(packet.version, current)) return;
      this.objectVersions.set(packet.object.id, packet.version);
      this.lastObjectHashes.set(packet.object.id, fastHash(packet.object));
      await this.bridge('APPLY_OBJECT', { object: packet.object });
      this.setNotice('다른 사용자의 변경을 반영했습니다.');
    }

    async acceptObjectRemoval(packet) {
      if (this.mode !== 'mode2' || !packet.objectId) return;
      const current = this.objectVersions.get(packet.objectId);
      if (!this.versionIsNewer(packet.version, current)) return;
      this.objectVersions.set(packet.objectId, packet.version);
      this.lastObjectHashes.delete(packet.objectId);
      await this.bridge('REMOVE_OBJECT', { objectId: packet.objectId });
    }

    async acceptGlobalsSync(packet) {
      if (this.mode !== 'mode2' || !packet.globals) return;
      this.lamport = Math.max(this.lamport, packet.version?.clock || 0) + 1;
      this.lastGlobalsHash = fastHash(packet.globals);
      await this.bridge('APPLY_GLOBALS', { globals: packet.globals });
    }

    requestFullState() {
      if (!this.active || this.mode !== 'mode2' || this.config.creator || this.fullStateReceived) return;
      this.sendAll({ type: 'FULL_PROJECT_REQUEST', requester: this.userId });
    }

    async answerFullStateRequest(to) {
      if (this.mode !== 'mode2' || !this.fullStateReceived) return;
      const online = [this.userId, ...this.peerIds()].sort();
      const delay = Math.max(0, online.indexOf(this.userId)) * 450;
      await sleep(delay);
      const project = await this.bridge('GET_FULL_PROJECT', {}, 60000);
      this.sendTo(to, { type: 'FULL_PROJECT', project, version: this.nextVersion() });
    }

    async acceptFullProject(_from, packet) {
      if (this.mode !== 'mode2' || (this.fullStateReceived && !packet.force) || !packet.project) return;
      await this.bridge('APPLY_FULL_PROJECT', { project: packet.project }, 60000);
      this.fullStateReceived = true;
      this.collabBaseline = false;
      this.lastMediaHashes.clear();
      this.setNotice('공동 작품을 불러왔습니다.');
      this.notifyState();
    }

    async forceFullSync() {
      if (this.mode !== 'mode2') throw new Error('공동 편집 모드에서만 사용할 수 있습니다.');
      const project = await this.bridge('GET_FULL_PROJECT', {}, 60000);
      this.sendAll({ type: 'FULL_PROJECT', project, version: this.nextVersion(), force: true });
      return true;
    }

    cleanParticipant(participant) {
      return {
        id: participant.id,
        name: participant.name,
        role: participant.role,
        peerState: participant.peerState,
        lastSeen: participant.lastSeen,
        summary: participant.summary || null,
        codeView: participant.codeView || null,
      };
    }

    inviteCode() {
      if (!this.active) return '';
      return EntryInviteCodec.encode({
        v: 1,
        room: this.config.room,
        mode: this.mode,
        leaderId: this.mode === 'mode1' ? this.leaderId : undefined,
        ownerId: this.mode === 'mode2' ? this.ownerId : undefined,
      });
    }

    publicState() {
      if (!this.active) return { active: false, endReason: this.lastEndReason || '' };
      return {
        active: true,
        mode: this.mode,
        role: this.role,
        userId: this.userId,
        name: this.config.name || '참여자',
        room: this.config.room,
        leaderId: this.leaderId,
        ownerId: this.ownerId,
        connectionStatus: this.connectionStatus || 'connecting',
        statusDetail: this.statusDetail || '',
        screenEnabled: this.screenEnabled,
        shareControls: Boolean(this.config.shareControls),
        displayMode: this.config.displayMode || 'floating',
        inviteCode: this.inviteCode(),
        participants: [...this.participants.values()].map((item) => this.cleanParticipant(item)),
        ownSummary: this.ownSummary || null,
        ownCodeView: this.ownCodeView || null,
        fullStateReceived: this.fullStateReceived,
        latestFrames: this.config.displayMode === 'floating' ? {} : this.latestFrames,
        notice: this.notice || null,
      };
    }

    notifyState() {
      if (this.uiLocks.size) {
        this.pendingStateNotify = true;
        return;
      }
      this.sendStateNow();
    }

    sendStateNow() {
      chrome.runtime.sendMessage({ type: 'ENTRY_LIVE_SESSION_STATE', state: this.publicState() }).catch(() => {});
    }

    notifyUiEvent(event) {
      if (this.uiLocks.size) {
        const identity = event?.type === 'participant-summary'
          ? event.participant?.id
          : event?.type === 'participant-code'
            ? event.participantId
            : event?.type === 'frame'
              ? event.kind
              : event?.type === 'feedback'
                ? `${event.from}:${event.at || Date.now()}`
                : '';
        const key = ['leader-screen', 'notice'].includes(event?.type)
          ? event.type
          : `${event?.type || 'event'}:${identity}`;
        this.deferredUiEvents.set(key, event);
        while (this.deferredUiEvents.size > 40) {
          this.deferredUiEvents.delete(this.deferredUiEvents.keys().next().value);
        }
        return;
      }
      this.sendUiEventNow(event);
    }

    sendUiEventNow(event) {
      chrome.runtime.sendMessage({ type: 'ENTRY_LIVE_UI_EVENT', event }).catch(() => {});
    }

    setUiEditing(token, locked) {
      const id = String(token || 'ui');
      if (locked) {
        this.uiLocks.add(id);
        return true;
      }
      this.uiLocks.delete(id);
      if (!this.uiLocks.size) this.flushUiUpdates();
      return true;
    }

    flushUiUpdates() {
      if (!this.active) {
        this.deferredUiEvents.clear();
        this.pendingStateNotify = false;
        this.pendingUiRender = false;
        return;
      }
      const shouldRender = this.pendingUiRender;
      const shouldNotify = this.pendingStateNotify;
      const events = [...this.deferredUiEvents.values()];
      this.pendingUiRender = false;
      this.pendingStateNotify = false;
      this.deferredUiEvents.clear();
      if (shouldRender) this.updateUi(true);
      if (shouldNotify || events.length) this.sendStateNow();
      for (const event of events) this.sendUiEventNow(event);
    }

    setNotice(text, tone = 'normal') {
      this.notice = { text, tone, at: Date.now() };
      this.patchFloatingNotice();
      this.notifyUiEvent({ type: 'notice', notice: this.notice });
      setTimeout(() => {
        if (this.notice?.text === text) {
          this.notice = null;
          this.patchFloatingNotice();
          this.notifyUiEvent({ type: 'notice', notice: null });
        }
      }, 4000);
    }

    async handleCommand(command, payload) {
      switch (command) {
        case 'START': return this.start(payload);
        case 'STOP': return this.stop();
        case 'SET_DISPLAY':
          this.config.displayMode = payload.displayMode;
          await chrome.storage.local.set({ entryLiveSettings: { ...(await chrome.storage.local.get('entryLiveSettings')).entryLiveSettings, displayMode: payload.displayMode } });
          this.mountUi(true);
          this.notifyState();
          return true;
        case 'OPEN_PANEL':
        case 'OPEN_MANAGER':
          if (command === 'OPEN_MANAGER' && this.mode === 'mode1' && this.role === 'leader' && this.config.captureBackend === 'tab') {
            this.config.displayMode = 'newpage';
            this.mountUi(true);
            this.notifyState();
          }
          return chrome.runtime.sendMessage({
            type: 'ENTRY_LIVE_OPEN_PAGE',
            page: command === 'OPEN_MANAGER' ? 'manager' : 'panel',
          });
        case 'SET_SCREEN': {
          const nextEnabled = Boolean(payload.enabled);
          if (nextEnabled && !this.screenEnabled) this.screenShareStartedAt = Date.now();
          if (!nextEnabled) this.screenShareStartedAt = null;
          this.screenEnabled = nextEnabled;
          if (this.role === 'leader' && this.mode === 'mode1') {
            this.sendAll({ type: 'SCREEN_STATUS', enabled: this.screenEnabled, startedAt: this.screenShareStartedAt });
          }
          this.updateUi();
          this.notifyState();
          return true;
        }
        case 'SET_SHARE_CONTROLS':
          this.config.shareControls = Boolean(payload.enabled);
          this.updateUi();
          this.notifyState();
          return true;
        case 'SEND_CODE': return this.sendSelectedCode(payload);
        case 'REQUEST_PARTICIPANT_CODE':
          this.requestParticipantCode(payload.userId, payload.objectId);
          return true;
        case 'CHANGE_LEADER': return this.changeRepresentative(payload.userId);
        case 'SEND_FRAME':
          for (const userId of payload.userIds || []) this.sendTo(userId, { type: 'MANAGER_FRAME', dataUrl: payload.dataUrl });
          return true;
        case 'SEND_FEEDBACK':
          if (payload.dataUrl) {
            if (!this.leaderId) throw new Error('대표가 연결되지 않았습니다.');
            this.sendTo(this.leaderId, { type: 'FEEDBACK_FRAME', dataUrl: payload.dataUrl, note: payload.note || '' });
            this.setNotice('표시한 화면을 대표에게 보냈습니다.');
            return true;
          }
          return this.sendFeedback(payload.note || '');
        case 'FORCE_FULL_SYNC': return this.forceFullSync();
        case 'SET_UI_EDITING': return this.setUiEditing(payload.token, Boolean(payload.locked));
        case 'GET_MANAGER_STATE': return this.publicState();
        case 'SET_DRAW_TOOL':
          return this.setLeaderDrawTool(payload.tool);
        case 'CLEAR_DRAWING':
          this.clearLeaderDrawing();
          return true;
        case 'TOGGLE_DRAW':
          this.toggleLeaderDrawing(payload.enabled);
          return true;
        default: throw new Error('지원하지 않는 동작입니다.');
      }
    }

    async stop(reason = '') {
      if (!this.active) return true;
      if (this.mode === 'mode1' && this.role === 'leader') {
        this.bus?.send('session-end', { reason: reason || '대표가 나가 연결이 종료되었습니다.' });
        await sleep(80);
      }
      this.lastEndReason = reason;
      this.active = false;
      for (const timer of this.timers) clearInterval(timer);
      this.timers.clear();
      this.bus?.close();
      this.hub?.close();
      this.participants.clear();
      this.unmountUi();
      this.uiLocks.clear();
      this.deferredUiEvents.clear();
      this.pendingStateNotify = false;
      this.pendingUiRender = false;
      this.connectionStatus = 'offline';
      this.sendStateNow();
      return true;
    }

    mountUi(force = false) {
      if (force) this.unmountUi();
      if (!this.active || this.config.displayMode !== 'floating') return;
      const host = document.createElement('div');
      host.id = 'entry-live-studio-host';
      const shadow = host.attachShadow({ mode: 'open' });
      document.documentElement.appendChild(host);
      this.ui = {
        host, shadow, collapsed: false, viewKind: 'screen', leaderView: 'stream',
        selectedParticipantId: null, selectedParticipantObjectId: null,
        zoom: 1, panX: 0, panY: 0, tool: 'pan',
        panelX: null, panelY: null,
      };
      this.renderUi();
      if (this.role === 'leader') this.ensureLeaderDrawingCanvas();
    }

    unmountUi() {
      const releasedUiLock = this.uiLocks.has('leader-draw') || this.uiLocks.has('floating-feedback');
      this.ui?.host?.remove();
      this.ui = null;
      document.getElementById('entry-live-studio-draw-host')?.remove();
      if (this.leaderDrawResizeHandler) removeEventListener('resize', this.leaderDrawResizeHandler);
      if (this.leaderDrawKeyHandler) removeEventListener('keydown', this.leaderDrawKeyHandler, true);
      this.leaderDrawResizeHandler = null;
      this.leaderDrawKeyHandler = null;
      this.drawCanvas = null;
      this.drawContext = null;
      this.drawingEnabled = false;
      this.uiLocks.delete('leader-draw');
      this.uiLocks.delete('floating-feedback');
      this.lastFloatingSignature = '';
      if (releasedUiLock && !this.uiLocks.size && this.active) queueMicrotask(() => this.flushUiUpdates());
    }

    floatingSignature() {
      const participants = [...this.participants.values()].map((item) => ({
        id: item.id,
        name: item.name,
        role: item.role,
        peerState: item.peerState,
        selectedObjectId: item.summary?.selectedObjectId || '',
        objects: (item.summary?.objects || []).map((object) => [object.id, object.name, object.blockCount]),
      }));
      return fastHash({
        active: this.active,
        role: this.role,
        mode: this.mode,
        status: this.connectionStatus,
        screen: this.screenEnabled,
        drawing: this.drawingEnabled,
        controls: this.config?.shareControls,
        participants,
        objects: (this.ownSummary?.objects || []).map((object) => [object.id, object.name, object.blockCount, object.selected]),
        collapsed: this.ui?.collapsed,
        view: this.ui?.viewKind,
        leaderView: this.ui?.leaderView,
        selectedParticipantId: this.ui?.selectedParticipantId,
        selectedParticipantObjectId: this.ui?.selectedParticipantObjectId,
      });
    }

    updateUi(force = false) {
      if (!this.ui?.shadow) return;
      if (this.uiLocks.size && !force) {
        this.pendingUiRender = true;
        return;
      }
      const signature = this.floatingSignature();
      if (!force && signature === this.lastFloatingSignature) return;
      this.renderUi();
      this.lastFloatingSignature = signature;
    }

    patchFloatingNotice() {
      if (!this.ui?.shadow) return;
      if (this.uiLocks.size) {
        this.pendingUiRender = true;
        return;
      }
      const element = this.ui.shadow.getElementById('floatingNotice');
      if (!element) return;
      element.hidden = !this.notice;
      element.className = `notice ${this.notice?.tone === 'error' ? 'error' : ''}`;
      element.textContent = this.notice?.text || '';
    }

    patchCodePreview(id, dataUrl, alt) {
      if (!this.ui?.shadow) return;
      if (this.uiLocks.size) {
        this.pendingUiRender = true;
        return;
      }
      const preview = this.ui.shadow.getElementById(id);
      if (!preview) return;
      preview.replaceChildren();
      if (!dataUrl) {
        const empty = document.createElement('span');
        empty.textContent = '코드 없음';
        preview.appendChild(empty);
        return;
      }
      const image = document.createElement('img');
      image.src = dataUrl;
      image.alt = alt;
      preview.appendChild(image);
    }

    renderUi() {
      const ui = this.ui;
      if (!ui) return;
      const isLeader = this.role === 'leader';
      const isMode1 = this.mode === 'mode1';
      const onlineCount = this.participants.size + 1;
      const people = [...this.participants.values()].filter((item) => item.id !== this.leaderId || !isMode1);
      if (!people.some((item) => item.id === ui.selectedParticipantId)) ui.selectedParticipantId = people[0]?.id || null;
      const selectedParticipant = people.find((item) => item.id === ui.selectedParticipantId);
      const selectedParticipantObjects = selectedParticipant?.summary?.objects || [];
      if (!selectedParticipantObjects.some((item) => item.id === ui.selectedParticipantObjectId)) {
        ui.selectedParticipantObjectId = selectedParticipant?.summary?.selectedObjectId || selectedParticipantObjects[0]?.id || null;
      }
      const participants = people
        .map((item) => `<label class="person"><input type="checkbox" data-user="${escapeHtml(item.id)}"><span>${escapeHtml(item.name)}</span><i class="${item.peerState === 'connected' ? 'on' : ''}"></i></label>`)
        .join('');
      const managerPeople = people
        .map((item) => `<button data-manage-user="${escapeHtml(item.id)}" class="mini-person ${item.id === ui.selectedParticipantId ? 'active' : ''}"><span>${escapeHtml(item.name)}</span><i class="${item.peerState === 'connected' ? 'on' : ''}"></i></button>`)
        .join('');
      const objectOptions = (this.ownSummary?.objects || [])
        .map((item) => `<option value="${escapeHtml(item.id)}" ${item.selected ? 'selected' : ''}>${escapeHtml(item.name)}</option>`)
        .join('');
      const selectedObject = this.ownSummary?.objects?.find((item) => item.selected);
      const ownCodeImage = this.ownCodeView?.image?.dataUrl || '';
      const participantCodeImage = selectedParticipant?.codeView?.objectId === ui.selectedParticipantObjectId
        ? selectedParticipant.codeView?.image?.dataUrl || ''
        : '';
      const participantObjectOptions = selectedParticipantObjects
        .map((item) => `<option value="${escapeHtml(item.id)}" ${item.id === ui.selectedParticipantObjectId ? 'selected' : ''}>${escapeHtml(item.name)}</option>`)
        .join('');
      const panelStyle = Number.isFinite(ui.panelX) && Number.isFinite(ui.panelY)
        ? `left:${ui.panelX}px;top:${ui.panelY}px;right:auto;bottom:auto`
        : '';
      ui.shadow.innerHTML = `
        <style>${this.uiCss()}</style>
        <section class="panel ${ui.collapsed ? 'collapsed' : ''}" style="${panelStyle}">
          <header id="dragHeader"><div><b>Entry Live</b><small>${isMode1 ? (isLeader ? '대표' : '참여자') : '공동 편집'} · ${onlineCount}명</small></div><button id="collapse">${ui.collapsed ? '＋' : '−'}</button></header>
          <div class="body">
            <div id="floatingNotice" class="notice ${this.notice?.tone === 'error' ? 'error' : ''}" ${this.notice ? '' : 'hidden'}>${escapeHtml(this.notice?.text || '')}</div>
            <div class="room"><span>방 ${escapeHtml(this.config.room)}</span><span class="status ${this.connectionStatus === 'online' ? 'on' : ''}">${this.connectionStatus === 'online' ? '연결됨' : '연결 중'}</span></div>
            ${isMode1 && isLeader ? `
              <div class="tabs leader-tabs"><button data-leader-view="stream" class="${ui.leaderView === 'stream' ? 'active' : ''}">송출</button><button data-leader-view="manage" class="${ui.leaderView === 'manage' ? 'active' : ''}">관리</button><button data-leader-view="code" class="${ui.leaderView === 'code' ? 'active' : ''}">코드</button></div>
              ${ui.leaderView === 'stream' ? `
                <div class="row"><button id="screen" class="wide ${this.screenEnabled ? 'primary' : ''}">${this.screenEnabled ? '송출 중' : '송출 시작'}</button><button id="draw" class="wide ${this.drawingEnabled ? 'active' : ''}">${this.drawingEnabled ? '그리기 완료' : '화면에 그리기'}</button><button id="clearDraw">${this.drawingEnabled ? '취소' : '그림 지우기'}</button></div>
                <label class="switch"><input id="shareControls" type="checkbox" ${this.config.shareControls ? 'checked' : ''}><span>박스도 송출</span></label>
              ` : ui.leaderView === 'manage' ? `
                <div class="mini-list">${managerPeople || '<span class="empty-line">참여자 없음</span>'}</div>
                <select id="manageObject" ${selectedParticipant ? '' : 'disabled'}>${participantObjectOptions}</select>
                <div id="participantCodePreview" class="code-preview">${participantCodeImage ? `<img src="${participantCodeImage}" alt="참여자 코드">` : '<span>코드 없음</span>'}</div>
                <div class="sendbox"><div class="grid"><select id="sourceObject">${objectOptions}</select><select id="scope"><option value="object">전체</option><option value="thread">선택 묶음</option><option value="below">선택 아래</option></select></div><button id="quickSend" class="primary wide" ${selectedParticipant ? '' : 'disabled'}>선택 사용자에게 보내기</button></div>
                <button id="manager" class="wide block-button">전체 관리자 화면</button>
              ` : `
                <div class="code-title">${escapeHtml(selectedObject?.name || '현재 오브젝트')}</div>
                <div id="ownCodePreview" class="code-preview code-only">${ownCodeImage ? `<img src="${ownCodeImage}" alt="현재 코드">` : '<span>코드 없음</span>'}</div>
              `}
              <div class="row footer-row"><button id="panel" class="wide">새 페이지</button></div>
            ` : ''}
            ${isMode1 && !isLeader ? `
              <div class="tabs"><button data-view="screen" class="${ui.viewKind === 'screen' ? 'active' : ''}">대표 화면</button><button data-view="code" class="${ui.viewKind === 'code' ? 'active' : ''}">대표 코드</button></div>
              <div class="viewer"><canvas id="viewerCanvas"></canvas><canvas id="annotCanvas"></canvas><div class="empty">화면을 기다리는 중</div></div>
              <div class="row tools"><button data-tool="pan" class="${ui.tool === 'pan' ? 'active' : ''}">이동</button><button data-tool="draw" class="${ui.tool === 'draw' ? 'active' : ''}">그리기</button><button data-tool="erase" class="${ui.tool === 'erase' ? 'active' : ''}">지우개</button><button id="zoomOut">−</button><button id="zoomReset">100%</button><button id="zoomIn">＋</button></div>
              <div class="row"><button id="feedback" class="primary wide">전송</button><button id="cancelFeedback">취소</button><button id="panel">새 페이지</button></div>
            ` : ''}
            ${!isMode1 ? `
              <div class="row"><button id="forceSync" class="wide">전체 동기화</button><button id="panel">새 페이지</button></div>
            ` : ''}
          </div>
        </section>`;
      this.bindUiEvents();
      if (isMode1 && !isLeader) {
        const frame = ui.viewKind === 'code' ? this.latestFrames.code : this.latestFrames.screen;
        if (frame) this.loadViewerFrame(ui.viewKind, frame, true);
      }
      this.lastFloatingSignature = this.floatingSignature();
    }

    uiCss() {
      return `
        *{box-sizing:border-box}button,select,input{font:inherit}[hidden]{display:none!important}
        .panel{position:fixed;right:18px;bottom:18px;width:410px;max-height:calc(100vh - 24px);overflow:hidden;color:#1d2636;background:#fff;border:1px solid #dfe5ef;border-radius:16px;box-shadow:0 18px 48px rgba(22,34,55,.22);font:13px/1.4 system-ui,-apple-system,"Noto Sans KR",sans-serif}
        .panel.collapsed{width:176px}.panel header{height:48px;display:flex;align-items:center;justify-content:space-between;padding:0 9px 0 14px;background:#fff;border-bottom:1px solid #edf0f5;cursor:grab;touch-action:none;user-select:none}.panel header:active{cursor:grabbing}.panel header div{display:flex;align-items:baseline;gap:7px;pointer-events:none}.panel header b{font-size:15px}.panel header small{color:#7a8497}.panel header button{width:31px;height:31px;border:0;border-radius:9px;background:#f1f4f8}.collapsed .body{display:none}
        .body{padding:11px;max-height:calc(100vh - 66px);overflow:auto}.notice{padding:8px 10px;margin-bottom:8px;border-radius:9px;background:#eef7ff;color:#1769aa}.notice.error{background:#fff0f1;color:#c43b4d}.room,.row,.grid,.switch{display:flex;align-items:center;gap:7px}.room{justify-content:space-between;margin-bottom:9px;color:#687287}.status{display:flex;align-items:center;gap:5px}.status:before{content:"";width:7px;height:7px;border-radius:50%;background:#aab1bd}.status.on:before,.person i.on,.mini-person i.on{background:#2ac27a}.row{margin-top:8px}.row button{flex:0 0 auto}
        button,select{border:1px solid #dbe1ea;background:#fff;color:#344054;border-radius:9px;padding:8px 9px;cursor:pointer}button:hover{background:#f6f8fb}button.primary{border-color:#6d5dfc;background:#6d5dfc;color:#fff}button.active{border-color:#6d5dfc;color:#5b4aea;background:#f0eeff}button:disabled{opacity:.45;cursor:default}.wide{flex:1!important}.block-button{width:100%;margin-top:8px}
        .tabs{display:flex;gap:4px;margin-bottom:8px}.tabs button{flex:1;border:0;background:#f2f4f7}.tabs button.active{color:#5143d8;background:#eeecff}.sendbox{margin-top:8px;padding:9px;border-radius:11px;background:#f7f8fb}.grid{margin-bottom:7px}.grid select{width:50%;min-width:0}.switch{margin:9px 2px;color:#5e6879}.switch input{width:auto}.footer-row{border-top:1px solid #edf0f4;padding-top:8px}
        .mini-list{display:flex;gap:5px;overflow:auto;padding-bottom:6px}.mini-person{display:flex;align-items:center;gap:6px;white-space:nowrap}.mini-person i,.person i{width:6px;height:6px;border-radius:50%;background:#b8bec9}.empty-line{padding:8px;color:#8b94a3}#manageObject{width:100%;margin-bottom:7px}.code-title{margin:4px 1px 7px;font-weight:700}.code-preview{height:180px;display:grid;place-items:center;overflow:auto;border:1px solid #e1e6ee;border-radius:11px;background:#eef1f6;color:#929baa}.code-preview.code-only{height:285px}.code-preview img{display:block;max-width:100%;max-height:100%;object-fit:contain}
        .viewer{height:250px;overflow:hidden;position:relative;border:1px solid #e1e6ee;border-radius:11px;background:#eef1f6;touch-action:none}.viewer canvas{position:absolute;transform-origin:0 0;max-width:none}.viewer .empty{position:absolute;inset:0;display:grid;place-items:center;color:#929baa;pointer-events:none}.viewer.has-frame .empty{display:none}.tools{overflow-x:auto}.tools button{padding:6px 8px;white-space:nowrap}`;
    }

    bindUiEvents() {
      const root = this.ui.shadow;
      root.getElementById('collapse')?.addEventListener('click', () => {
        this.ui.collapsed = !this.ui.collapsed;
        this.renderUi();
      });
      root.querySelectorAll('[data-leader-view]').forEach((button) => button.addEventListener('click', () => {
        this.ui.leaderView = button.dataset.leaderView;
        this.renderUi();
        if (this.ui.leaderView === 'manage' && this.ui.selectedParticipantId && this.ui.selectedParticipantObjectId) {
          this.requestParticipantCode(this.ui.selectedParticipantId, this.ui.selectedParticipantObjectId);
        }
      }));
      root.querySelectorAll('[data-manage-user]').forEach((button) => button.addEventListener('click', () => {
        this.ui.selectedParticipantId = button.dataset.manageUser;
        const participant = this.participants.get(this.ui.selectedParticipantId);
        const objectId = participant?.summary?.selectedObjectId || participant?.summary?.objects?.[0]?.id;
        this.ui.selectedParticipantObjectId = objectId || null;
        if (objectId) this.requestParticipantCode(this.ui.selectedParticipantId, objectId);
        this.renderUi();
      }));
      root.getElementById('manageObject')?.addEventListener('change', (event) => {
        this.ui.selectedParticipantObjectId = event.target.value;
        this.requestParticipantCode(this.ui.selectedParticipantId, this.ui.selectedParticipantObjectId);
        this.patchCodePreview('participantCodePreview', '', '참여자 코드');
      });
      root.getElementById('screen')?.addEventListener('click', () => this.handleCommand('SET_SCREEN', { enabled: !this.screenEnabled }));
      root.getElementById('draw')?.addEventListener('click', () => this.toggleLeaderDrawing(!this.drawingEnabled));
      root.getElementById('clearDraw')?.addEventListener('click', () => {
        this.clearLeaderDrawing();
        if (this.drawingEnabled) this.toggleLeaderDrawing(false);
      });
      root.getElementById('shareControls')?.addEventListener('change', (event) => this.handleCommand('SET_SHARE_CONTROLS', { enabled: event.target.checked }));
      root.getElementById('manager')?.addEventListener('click', () => this.handleCommand('OPEN_MANAGER', {}));
      root.getElementById('panel')?.addEventListener('click', () => this.handleCommand('OPEN_PANEL', {}));
      root.getElementById('quickSend')?.addEventListener('click', () => {
        const checkedUsers = [...root.querySelectorAll('[data-user]:checked')].map((input) => input.dataset.user);
        const userIds = checkedUsers.length ? checkedUsers : [this.ui.selectedParticipantId].filter(Boolean);
        const users = userIds.map((userId) => ({ userId, targetMode: 'current' }));
        this.sendSelectedCode({
          objectId: root.getElementById('sourceObject')?.value,
          scope: root.getElementById('scope')?.value || 'object',
          targets: users,
        }).catch((error) => this.setNotice(error.message, 'error'));
      });
      root.querySelectorAll('[data-view]').forEach((button) => button.addEventListener('click', () => {
        this.ui.viewKind = button.dataset.view;
        this.renderUi();
      }));
      root.querySelectorAll('[data-tool]').forEach((button) => button.addEventListener('click', () => {
        this.ui.tool = button.dataset.tool;
        root.querySelectorAll('[data-tool]').forEach((item) => item.classList.toggle('active', item === button));
      }));
      root.getElementById('zoomIn')?.addEventListener('click', () => this.setViewerZoom(this.ui.zoom * 1.2));
      root.getElementById('zoomOut')?.addEventListener('click', () => this.setViewerZoom(this.ui.zoom / 1.2));
      root.getElementById('zoomReset')?.addEventListener('click', () => this.resetViewer());
      root.getElementById('feedback')?.addEventListener('click', () => this.sendFeedback(''));
      root.getElementById('cancelFeedback')?.addEventListener('click', () => this.cancelFeedbackDrawing());
      root.getElementById('forceSync')?.addEventListener('click', () => this.forceFullSync().catch((error) => this.setNotice(error.message, 'error')));
      this.bindViewerPointerEvents();
      this.bindFloatingDrag();
    }

    bindFloatingDrag() {
      const header = this.ui?.shadow?.getElementById('dragHeader');
      const panel = header?.parentElement;
      if (!header || !panel) return;
      let dragging = false;
      let offsetX = 0;
      let offsetY = 0;
      header.addEventListener('pointerdown', (event) => {
        if (event.target.closest('button')) return;
        const rect = panel.getBoundingClientRect();
        dragging = true;
        offsetX = event.clientX - rect.left;
        offsetY = event.clientY - rect.top;
        header.setPointerCapture(event.pointerId);
      });
      header.addEventListener('pointermove', (event) => {
        if (!dragging) return;
        const maxX = Math.max(0, innerWidth - panel.offsetWidth);
        const maxY = Math.max(0, innerHeight - panel.offsetHeight);
        this.ui.panelX = Math.max(0, Math.min(maxX, event.clientX - offsetX));
        this.ui.panelY = Math.max(0, Math.min(maxY, event.clientY - offsetY));
        panel.style.left = `${this.ui.panelX}px`;
        panel.style.top = `${this.ui.panelY}px`;
        panel.style.right = 'auto';
        panel.style.bottom = 'auto';
      });
      const end = () => { dragging = false; };
      header.addEventListener('pointerup', end);
      header.addEventListener('pointercancel', end);
      header.addEventListener('lostpointercapture', end);
    }

    async loadViewerFrame(kind, dataUrl, preserve = false) {
      if (!this.ui?.shadow || this.role === 'leader') return;
      if (this.ui.viewKind !== kind) return;
      if (this.uiLocks.size) {
        this.pendingUiRender = true;
        return;
      }
      const canvas = this.ui.shadow.getElementById('viewerCanvas');
      const annotation = this.ui.shadow.getElementById('annotCanvas');
      const viewer = canvas?.parentElement;
      if (!canvas || !annotation || !viewer || !dataUrl) return;
      const sequence = ++this.viewerFrameSequence;
      const image = new Image();
      image.onload = () => {
        if (sequence !== this.viewerFrameSequence || !this.ui?.shadow?.contains(canvas)) return;
        const hadFrame = Boolean(canvas.width);
        const sizeChanged = annotation.width !== (image.naturalWidth || 1280) || annotation.height !== (image.naturalHeight || 720);
        canvas.width = image.naturalWidth || 1280;
        canvas.height = image.naturalHeight || 720;
        if (sizeChanged || !preserve) {
          annotation.width = canvas.width;
          annotation.height = canvas.height;
        }
        const context = canvas.getContext('2d');
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        viewer.classList.add('has-frame');
        if (!hadFrame || sizeChanged || !preserve) this.fitViewer();
      };
      image.src = dataUrl;
    }

    fitViewer() {
      const canvas = this.ui?.shadow?.getElementById('viewerCanvas');
      const viewer = canvas?.parentElement;
      if (!canvas || !viewer || !canvas.width) return;
      this.ui.zoom = Math.min(viewer.clientWidth / canvas.width, viewer.clientHeight / canvas.height);
      this.ui.panX = (viewer.clientWidth - canvas.width * this.ui.zoom) / 2;
      this.ui.panY = (viewer.clientHeight - canvas.height * this.ui.zoom) / 2;
      this.applyViewerTransform();
    }

    resetViewer() { this.fitViewer(); }
    setViewerZoom(value) {
      this.ui.zoom = Math.max(0.15, Math.min(4, value));
      this.applyViewerTransform();
    }
    applyViewerTransform() {
      const canvas = this.ui?.shadow?.getElementById('viewerCanvas');
      const annotation = this.ui?.shadow?.getElementById('annotCanvas');
      const transform = `translate(${this.ui.panX}px,${this.ui.panY}px) scale(${this.ui.zoom})`;
      if (canvas) canvas.style.transform = transform;
      if (annotation) annotation.style.transform = transform;
      const label = this.ui?.shadow?.getElementById('zoomReset');
      if (label) label.textContent = `${Math.round(this.ui.zoom * 100)}%`;
    }

    bindViewerPointerEvents() {
      const base = this.ui?.shadow?.getElementById('viewerCanvas');
      const canvas = this.ui?.shadow?.getElementById('annotCanvas');
      if (!canvas || !base) return;
      let dragging = false;
      let previous = null;
      const point = (event) => ({
        x: (event.clientX - canvas.getBoundingClientRect().left) / this.ui.zoom,
        y: (event.clientY - canvas.getBoundingClientRect().top) / this.ui.zoom,
      });
      canvas.addEventListener('pointerdown', (event) => {
        dragging = true;
        if (this.ui.tool !== 'pan') this.setUiEditing('floating-feedback', true);
        previous = this.ui.tool === 'pan' ? { x: event.clientX, y: event.clientY } : point(event);
        canvas.setPointerCapture(event.pointerId);
      });
      canvas.addEventListener('pointermove', (event) => {
        if (!dragging) return;
        if (this.ui.tool === 'pan') {
          this.ui.panX += event.clientX - previous.x;
          this.ui.panY += event.clientY - previous.y;
          previous = { x: event.clientX, y: event.clientY };
          this.applyViewerTransform();
          return;
        }
        const now = point(event);
        const context = canvas.getContext('2d');
        context.save();
        context.lineCap = 'round';
        context.lineJoin = 'round';
        context.lineWidth = this.ui.tool === 'erase' ? 20 : 5;
        context.globalCompositeOperation = this.ui.tool === 'erase' ? 'destination-out' : 'source-over';
        context.strokeStyle = '#ff3d61';
        context.beginPath(); context.moveTo(previous.x, previous.y); context.lineTo(now.x, now.y); context.stroke();
        context.restore();
        previous = now;
      });
      const end = () => { dragging = false; previous = null; };
      canvas.addEventListener('pointerup', end);
      canvas.addEventListener('pointercancel', end);
      canvas.addEventListener('lostpointercapture', end);
      canvas.parentElement.addEventListener('wheel', (event) => {
        event.preventDefault();
        this.setViewerZoom(this.ui.zoom * (event.deltaY < 0 ? 1.1 : 0.9));
      }, { passive: false });
    }

    sendFeedback(note) {
      if (!this.leaderId) throw new Error('대표가 연결되지 않았습니다.');
      const canvas = this.ui?.shadow?.getElementById('viewerCanvas');
      const annotation = this.ui?.shadow?.getElementById('annotCanvas');
      if (!canvas?.width || !annotation) throw new Error('표시할 화면이 아직 없습니다.');
      const output = document.createElement('canvas');
      output.width = canvas.width; output.height = canvas.height;
      const context = output.getContext('2d');
      context.drawImage(canvas, 0, 0); context.drawImage(annotation, 0, 0);
      const dataUrl = output.toDataURL('image/jpeg', 0.76);
      this.sendTo(this.leaderId, { type: 'FEEDBACK_FRAME', dataUrl, note });
      this.setNotice('표시한 화면을 대표에게 보냈습니다.');
      this.clearFeedbackAnnotation();
      this.setUiEditing('floating-feedback', false);
      return true;
    }

    clearFeedbackAnnotation() {
      const annotation = this.ui?.shadow?.getElementById('annotCanvas');
      if (annotation?.width) annotation.getContext('2d').clearRect(0, 0, annotation.width, annotation.height);
    }

    cancelFeedbackDrawing() {
      this.clearFeedbackAnnotation();
      this.setUiEditing('floating-feedback', false);
      return true;
    }

    ensureLeaderDrawingCanvas() {
      if (document.getElementById('entry-live-studio-draw-host')) return;
      const host = document.createElement('div');
      host.id = 'entry-live-studio-draw-host';
      const shadow = host.attachShadow({ mode: 'open' });
      shadow.innerHTML = '<style>:host{all:initial}canvas{position:fixed;inset:0;width:100vw;height:100vh;pointer-events:none;touch-action:none}</style><canvas></canvas>';
      document.documentElement.appendChild(host);
      const canvas = shadow.querySelector('canvas');
      const resize = () => {
        if (canvas.width === innerWidth && canvas.height === innerHeight) return;
        const copy = document.createElement('canvas'); copy.width = canvas.width; copy.height = canvas.height;
        if (canvas.width) copy.getContext('2d').drawImage(canvas, 0, 0);
        canvas.width = innerWidth; canvas.height = innerHeight;
        canvas.getContext('2d').drawImage(copy, 0, 0);
      };
      resize();
      addEventListener('resize', resize);
      this.leaderDrawResizeHandler = resize;
      this.leaderDrawKeyHandler = (event) => {
        if (event.key !== 'Escape' || !this.drawingEnabled) return;
        event.preventDefault();
        this.clearLeaderDrawing();
        this.toggleLeaderDrawing(false);
      };
      addEventListener('keydown', this.leaderDrawKeyHandler, true);
      this.drawCanvas = canvas;
      this.drawContext = canvas.getContext('2d');
      let drawing = false;
      let previous = null;
      canvas.addEventListener('pointerdown', (event) => {
        if (!this.drawingEnabled) return;
        drawing = true; previous = { x: event.clientX, y: event.clientY };
        canvas.setPointerCapture(event.pointerId);
      });
      canvas.addEventListener('pointermove', (event) => {
        if (!drawing || !this.drawingEnabled) return;
        const now = { x: event.clientX, y: event.clientY };
        const ctx = this.drawContext;
        const erasing = this.leaderDrawTool === 'erase';
        ctx.save();
        ctx.globalCompositeOperation = erasing ? 'destination-out' : 'source-over';
        ctx.strokeStyle = '#ff3158'; ctx.lineWidth = erasing ? 30 : 5; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        ctx.beginPath(); ctx.moveTo(previous.x, previous.y); ctx.lineTo(now.x, now.y); ctx.stroke();
        ctx.restore();
        previous = now;
      });
      const end = () => { drawing = false; previous = null; };
      canvas.addEventListener('pointerup', end); canvas.addEventListener('pointercancel', end); canvas.addEventListener('lostpointercapture', end);
    }

    toggleLeaderDrawing(enabled) {
      if (this.role !== 'leader') return;
      this.ensureLeaderDrawingCanvas();
      this.drawingEnabled = Boolean(enabled);
      if (this.drawCanvas) {
        this.drawCanvas.style.pointerEvents = this.drawingEnabled ? 'auto' : 'none';
        this.drawCanvas.style.cursor = this.drawingEnabled ? (this.leaderDrawTool === 'erase' ? 'cell' : 'crosshair') : 'default';
      }
      if (this.drawingEnabled) {
        this.updateUi(true);
        this.setUiEditing('leader-draw', true);
      } else {
        this.setUiEditing('leader-draw', false);
        this.updateUi();
      }
    }

    setLeaderDrawTool(tool = 'draw') {
      if (this.role !== 'leader') return false;
      this.leaderDrawTool = tool === 'erase' ? 'erase' : 'draw';
      this.ensureLeaderDrawingCanvas();
      if (this.drawCanvas) this.drawCanvas.style.cursor = this.drawingEnabled ? (this.leaderDrawTool === 'erase' ? 'cell' : 'crosshair') : 'default';
      this.updateUi();
      return true;
    }

    clearLeaderDrawing() {
      if (this.drawCanvas && this.drawContext) this.drawContext.clearRect(0, 0, this.drawCanvas.width, this.drawCanvas.height);
    }
  }

  globalThis.__entryLiveStudio = new EntryLiveStudio();
})();
