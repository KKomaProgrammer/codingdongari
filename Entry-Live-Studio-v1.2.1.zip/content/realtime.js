(function () {
  class EntryCollabRealtime {
    constructor({ url, key, room, userId, onEvent, onStatus }) {
      this.url = (url || '').replace(/\/$/, '');
      this.key = key || '';
      this.room = String(room || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 48);
      this.userId = userId;
      this.onEvent = onEvent || (() => {});
      this.onStatus = onStatus || (() => {});
      this.topic = `realtime:entry-live-${this.room}`;
      this.ref = 0;
      this.queue = [];
      this.joined = false;
      this.closed = false;
      this.reconnectCount = 0;
      this.heartbeatTimer = null;
      this.reconnectTimer = null;
      this.localChannel = null;
    }

    connect() {
      if (!this.url || !this.key) {
        this.connectLocal();
        return;
      }
      this.closed = false;
      const socketUrl = this.url
        .replace(/^http:/, 'ws:')
        .replace(/^https:/, 'wss:');
      const wsUrl = `${socketUrl}/realtime/v1/websocket?apikey=${encodeURIComponent(
        this.key
      )}&vsn=1.0.0`;
      try {
        this.socket = new WebSocket(wsUrl);
      } catch (error) {
        this.onStatus('error', error.message);
        this.scheduleReconnect();
        return;
      }
      this.onStatus('connecting');
      this.socket.addEventListener('open', () => this.join());
      this.socket.addEventListener('message', (event) => this.handleMessage(event.data));
      this.socket.addEventListener('error', () => this.onStatus('error', '실시간 서버 연결 실패'));
      this.socket.addEventListener('close', () => {
        this.joined = false;
        clearInterval(this.heartbeatTimer);
        this.onStatus('offline');
        this.scheduleReconnect();
      });
    }

    connectLocal() {
      this.localChannel = new BroadcastChannel(`entry-live-${this.room}`);
      this.localChannel.onmessage = ({ data }) => {
        if (data?.sender !== this.userId) this.onEvent(data.event, data.payload, data.sender);
      };
      this.joined = true;
      this.onStatus('online', '이 기기에서 시험 연결됨');
      queueMicrotask(() => this.flush());
    }

    join() {
      const ref = String(++this.ref);
      this.joinRef = ref;
      const joinPayload = {
        config: {
          broadcast: { ack: false, self: false },
          presence: { key: this.userId, enabled: false },
          postgres_changes: [],
          private: false,
        },
      };
      if (this.key.split('.').length === 3) joinPayload.access_token = this.key;
      this.socket.send(
        JSON.stringify({ topic: this.topic, event: 'phx_join', payload: joinPayload, ref })
      );
      this.heartbeatTimer = setInterval(() => {
        if (this.socket?.readyState === WebSocket.OPEN) {
          this.socket.send(
            JSON.stringify({
              topic: 'phoenix',
              event: 'heartbeat',
              payload: {},
              ref: String(++this.ref),
            })
          );
        }
      }, 25000);
    }

    handleMessage(raw) {
      let message;
      try {
        message = JSON.parse(raw);
      } catch (_) {
        return;
      }
      if (message.event === 'phx_reply' && message.ref === this.joinRef) {
        if (message.payload?.status === 'ok') {
          this.joined = true;
          this.reconnectCount = 0;
          this.onStatus('online');
          this.flush();
        } else {
          this.onStatus('error', '방에 연결할 수 없습니다.');
        }
        return;
      }
      if (message.event !== 'broadcast') return;
      const envelope = message.payload || {};
      const event = envelope.event || envelope.payload?.event;
      const payload = envelope.payload?.payload ?? envelope.payload;
      const sender = payload?.__sender;
      if (!event || sender === this.userId) return;
      if (payload && typeof payload === 'object') delete payload.__sender;
      this.onEvent(event, payload, sender);
    }

    send(event, payload = {}) {
      const cleanPayload = { ...payload, __sender: this.userId };
      if (this.localChannel) {
        this.localChannel.postMessage({ event, payload: cleanPayload, sender: this.userId });
        return true;
      }
      const message = {
        topic: this.topic,
        event: 'broadcast',
        payload: { type: 'broadcast', event, payload: cleanPayload },
        ref: null,
      };
      if (!this.joined || this.socket?.readyState !== WebSocket.OPEN) {
        this.queue.push(message);
        if (this.queue.length > 300) this.queue.shift();
        return false;
      }
      this.socket.send(JSON.stringify(message));
      return true;
    }

    flush() {
      while (this.joined && this.queue.length && this.socket?.readyState === WebSocket.OPEN) {
        this.socket.send(JSON.stringify(this.queue.shift()));
      }
    }

    scheduleReconnect() {
      if (this.closed || this.localChannel) return;
      clearTimeout(this.reconnectTimer);
      const delay = Math.min(12000, 800 * 2 ** this.reconnectCount++);
      this.reconnectTimer = setTimeout(() => this.connect(), delay);
    }

    close() {
      this.closed = true;
      this.joined = false;
      clearInterval(this.heartbeatTimer);
      clearTimeout(this.reconnectTimer);
      this.localChannel?.close();
      this.socket?.close();
    }
  }

  globalThis.EntryCollabRealtime = EntryCollabRealtime;
})();
