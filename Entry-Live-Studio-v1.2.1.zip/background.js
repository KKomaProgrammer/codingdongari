const uiPorts = new Set();
const sessionByTab = new Map();
const captureTabs = new Set();

async function ensureOffscreenDocument() {
  const url = chrome.runtime.getURL('offscreen/offscreen.html');
  if (chrome.runtime.getContexts) {
    const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'], documentUrls: [url] });
    if (contexts.length) return;
  }
  try {
    await chrome.offscreen.createDocument({
      url: 'offscreen/offscreen.html',
      reasons: ['USER_MEDIA'],
      justification: '대표의 엔트리 탭 화면을 관리자 페이지에서도 계속 송출합니다.',
    });
  } catch (error) {
    if (!String(error?.message || error).includes('single offscreen')) throw error;
  }
}

async function startTabCapture(tab, config) {
  try {
    await ensureOffscreenDocument();
    const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });
    const result = await chrome.runtime.sendMessage({
      type: 'ENTRY_LIVE_OFFSCREEN_START',
      tabId: tab.id,
      streamId,
      interval: Math.max(650, Number(config.captureInterval) || 1000),
      quality: Math.max(25, Math.min(90, Number(config.captureQuality) || 58)),
    });
    if (!result?.ok) throw new Error(result?.error || '탭 화면을 캡처할 수 없습니다.');
    captureTabs.add(tab.id);
    return true;
  } catch (_) {
    return false;
  }
}

function stopTabCapture(tabId) {
  captureTabs.delete(tabId);
  chrome.runtime.sendMessage({ type: 'ENTRY_LIVE_OFFSCREEN_STOP', tabId }).catch(() => {});
}

function broadcastToUi(message) {
  for (const port of [...uiPorts]) {
    try {
      port.postMessage(message);
    } catch (_) {
      uiPorts.delete(port);
    }
  }
}

async function rememberSession(tabId, state) {
  if (!tabId) return;
  if (state && state.active) {
    sessionByTab.set(tabId, state);
    await chrome.storage.session.set({ entryLiveLastTabId: tabId });
  } else {
    sessionByTab.delete(tabId);
    const { entryLiveLastTabId } = await chrome.storage.session.get('entryLiveLastTabId');
    if (entryLiveLastTabId === tabId) {
      await chrome.storage.session.remove('entryLiveLastTabId');
    }
  }
}

async function resolveSessionTab(preferredTabId) {
  if (preferredTabId) {
    try {
      const tab = await chrome.tabs.get(Number(preferredTabId));
      if (tab?.url?.startsWith('https://playentry.org/ws/')) return tab;
    } catch (_) {}
  }

  const active = await chrome.tabs.query({ active: true, currentWindow: true });
  if (active[0]?.url?.startsWith('https://playentry.org/ws/')) return active[0];

  const { entryLiveLastTabId } = await chrome.storage.session.get('entryLiveLastTabId');
  if (entryLiveLastTabId) {
    try {
      return await chrome.tabs.get(entryLiveLastTabId);
    } catch (_) {}
  }

  const entryTabs = await chrome.tabs.query({ url: 'https://playentry.org/ws/*' });
  return entryTabs[0] || null;
}

async function sendToSession(message, preferredTabId) {
  const tab = await resolveSessionTab(preferredTabId);
  if (!tab) throw new Error('엔트리 작품 만들기 탭을 먼저 열어 주세요.');
  const response = await chrome.tabs.sendMessage(tab.id, message);
  return { tabId: tab.id, response };
}

chrome.runtime.onConnect.addListener((port) => {
  if (!['entry-live-ui', 'entry-live-manager'].includes(port.name)) return;
  uiPorts.add(port);
  port.onDisconnect.addListener(() => uiPorts.delete(port));
  port.onMessage.addListener(async (message) => {
    try {
      if (message.type === 'UI_COMMAND') {
        const tab = await resolveSessionTab(message.tabId);
        if (!tab) throw new Error('엔트리 작품 만들기 탭을 먼저 열어 주세요.');
        const payload = { ...(message.payload || {}) };
        if (message.command === 'START' && payload.mode === 'mode1' && payload.role === 'leader') {
          payload.captureBackend = (await startTabCapture(tab, payload)) ? 'tab' : 'visible';
        }
        const response = await chrome.tabs.sendMessage(tab.id, {
          type: 'ENTRY_LIVE_COMMAND', command: message.command, payload,
        });
        if (message.command === 'STOP') stopTabCapture(tab.id);
        const result = { tabId: tab.id, response };
        port.postMessage({ type: 'UI_RESPONSE', requestId: message.requestId, ok: true, ...result });
      } else if (message.type === 'GET_SESSION') {
        const result = await sendToSession({ type: 'ENTRY_LIVE_GET_STATE' }, message.tabId);
        port.postMessage({
          type: 'UI_RESPONSE',
          requestId: message.requestId,
          ok: true,
          tabId: result.tabId,
          response: result.response,
        });
      }
    } catch (error) {
      port.postMessage({
        type: 'UI_RESPONSE',
        requestId: message.requestId,
        ok: false,
        error: error?.message || String(error),
      });
    }
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'ENTRY_LIVE_OFFSCREEN_FRAME') {
    chrome.tabs.sendMessage(message.tabId, {
      type: 'ENTRY_LIVE_CAPTURE_FRAME',
      dataUrl: message.dataUrl,
    }).catch(() => {});
    sendResponse({ ok: true });
    return;
  }

  if (message.type === 'ENTRY_LIVE_SESSION_STATE') {
    const tabId = sender.tab?.id;
    rememberSession(tabId, message.state);
    broadcastToUi({ type: 'SESSION_STATE', tabId, state: message.state });
    sendResponse({ ok: true });
    return;
  }

  if (message.type === 'ENTRY_LIVE_UI_EVENT') {
    broadcastToUi({ type: 'SESSION_EVENT', tabId: sender.tab?.id, event: message.event });
    sendResponse({ ok: true });
    return;
  }

  if (message.type === 'ENTRY_LIVE_CAPTURE') {
    (async () => {
      try {
        const tab = sender.tab;
        if (!tab?.id || !tab.active) {
          throw new Error('대표의 엔트리 탭이 화면에 표시되어 있을 때만 송출됩니다.');
        }
        const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
          format: 'jpeg',
          quality: Math.max(25, Math.min(90, Number(message.quality) || 58)),
        });
        sendResponse({ ok: true, dataUrl });
      } catch (error) {
        sendResponse({ ok: false, error: error?.message || String(error) });
      }
    })();
    return true;
  }

  if (message.type === 'ENTRY_LIVE_OPEN_PAGE') {
    (async () => {
      const tab = await resolveSessionTab(message.tabId || sender.tab?.id);
      const page = message.page === 'manager' ? 'ui/manager.html' : 'ui/panel.html';
      const url = chrome.runtime.getURL(page) + (tab?.id ? `?tabId=${tab.id}` : '');
      await chrome.tabs.create({ url });
      sendResponse({ ok: true });
    })();
    return true;
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  sessionByTab.delete(tabId);
  stopTabCapture(tabId);
});
