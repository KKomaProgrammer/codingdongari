import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
if (manifest.manifest_version !== 3) throw new Error('Manifest V3가 아닙니다.');

const required = [
  'background.js',
  'content/content.js',
  'content/features.js',
  'content/realtime.js',
  'content/rtc.js',
  'shared/invite-codec.js',
  'shared/settings-fetch.js',
  'page/page-bridge.js',
  'offscreen/offscreen.html',
  'offscreen/offscreen.js',
  'ui/popup.html',
  'ui/panel.html',
  'ui/manager.html',
  'ui/options.html',
  'assets/icon-16.png',
  'assets/icon-32.png',
  'assets/icon-48.png',
  'assets/icon-128.png',
];
for (const file of required) {
  if (!fs.existsSync(path.join(root, file))) throw new Error(`필수 파일 없음: ${file}`);
}

const jsFiles = [];
function walk(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const full = path.join(directory, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.name.endsWith('.js')) jsFiles.push(full);
  }
}
walk(root);
for (const file of jsFiles) execFileSync(process.execPath, ['--check', file], { stdio: 'pipe' });

const htmlFiles = required.filter((file) => file.endsWith('.html'));
for (const file of htmlFiles) {
  const html = fs.readFileSync(path.join(root, file), 'utf8');
  if (/<script(?![^>]*\bsrc=)/i.test(html)) throw new Error(`인라인 스크립트 발견: ${file}`);
}

const allText = required.filter((file) => !file.endsWith('.png')).concat(['manifest.json']).map((file) => fs.readFileSync(path.join(root, file), 'utf8')).join('\n');
if (/https?:\/\/[^\s"']+\.js\b/i.test(allText)) throw new Error('원격 실행 코드가 포함되어 있습니다.');

console.log(`검증 완료: ${jsFiles.length}개 JavaScript, ${htmlFiles.length}개 HTML`);
