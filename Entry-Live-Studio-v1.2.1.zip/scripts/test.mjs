import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
await import(pathToFileURL(path.join(root, 'content/realtime.js')));
await import(pathToFileURL(path.join(root, 'content/rtc.js')));
await import(pathToFileURL(path.join(root, 'shared/invite-codec.js')));
await import(pathToFileURL(path.join(root, 'shared/settings-fetch.js')));

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const room = `test-${Date.now()}`;
let received = null;
const first = new globalThis.EntryCollabRealtime({ url:'', key:'', room, userId:'a', onEvent:()=>{} });
const second = new globalThis.EntryCollabRealtime({
  url:'', key:'', room, userId:'b',
  onEvent: (event, payload, sender) => { received = { event, payload, sender }; },
});
first.connect(); second.connect();
first.send('hello', { value: 42 });
await new Promise((resolve) => setTimeout(resolve, 80));
assert(received?.event === 'hello', '로컬 Realtime 이벤트가 전달되지 않았습니다.');
assert(received?.payload?.value === 42, 'Realtime 페이로드가 달라졌습니다.');
assert(received?.sender === 'a', 'Realtime 발신자 정보가 잘못되었습니다.');
first.close(); second.close();

let rebuilt = null;
const fakeBus = { send() {} };
const hub = new globalThis.EntryCollabPeerHub({
  selfId:'a', mode:'mode1', leaderId:'a', bus:fakeBus,
  onData: (from, packet) => { rebuilt = { from, packet }; },
});
const packet = { type:'SCREEN_FRAME', text:'가나다'.repeat(6000) };
for (const part of hub.fragments(packet)) hub.receiveChunk('b', part);
assert(rebuilt?.from === 'b', '조각 데이터 발신자가 보존되지 않았습니다.');
assert(rebuilt?.packet?.text === packet.text, '조각 데이터가 원래대로 복원되지 않았습니다.');

assert(hub.shouldConnect('b') === true, '대표-참여자 연결이 차단되었습니다.');
const viewerHub = new globalThis.EntryCollabPeerHub({ selfId:'b', mode:'mode1', leaderId:'a', bus:fakeBus });
assert(viewerHub.shouldConnect('c') === false, '참여자끼리 연결되면 안 됩니다.');
assert(viewerHub.shouldConnect('a') === true, '참여자가 대표와 연결되지 않습니다.');
const unknownLeaderHub = new globalThis.EntryCollabPeerHub({ selfId:'c', mode:'mode1', leaderId:null, bus:fakeBus });
assert(unknownLeaderHub.shouldConnect('a') === false, '대표 탐색 전 임의 연결이 허용되었습니다.');
unknownLeaderHub.setTopology('mode1', 'a');
assert(unknownLeaderHub.shouldConnect('a') === true, '방 코드 입장 후 발견한 대표와 연결되지 않습니다.');
hub.close(); viewerHub.close();
unknownLeaderHub.close();

const invitePayload = {
  v: 1,
  room: 'ROOM123',
  mode: 'mode1',
  leaderId: '대표-사용자',
};
const encodedInvite = EntryInviteCodec.encode(invitePayload);
assert(!encodedInvite.includes('='), '초대 코드의 패딩이 제거되지 않았습니다.');
const decodedInvite = EntryInviteCodec.decode(` \n${encodedInvite}\u200b `, {
  serverUrl: 'https://example.supabase.co',
  anonKey: 'fetched-key',
});
assert(decodedInvite.room === invitePayload.room, '초대 코드의 방 정보가 복원되지 않았습니다.');
assert(decodedInvite.leaderId === invitePayload.leaderId, 'UTF-8 초대 코드가 복원되지 않았습니다.');
assert(decodedInvite.serverUrl === 'https://example.supabase.co' && decodedInvite.anonKey === 'fetched-key', '설정 서버에서 받은 연결 정보가 초대 코드에 적용되지 않았습니다.');

const decodedRoom = EntryInviteCodec.decode('AB12CD3', {
  mode: 'mode2',
  serverUrl: 'https://example.supabase.co',
  anonKey: 'local-key',
});
assert(decodedRoom.plainRoom === true, '짧은 방 코드가 인식되지 않았습니다.');
assert(decodedRoom.mode === 'mode2', '방 코드 입장 모드가 보존되지 않았습니다.');
assert(decodedRoom.serverUrl === 'https://example.supabase.co', '방 코드에 연결 설정이 적용되지 않았습니다.');

let invalidMessage = '';
try { EntryInviteCodec.decode('잘못된 코드'); } catch (error) { invalidMessage = error.message; }
assert(invalidMessage === '초대 코드 또는 방 코드가 올바르지 않습니다. 다시 복사해 주세요.', '잘못된 코드 안내가 명확하지 않습니다.');

assert(EntrySettingsFetch.API_URL === 'https://supabase-settings-fetch.pages.dev/api/settings', '설정 API 주소가 올바르지 않습니다.');
const originalFetch = globalThis.fetch;
let fetchedPassword = '';
globalThis.fetch = async (_url, options) => {
  fetchedPassword = JSON.parse(options.body).password;
  return new Response(JSON.stringify({ ok:true, serverUrl:'https://example.supabase.co', anonKey:'sb_publishable_test' }), { status:200, headers:{'Content-Type':'application/json'} });
};
const fetchedSettings = await EntrySettingsFetch.fetchSettings('비밀번호-123');
assert(fetchedPassword === '비밀번호-123', '입력한 비밀번호가 설정 API 요청에 전달되지 않았습니다.');
assert(fetchedSettings.serverUrl === 'https://example.supabase.co' && fetchedSettings.anonKey === 'sb_publishable_test', '설정 API 응답이 연결 설정으로 변환되지 않았습니다.');
globalThis.fetch = originalFetch;

const contentSource = fs.readFileSync(path.join(root, 'content/content.js'), 'utf8');
const controlSource = fs.readFileSync(path.join(root, 'ui/control.js'), 'utf8');
const managerSource = fs.readFileSync(path.join(root, 'ui/manager.js'), 'utf8');
const featuresSource = fs.readFileSync(path.join(root, 'content/features.js'), 'utf8');
const bridgeSource = fs.readFileSync(path.join(root, 'page/page-bridge.js'), 'utf8');
const optionsSource = fs.readFileSync(path.join(root, 'ui/options.html'), 'utf8');
const settingsFetchSource = fs.readFileSync(path.join(root, 'shared/settings-fetch.js'), 'utf8');
assert(controlSource.includes('connectionPassword') && controlSource.includes('EntrySettingsFetch.fetchSettings'), '비밀번호 기반 Supabase 자동 설정 가져오기가 없습니다.');
assert(!optionsSource.includes('id="serverUrl"') && !optionsSource.includes('id="anonKey"'), '설정 화면에 Supabase URL/키 직접 입력란이 남아 있습니다.');
assert(settingsFetchSource.includes('supabase-settings-fetch.pages.dev/api/settings'), 'Cloudflare Pages 설정 API 연결 코드가 없습니다.');
assert(!contentSource.slice(contentSource.indexOf('inviteCode()'), contentSource.indexOf('publicState()')).includes('anonKey'), '새 초대 코드에 Supabase 키가 포함되고 있습니다.');
assert(contentSource.includes("delete nextStoredSettings.serverUrl") && contentSource.includes("delete nextStoredSettings.anonKey"), 'Supabase 설정값 로컬 저장 제거가 적용되지 않았습니다.');
assert(contentSource.includes("event === 'session-end'"), '대표 종료 이벤트 처리가 없습니다.');
assert(contentSource.includes("this.stop('대표 연결이 끊겨 세션을 종료했습니다.')"), '대표 연결 타임아웃 종료 처리가 없습니다.');
assert(contentSource.includes("case 'SET_UI_EDITING'"), '그리기 중 UI 갱신 잠금이 없습니다.');
assert(contentSource.includes('bindFloatingDrag()'), '떠있는 박스 드래그 처리가 없습니다.');
assert(controlSource.includes('deferredState'), '기존 제어창의 그리기 중 상태 갱신 보류가 없습니다.');
assert(featuresSource.includes("'.rcs-inner-container'") && featuresSource.includes('관리자에게 코드 전송'), '참가자 블록 컨텍스트 메뉴 코드 전송 기능이 없습니다.');
assert(featuresSource.includes("case 'CHAT_MESSAGE'") && featuresSource.includes("case 'SEND_CHAT'"), '채팅 송수신 기능이 없습니다.');
assert(featuresSource.includes('peerChatAllowed') && featuresSource.includes('chatCooldownMs'), '참가자 간 채팅 정책 또는 쿨타임 기능이 없습니다.');
assert(featuresSource.includes("case 'SEND_ANNOUNCEMENT'") && featuresSource.includes("case 'SEND_MEDIA'"), '공지 또는 이미지 전송 기능이 없습니다.');
assert(featuresSource.includes('PROJECT_EXPORT_REQUEST') && managerSource.includes('buildEnt'), '참가자 작품 ENT 가져오기 기능이 없습니다.');
assert(featuresSource.includes('data-resize') && featuresSource.includes('viewerFrameAspect'), '대표 화면 비율 유지 리사이즈 기능이 없습니다.');
assert(bridgeSource.includes('dependencyBundle') && bridgeSource.includes('applyDependencies'), '코드 의존성 자동 추가 기능이 없습니다.');
assert(!contentSource.includes("this.sendAll({ type: 'LEADER_CODE', codeView });"), '참가자에게 대표 코드를 자동 송출하고 있습니다.');
assert(contentSource.includes("message.type === 'ENTRY_LIVE_CAPTURE_FRAME'") && !contentSource.includes("this.screenEnabled && this.config.displayMode !== 'floating'"), '플로팅 모드 tabCapture 프레임 수신이 차단되어 있습니다.');

assert(featuresSource.includes("style.overflowY === 'visible'") && featuresSource.includes('targetList.appendChild(item)'), '컨텍스트 메뉴 항목이 실제 내부 목록 div에 삽입되지 않습니다.');
assert(featuresSource.includes('참가자에게 코드 보내기'), '대표의 컨텍스트 메뉴 코드 보내기 기능이 없습니다.');
assert(featuresSource.includes('toggleChat(!studio.chatOpen)'), '채팅 아이콘 재클릭 닫기 동작이 없습니다.');
assert(featuresSource.includes('대표 화면') && !featuresSource.includes('<strong>관리자 화면</strong>'), '참가자 대표 화면 표기가 적용되지 않았습니다.');
assert(featuresSource.includes('elsErase') && featuresSource.includes('elsClearDraw') && contentSource.includes("leaderDrawTool === 'erase'"), '대표 떠있는 박스의 지우개/전체 지우기 기능이 없습니다.');
assert(featuresSource.includes('screenShareStartedAt') && featuresSource.includes('formatDuration'), '화면 공유 시간 표시 기능이 없습니다.');
assert(featuresSource.includes('viewerUserSized') && featuresSource.includes('viewerFrameAspect'), '대표 화면 실제 비율에 맞춘 박스 크기 조절이 없습니다.');
assert(managerSource.includes('chat-app-shell') && managerSource.includes('managerChatRooms'), '관리자 채팅방 분리 UI가 없습니다.');
assert(managerSource.includes('chatDrafts') && managerSource.includes("input.addEventListener('input'"), '관리자 채팅 작성 내용 보존 처리가 없습니다.');
assert(managerSource.includes('GET_CURRENT_CODE_IMAGE') && !managerSource.includes('const dataUrl = viewer?.toDataUrl();'), '현재 표시 이미지 전송이 선택 코드 이미지 기반이 아닙니다.');
assert(managerSource.includes('managerLightbox') && featuresSource.includes('elsLightbox'), '채팅 이미지 크게 보기 기능이 없습니다.');
assert(managerSource.includes('clearAnnotations') && managerSource.includes('전체 지우기'), '관리자 페이지 전체 지우기 기능이 없습니다.');
assert(bridgeSource.includes('const padding = 8') && featuresSource.includes('.els-code-delivery{position:absolute;inset:4%'), '전송 코드 이미지 여백 또는 거의 전체 오버레이 처리가 없습니다.');

console.log('테스트 완료: 비밀번호 설정 가져오기, 대표 중심 연결, 방별 채팅, 컨텍스트 메뉴, 공유 시간, 코드 이미지/ENT, 안정 화면 갱신');
