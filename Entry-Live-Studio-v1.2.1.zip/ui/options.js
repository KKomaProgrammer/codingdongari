(async function () {
  const data = await chrome.storage.local.get('entryLiveSettings');
  const settings = data.entryLiveSettings || {};
  const ids = ['captureInterval','captureQuality','displayMode','turnUrl','turnUsername','turnCredential'];
  for (const id of ids) {
    const input = document.getElementById(id);
    if (settings[id] !== undefined) input.value = settings[id];
  }
  document.getElementById('captureInterval').value ||= '1000';
  document.getElementById('captureQuality').value ||= '58';
  document.getElementById('displayMode').value ||= 'floating';
  document.getElementById('shareControls').checked = Boolean(settings.shareControls);

  document.getElementById('testConnection').addEventListener('click', async () => {
    const button = document.getElementById('testConnection');
    const status = document.getElementById('connectionStatus');
    const password = document.getElementById('connectionPassword').value;
    button.disabled = true;
    status.textContent = '확인 중…';
    try {
      await EntrySettingsFetch.fetchSettings(password);
      status.textContent = '연결 설정을 확인했습니다.';
    } catch (error) {
      status.textContent = error.message;
    } finally {
      button.disabled = false;
    }
  });

  document.getElementById('save').addEventListener('click', async () => {
    const next = { ...settings };
    delete next.serverUrl;
    delete next.anonKey;
    for (const id of ids) next[id] = document.getElementById(id).value.trim();
    next.captureInterval = Number(next.captureInterval) || 1000;
    next.captureQuality = Number(next.captureQuality) || 58;
    next.shareControls = document.getElementById('shareControls').checked;
    await chrome.storage.local.set({ entryLiveSettings: next });
    const saved = document.getElementById('saved');
    saved.textContent = '저장했습니다.';
    setTimeout(() => { saved.textContent = ''; }, 2500);
  });
})();
