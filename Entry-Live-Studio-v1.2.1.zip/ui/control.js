(function () {
  const app = document.getElementById('app');
  const surface = document.documentElement.dataset.surface;
  const tabId = Number(new URLSearchParams(location.search).get('tabId')) || null;
  const port = chrome.runtime.connect({ name: 'entry-live-ui' });
  const pending = new Map();
  let requestSeq = 0;
  let state = { active: false };
  let setupMode = 'create';
  let selectedMode = 'mode1';
  let settings = {};
  let errorText = '';
  let noticeText = '';
  let viewer = null;
  let editing = false;
  let deferredState = null;
  const deferredEvents = new Map();
  let renderedSignature = '';
  let selectedFrameKind = 'screen';
  const editToken = `control-${Date.now()}-${Math.random().toString(36).slice(2)}`;

  const escapeHtml = (value) => String(value ?? '').replace(/[&<>'"]/g, (c) => ({ '&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;' })[c]);
  const randomRoom = () => Math.random().toString(36).slice(2, 9).toUpperCase();

  function request(command, payload = {}) {
    const requestId = `ui-${Date.now()}-${++requestSeq}`;
    return new Promise((resolve, reject) => {
      pending.set(requestId, { resolve, reject });
      port.postMessage({ type: 'UI_COMMAND', requestId, tabId, command, payload });
      setTimeout(() => {
        if (!pending.has(requestId)) return;
        pending.delete(requestId);
        reject(new Error('응답 시간이 초과되었습니다.'));
      }, 30000);
    });
  }

  function getSession() {
    const requestId = `get-${Date.now()}-${++requestSeq}`;
    return new Promise((resolve) => {
      pending.set(requestId, { resolve, reject: resolve });
      port.postMessage({ type: 'GET_SESSION', requestId, tabId });
      setTimeout(() => resolve(null), 5000);
    });
  }

  port.onMessage.addListener((message) => {
    if (message.type === 'UI_RESPONSE') {
      const item = pending.get(message.requestId);
      if (!item) return;
      pending.delete(message.requestId);
      if (message.ok) item.resolve(message);
      else item.reject(new Error(message.error || '동작을 완료하지 못했습니다.'));
      return;
    }
    if (message.type === 'SESSION_STATE' && (!tabId || message.tabId === tabId)) {
      const nextState = message.state || { active: false };
      if (editing) deferredState = nextState;
      else acceptState(nextState);
      return;
    }
    if (message.type === 'SESSION_EVENT' && (!tabId || message.tabId === tabId)) {
      if (editing) deferEvent(message.event);
      else handleSessionEvent(message.event);
    }
  });

  function stateSignature(value) {
    return JSON.stringify({
      active: value.active,
      endReason: value.endReason,
      mode: value.mode,
      role: value.role,
      room: value.room,
      connectionStatus: value.connectionStatus,
      screenEnabled: value.screenEnabled,
      shareControls: value.shareControls,
      displayMode: value.displayMode,
      fullStateReceived: value.fullStateReceived,
      people: (value.participants || []).map((person) => ({
        id: person.id,
        name: person.name,
        role: person.role,
        peerState: person.peerState,
        selectedObjectId: person.summary?.selectedObjectId,
        objects: (person.summary?.objects || []).map((object) => [object.id, object.name, object.blockCount]),
      })),
      objects: (value.ownSummary?.objects || []).map((object) => [object.id, object.name, object.blockCount, object.selected]),
    });
  }

  function acceptState(nextState) {
    const signature = stateSignature(nextState);
    state = nextState;
    if (signature !== renderedSignature) render();
  }

  function deferEvent(event) {
    if (!event) return;
    const key = event.type === 'frame' ? `frame:${event.kind}` : event.type;
    deferredEvents.set(key, event);
  }

  function beginEditing() {
    if (editing) return;
    editing = true;
    request('SET_UI_EDITING', { token: editToken, locked: true }).catch(() => {});
  }

  async function finishEditing(clear = false) {
    if (clear) viewer?.clearAnnotations();
    if (editing) {
      try { await request('SET_UI_EDITING', { token: editToken, locked: false }); } catch (_) {}
    }
    editing = false;
    if (deferredState) {
      const next = deferredState;
      deferredState = null;
      acceptState(next);
    }
    const events = [...deferredEvents.values()];
    deferredEvents.clear();
    for (const event of events) handleSessionEvent(event);
  }

  function handleSessionEvent(event) {
    if (!event) return;
    if (event.type === 'frame' && event.dataUrl) {
      if (viewer && viewer.kind === event.kind) viewer.load(event.dataUrl, event.kind === 'screen');
      state.latestFrames = { ...(state.latestFrames || {}), [event.kind]: event.dataUrl };
    } else if (event.type === 'notice') {
      noticeText = event.notice?.text || '';
      updateNotice();
    }
  }

  function updateNotice() {
    const element = document.getElementById('controlNotice');
    if (!element) return;
    element.hidden = !noticeText;
    element.textContent = noticeText;
  }

  function showControlNotice(text) {
    noticeText = text;
    updateNotice();
    setTimeout(() => {
      if (noticeText !== text) return;
      noticeText = '';
      updateNotice();
    }, 3200);
  }

  function setupView() {
    return `
      <div class="shell">
        ${topbar('새 세션')}
        ${errorText ? `<div class="errorbox">${escapeHtml(errorText)}</div>` : ''}
        ${state.endReason ? `<div class="notice">${escapeHtml(state.endReason)}</div>` : ''}
        <section class="card setup-grid">
          <div class="segment"><button id="createTab" class="${setupMode === 'create' ? 'active' : ''}">방 만들기</button><button id="joinTab" class="${setupMode === 'join' ? 'active' : ''}">코드로 입장</button></div>
          <div class="field"><label>표시 이름</label><input id="name" maxlength="20" value="${escapeHtml(settings.lastName || '')}" placeholder="예: 준우"></div>
          ${setupMode === 'create' ? `
            <div class="field"><label>모드</label><select id="mode"><option value="mode1" ${selectedMode === 'mode1' ? 'selected' : ''}>대표 송출 · 코드 관리</option><option value="mode2" ${selectedMode === 'mode2' ? 'selected' : ''}>실시간 공동 편집</option></select></div>
            <button id="create" class="btn primary block">방 만들기</button>
          ` : `
            <div class="field"><label>초대 코드 또는 방 코드</label><textarea id="inviteInput" rows="4" placeholder="대표가 보낸 코드를 붙여넣으세요"></textarea></div>
            <div class="field"><label>방 코드로 입장할 모드</label><select id="joinMode"><option value="mode1" ${selectedMode === 'mode1' ? 'selected' : ''}>대표 송출 · 코드 관리</option><option value="mode2" ${selectedMode === 'mode2' ? 'selected' : ''}>실시간 공동 편집</option></select></div>
            <button id="join" class="btn primary block">입장하기</button>
          `}
          <div class="field"><label>연결 비밀번호</label><input id="connectionPassword" type="password" autocomplete="current-password" placeholder="Cloudflare 설정 비밀번호"><span class="hint">Supabase URL과 키는 비밀번호 확인 후 설정 서버에서 자동으로 가져옵니다. 비밀번호는 저장하지 않습니다.</span></div>
        </section>
      </div>`;
  }

  function topbar(subtitle) {
    return `<header class="topbar"><div class="brand"><div class="logo">E</div><div><h1>Entry Live Studio</h1><p>${escapeHtml(subtitle)}</p></div></div><button id="options" class="btn icon" title="설정">⚙</button></header>`;
  }

  function activeView() {
    const isMode1 = state.mode === 'mode1';
    const isLeader = state.role === 'leader';
    const people = state.participants || [];
    const viewerHtml = isMode1 && !isLeader ? `
      <section class="card viewer-card">
        <div class="viewer-head"><div class="tabs"><button data-kind="screen" class="${selectedFrameKind === 'screen' ? 'active' : ''}">대표 화면</button><button data-kind="code" class="${selectedFrameKind === 'code' ? 'active' : ''}">대표 코드</button></div><span id="zoomLabel" class="badge">100%</span></div>
        <div id="viewport" class="viewport"><canvas id="baseCanvas"></canvas><canvas id="annotCanvas"></canvas><div class="empty">화면을 기다리는 중</div></div>
        <div class="viewer-tools"><div class="toolgroup"><button class="btn active" data-tool="pan">이동</button><button class="btn" data-tool="draw">그리기</button><button class="btn" data-tool="erase">지우개</button></div><div class="toolgroup"><button class="btn icon" id="zoomOut">−</button><button class="btn" id="zoomReset">초기화</button><button class="btn icon" id="zoomIn">＋</button></div></div>
      </section>` : `
      <section class="card viewer-card"><div class="viewer-head"><strong>${isMode1 ? '접속 사용자' : '공동 편집 상태'}</strong><span class="badge">${people.length + 1}명</span></div><div class="empty-session">${isMode1 ? '상세 사용자 관리는 관리자 화면에서 할 수 있습니다.' : (state.fullStateReceived === false ? '공동 작품을 불러오고 있습니다.' : '엔트리에서 편집하면 모두에게 바로 반영됩니다.')}</div><div class="viewer-tools"><span class="hint">${escapeHtml(state.notice?.text || noticeText || '')}</span></div></section>`;
    return `
      <div class="shell">
        ${topbar(isMode1 ? (isLeader ? '대표 송출 · 코드 관리' : '대표 화면 참여') : '실시간 공동 편집')}
        ${errorText ? `<div class="errorbox">${escapeHtml(errorText)}</div>` : ''}
        <div id="controlNotice" class="notice" ${noticeText ? '' : 'hidden'}>${escapeHtml(noticeText)}</div>
        <div class="session-grid">
          <div class="controls">
            <section class="card">
              <div class="statusbar"><div class="status-main"><i class="dot ${state.connectionStatus === 'online' ? 'online' : ''}"></i><div><strong>${state.connectionStatus === 'online' ? '연결됨' : '연결 중'}</strong><span>방 ${escapeHtml(state.room)}</span></div></div><span class="badge">${isMode1 ? (isLeader ? '대표' : '참여자') : '공동 편집'}</span></div>
              <div class="invite"><input readonly value="${escapeHtml(state.inviteCode || '')}"><button id="copyInvite" class="btn">복사</button></div>
            </section>
            <section class="card section">
              <h2>화면 위치</h2>
              <select id="display"><option value="floating" ${state.displayMode === 'floating' ? 'selected' : ''}>엔트리 위 떠있는 창</option><option value="newpage" ${state.displayMode === 'newpage' ? 'selected' : ''}>새 페이지</option><option value="popup" ${state.displayMode === 'popup' ? 'selected' : ''}>확장 프로그램 팝업</option></select>
            </section>
            ${isMode1 && isLeader ? leaderControls(people) : ''}
            ${isMode1 && !isLeader ? `<section class="card section"><div class="row"><button id="sendFeedback" class="btn primary grow">전송</button><button id="cancelFeedback" class="btn grow">취소</button></div></section>` : ''}
            ${!isMode1 ? `<section class="card section"><button id="forceSync" class="btn block">현재 작품 전체 보내기</button></section>` : ''}
            <div class="row"><button id="stop" class="btn danger grow">나가기</button>${isLeader && isMode1 ? '<button id="manager" class="btn grow">사용자 관리</button>' : ''}</div>
          </div>
          ${viewerHtml}
        </div>
      </div>`;
  }

  function leaderControls(people) {
    const objects = state.ownSummary?.objects || [];
    return `<section class="card section"><h2>송출</h2><div class="row"><label class="toggle grow"><input id="screenEnabled" type="checkbox" ${state.screenEnabled ? 'checked' : ''}>화면 송출</label><label class="toggle grow"><input id="shareControls" type="checkbox" ${state.shareControls ? 'checked' : ''}>작업 박스 표시</label></div><div class="divider"></div><h2>코드 보내기</h2><select id="sourceObject">${objects.map((object) => `<option value="${escapeHtml(object.id)}" ${object.selected ? 'selected' : ''}>${escapeHtml(object.name)}</option>`).join('')}</select><select id="scope" style="margin-top:7px"><option value="object">오브젝트 전체</option><option value="thread">선택 코드 묶음</option><option value="below">선택 블록 아래</option></select><div class="people">${people.map((person) => `<label class="person"><input type="checkbox" data-user="${escapeHtml(person.id)}">${escapeHtml(person.name)}</label>`).join('') || '<span class="hint">참여자를 기다리는 중</span>'}</div><div class="row"><select id="targetMode" class="grow"><option value="current">각자 작업 오브젝트</option><option value="new">새 오브젝트 추가</option></select><button id="sendCode" class="btn primary grow">코드 보내기</button></div></section>`;
  }

  function render() {
    viewer?.destroy?.();
    viewer = null;
    app.innerHTML = state.active ? activeView() : setupView();
    renderedSignature = stateSignature(state);
    bindCommon();
    if (state.active) bindActive(); else bindSetup();
  }

  function bindCommon() {
    document.getElementById('options')?.addEventListener('click', () => chrome.runtime.openOptionsPage());
  }

  async function collectServer() {
    const password = document.getElementById('connectionPassword')?.value || '';
    return EntrySettingsFetch.fetchSettings(password);
  }

  function bindSetup() {
    document.getElementById('createTab')?.addEventListener('click', () => { setupMode = 'create'; errorText = ''; render(); });
    document.getElementById('joinTab')?.addEventListener('click', () => { setupMode = 'join'; errorText = ''; render(); });
    document.getElementById('mode')?.addEventListener('change', (event) => { selectedMode = event.target.value; });
    document.getElementById('joinMode')?.addEventListener('change', (event) => { selectedMode = event.target.value; });
    document.getElementById('create')?.addEventListener('click', async () => {
      try {
        errorText = '';
        const name = document.getElementById('name').value.trim() || '대표';
        const mode = document.getElementById('mode').value;
        const server = await collectServer();
        const result = await request('START', {
          ...server, name, mode, room: randomRoom(), role: mode === 'mode1' ? 'leader' : 'member', creator: true,
          displayMode: surface === 'panel' ? 'newpage' : (settings.displayMode || 'floating'),
        });
        state = result.response?.result || result.response || state;
        render();
      } catch (error) { errorText = error.message; render(); }
    });
    document.getElementById('join')?.addEventListener('click', async () => {
      try {
        errorText = '';
        const server = await collectServer();
        const invite = EntryInviteCodec.decode(document.getElementById('inviteInput').value, {
          mode: document.getElementById('joinMode')?.value || selectedMode,
          ...server,
        });
        const name = document.getElementById('name').value.trim() || '참여자';
        const result = await request('START', {
          ...invite, name, role: invite.mode === 'mode1' ? 'participant' : 'member', creator: false,
          displayMode: surface === 'panel' ? 'newpage' : (settings.displayMode || 'floating'),
        });
        state = result.response?.result || result.response || state;
        render();
      } catch (error) { errorText = error.message; render(); }
    });
  }

  function bindActive() {
    document.getElementById('copyInvite')?.addEventListener('click', async () => {
      await navigator.clipboard.writeText(state.inviteCode || '');
      showControlNotice('초대 코드를 복사했습니다.');
    });
    document.getElementById('display')?.addEventListener('change', async (event) => {
      const displayMode = event.target.value;
      await request('SET_DISPLAY', { displayMode });
      if (displayMode === 'newpage' && surface !== 'panel') await request('OPEN_PANEL');
    });
    document.getElementById('stop')?.addEventListener('click', async () => {
      await request('STOP'); state = { active: false }; render();
    });
    document.getElementById('manager')?.addEventListener('click', () => request('OPEN_MANAGER'));
    document.getElementById('screenEnabled')?.addEventListener('change', (event) => request('SET_SCREEN', { enabled: event.target.checked }));
    document.getElementById('shareControls')?.addEventListener('change', (event) => request('SET_SHARE_CONTROLS', { enabled: event.target.checked }));
    document.getElementById('sendCode')?.addEventListener('click', async () => {
      try {
        const targetMode = document.getElementById('targetMode').value;
        const targets = [...document.querySelectorAll('[data-user]:checked')].map((input) => ({ userId: input.dataset.user, targetMode }));
        await request('SEND_CODE', { objectId: document.getElementById('sourceObject').value, scope: document.getElementById('scope').value, targets });
        showControlNotice(`${targets.length}명에게 코드를 보냈습니다.`);
      } catch (error) { errorText = error.message; render(); }
    });
    document.getElementById('forceSync')?.addEventListener('click', () => request('FORCE_FULL_SYNC').catch((error) => { errorText = error.message; render(); }));
    if (document.getElementById('viewport')) {
      viewer = new CanvasViewer(document.getElementById('viewport'), beginEditing);
      viewer.kind = selectedFrameKind;
      const frames = state.latestFrames || {};
      if (frames[selectedFrameKind]) viewer.load(frames[selectedFrameKind]);
      document.querySelectorAll('[data-kind]').forEach((button) => button.addEventListener('click', () => {
        document.querySelectorAll('[data-kind]').forEach((item) => item.classList.toggle('active', item === button));
        selectedFrameKind = button.dataset.kind;
        viewer.kind = selectedFrameKind;
        const frame = state.latestFrames?.[viewer.kind];
        if (frame) viewer.load(frame);
      }));
      document.querySelectorAll('[data-tool]').forEach((button) => button.addEventListener('click', () => {
        document.querySelectorAll('[data-tool]').forEach((item) => item.classList.toggle('active', item === button));
        viewer.tool = button.dataset.tool;
      }));
      document.getElementById('zoomIn').onclick = () => viewer.setZoom(viewer.zoom * 1.2);
      document.getElementById('zoomOut').onclick = () => viewer.setZoom(viewer.zoom / 1.2);
      document.getElementById('zoomReset').onclick = () => viewer.fit();
      document.getElementById('sendFeedback').onclick = async () => {
        try {
          await request('SEND_FEEDBACK', { dataUrl: viewer.toDataUrl() });
          await finishEditing(true);
          showControlNotice('대표에게 보냈습니다.');
        } catch (error) { errorText = error.message; await finishEditing(false); render(); }
      };
      document.getElementById('cancelFeedback').onclick = () => finishEditing(true);
    }
  }

  class CanvasViewer {
    constructor(viewport, onEditStart) {
      this.viewport = viewport;
      this.base = viewport.querySelector('#baseCanvas');
      this.canvas = viewport.querySelector('#annotCanvas');
      this.ctx = this.canvas.getContext('2d');
      this.kind = 'screen'; this.tool = 'pan'; this.zoom = 1; this.x = 0; this.y = 0;
      this.onEditStart = onEditStart;
      this.loadSequence = 0;
      this.bind();
    }
    load(url, preserve = false) {
      const sequence = ++this.loadSequence;
      const image = new Image();
      image.onload = () => {
        if (sequence !== this.loadSequence) return;
        const hadFrame = Boolean(this.base.width);
        const sizeChanged = this.canvas.width !== image.naturalWidth || this.canvas.height !== image.naturalHeight;
        this.base.width = image.naturalWidth; this.base.height = image.naturalHeight;
        this.base.getContext('2d').drawImage(image, 0, 0);
        if (sizeChanged || !preserve) { this.canvas.width = image.naturalWidth; this.canvas.height = image.naturalHeight; }
        this.ctx = this.canvas.getContext('2d');
        this.viewport.classList.add('has-frame');
        if (!hadFrame || sizeChanged || !preserve) this.fit();
      };
      image.src = url;
    }
    bind() {
      let down = false, previous = null;
      const local = (e) => ({ x:(e.clientX-this.canvas.getBoundingClientRect().left)/this.zoom, y:(e.clientY-this.canvas.getBoundingClientRect().top)/this.zoom });
      this.canvas.onpointerdown = (e) => { down = true; if(this.tool!=='pan')this.onEditStart?.(); previous = this.tool === 'pan' ? {x:e.clientX,y:e.clientY} : local(e); this.canvas.setPointerCapture(e.pointerId); };
      this.canvas.onpointermove = (e) => {
        if (!down) return;
        if (this.tool === 'pan') { this.x += e.clientX-previous.x; this.y += e.clientY-previous.y; previous={x:e.clientX,y:e.clientY}; this.apply(); return; }
        const now=local(e); this.ctx.save(); this.ctx.lineCap='round'; this.ctx.lineJoin='round'; this.ctx.lineWidth=this.tool==='erase'?22:5; this.ctx.globalCompositeOperation=this.tool==='erase'?'destination-out':'source-over'; this.ctx.strokeStyle='#ff365b'; this.ctx.beginPath(); this.ctx.moveTo(previous.x,previous.y); this.ctx.lineTo(now.x,now.y); this.ctx.stroke(); this.ctx.restore(); previous=now;
      };
      this.canvas.onpointerup = this.canvas.onpointercancel = this.canvas.onlostpointercapture = () => { down=false; previous=null; };
      this.viewport.onwheel = (e) => { e.preventDefault(); this.setZoom(this.zoom*(e.deltaY<0?1.1:.9)); };
    }
    fit() { if(!this.base.width)return; this.zoom=Math.min(this.viewport.clientWidth/this.base.width,this.viewport.clientHeight/this.base.height); this.x=(this.viewport.clientWidth-this.base.width*this.zoom)/2; this.y=(this.viewport.clientHeight-this.base.height*this.zoom)/2; this.apply(); }
    setZoom(value){this.zoom=Math.max(.12,Math.min(5,value));this.apply();}
    apply(){const transform=`translate(${this.x}px,${this.y}px) scale(${this.zoom})`;this.base.style.transform=transform;this.canvas.style.transform=transform;const label=document.getElementById('zoomLabel');if(label)label.textContent=`${Math.round(this.zoom*100)}%`;}
    clearAnnotations(){if(this.canvas.width)this.ctx.clearRect(0,0,this.canvas.width,this.canvas.height);}
    toDataUrl(){if(!this.base.width)throw new Error('표시할 화면이 아직 없습니다.');const output=document.createElement('canvas');output.width=this.base.width;output.height=this.base.height;const ctx=output.getContext('2d');ctx.drawImage(this.base,0,0);ctx.drawImage(this.canvas,0,0);return output.toDataURL('image/jpeg',.78);}
    destroy(){this.loadSequence++;this.viewport.onwheel=null;this.canvas.onpointerdown=null;this.canvas.onpointermove=null;this.canvas.onpointerup=null;this.canvas.onpointercancel=null;this.canvas.onlostpointercapture=null;}
  }

  addEventListener('pagehide', () => {
    if (!editing) return;
    port.postMessage({ type: 'UI_COMMAND', requestId: `unlock-${Date.now()}`, tabId, command: 'SET_UI_EDITING', payload: { token: editToken, locked: false } });
  });

  (async () => {
    settings = (await chrome.storage.local.get('entryLiveSettings')).entryLiveSettings || {};
    try {
      const result = await getSession();
      const response = result?.response;
      state = response?.active !== undefined ? response : response?.result || { active: false };
    } catch (_) { state = { active: false }; }
    render();
  })();
})();
