(function () {
  const app = document.getElementById('app');
  const tabId = Number(new URLSearchParams(location.search).get('tabId')) || null;
  const port = chrome.runtime.connect({ name: 'entry-live-manager' });
  const pending = new Map();
  let seq = 0;
  let state = { active: false, participants: [] };
  let selectedUserId = null;
  let activeView = 'leader';
  let selectedShareId = null;
  let activeSide = 'chat';
  let viewer = null;
  let shellReady = false;
  let noticeTimer = null;
  let managerTimer = null;
  let activeChatRoom = 'all';
  let renderedChatRoom = null;
  const chatDrafts = new Map();
  const exportRequests = new Map();

  const esc = (value) => String(value ?? '').replace(/[&<>'"]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'})[c]);

  const leaderRoomKey = (userId) => `leader:${userId}`;
  function formatDuration(ms) {
    const total = Math.max(0, Math.floor(Number(ms || 0) / 1000));
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const sec = total % 60;
    return h ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}` : `${m}:${String(sec).padStart(2, '0')}`;
  }

  function call(command, payload = {}, timeout = 30000) {
    const requestId = `m-${Date.now()}-${++seq}`;
    return new Promise((resolve, reject) => {
      pending.set(requestId, { resolve, reject });
      port.postMessage({ type: 'UI_COMMAND', requestId, tabId, command, payload });
      setTimeout(() => { if (pending.delete(requestId)) reject(new Error('응답 시간이 초과되었습니다.')); }, timeout);
    });
  }

  function getState() {
    const requestId = `g-${Date.now()}-${++seq}`;
    return new Promise((resolve, reject) => {
      pending.set(requestId, { resolve, reject });
      port.postMessage({ type: 'GET_SESSION', requestId, tabId });
      setTimeout(() => { if (pending.delete(requestId)) reject(new Error('엔트리 세션을 찾지 못했습니다.')); }, 7000);
    });
  }

  port.onMessage.addListener((message) => {
    if (message.type === 'UI_RESPONSE') {
      const item = pending.get(message.requestId);
      if (!item) return;
      pending.delete(message.requestId);
      if (message.ok) item.resolve(message); else item.reject(new Error(message.error || '동작 실패'));
      return;
    }
    if (message.type === 'SESSION_STATE' && (!tabId || message.tabId === tabId)) {
      state = message.state || { active: false, participants: [] };
      ensureSelection();
      renderOrPatch();
      return;
    }
    if (message.type === 'SESSION_EVENT' && (!tabId || message.tabId === tabId)) handleEvent(message.event);
  });

  function handleEvent(event) {
    if (!event) return;
    if (event.type === 'leader-screen') {
      state.latestFrames = { ...(state.latestFrames || {}), screen: event.dataUrl };
      if (activeView === 'leader') viewer?.load(event.dataUrl, true);
      return;
    }
    if (event.type === 'chat') {
      state.chat ||= { messages: [], unread: 0 };
      if (event.message && !state.chat.messages?.some((m) => m.id === event.message.id)) {
        state.chat.messages = [...(state.chat.messages || []), event.message].slice(-100);
      }
      patchChat();
      return;
    }
    if (event.type === 'code-share') {
      state.codeShares ||= [];
      state.codeShares = [event.share, ...state.codeShares.filter((s) => s.id !== event.share.id)].slice(0, 30);
      selectedShareId = event.share.id;
      activeView = 'codes';
      patchCenterHeader();
      patchCodeShares();
      loadActiveView();
      showNotice(`${event.share.fromName || '참여자'}의 코드를 받았습니다.`);
      return;
    }
    if (event.type === 'participant-project') {
      handleParticipantProject(event);
      return;
    }
    if (event.type === 'announcement') {
      state.announcement = event.announcement;
      patchSettings();
      return;
    }
    if (event.type === 'notice' && event.notice?.text) showNotice(event.notice.text, event.notice.tone === 'error');
  }

  function ensureSelection() {
    const people = state.participants || [];
    if (!people.some((p) => p.id === selectedUserId)) selectedUserId = people[0]?.id || null;
    const shares = state.codeShares || [];
    if (!shares.some((s) => s.id === selectedShareId)) selectedShareId = shares[0]?.id || null;
  }

  function renderOrPatch() {
    if (!state.active || state.role !== 'leader' || state.mode !== 'mode1') {
      shellReady = false;
      viewer = null;
      if (managerTimer) clearInterval(managerTimer);
      managerTimer = null;
      app.innerHTML = `<div class="manager-empty"><div><h1>Entry Live Studio</h1><p>${esc(state.endReason || '대표 송출 모드의 관리자만 사용할 수 있습니다.')}</p></div></div>`;
      return;
    }
    if (!shellReady) renderShell();
    patchAll();
  }

  function renderShell() {
    app.innerHTML = `<div class="manager-app">
      <header class="topbar">
        <div class="brand"><div class="logo">E</div><div><h1>Entry Live Studio</h1><p id="roomText"></p></div></div>
        <div class="top-actions"><span class="live-dot" id="liveDot"></span><span id="connectionText">연결 중</span><span id="shareDurationText" class="share-time">송출 중지</span><button id="screenTop" class="btn">화면 송출</button><button id="leave" class="btn danger">세션 종료</button></div>
      </header>
      <main class="layout">
        <aside class="card people-card">
          <div class="card-head"><div><h2>참여자</h2><p>보기 전용 · 코드 전송/작품 가져오기</p></div><span class="count" id="peopleCount">0</span></div>
          <div id="peopleList" class="people-list"></div>
          <div id="participantDetail" class="participant-detail"></div>
        </aside>
        <section class="card center-card">
          <div class="center-head"><div class="tabs"><button data-view="leader" class="active">대표 화면</button><button data-view="codes">받은 코드 <span id="codeCount"></span></button></div><div id="centerTools"></div></div>
          <div class="viewport" id="viewport"><canvas class="base-canvas"></canvas><canvas class="annot-canvas"></canvas><div class="empty">표시할 화면이 없습니다.</div></div>
          <div class="viewer-tools"><div class="toolgroup"><button class="btn active" data-tool="pan">이동</button><button class="btn" data-tool="draw">그리기</button><button class="btn" data-tool="erase">지우개</button><button id="clearAnnotations" class="btn">전체 지우기</button><input id="drawColor" type="color" value="#ff365b" title="그리기 색"></div><div class="toolgroup"><button id="zoomOut" class="btn icon">−</button><button id="fit" class="btn">화면 맞춤</button><button id="zoomIn" class="btn icon">＋</button></div></div>
        </section>
        <aside class="card side-card">
          <div class="side-tabs"><button data-side="chat" class="active">채팅</button><button data-side="send">코드·이미지</button><button data-side="settings">공지·설정</button></div>
          <div class="side-content" id="sideContent"></div>
        </aside>
      </main>
      <div id="managerNotice" class="manager-notice" hidden></div>
      <div id="managerLightbox" class="image-lightbox" hidden><div class="image-lightbox-head"><strong id="managerLightboxTitle">이미지</strong><button id="managerLightboxClose" aria-label="닫기">×</button></div><div class="image-lightbox-body"><img id="managerLightboxImage" alt="크게 보기"></div></div>
    </div>`;
    viewer = new Viewer(document.getElementById('viewport'));
    bindShell();
    shellReady = true;
    if (!managerTimer) managerTimer = setInterval(patchShareDuration, 1000);
  }

  function bindShell() {
    document.querySelectorAll('[data-view]').forEach((button) => button.addEventListener('click', () => {
      activeView = button.dataset.view;
      patchCenterHeader(); loadActiveView();
    }));
    document.querySelectorAll('[data-side]').forEach((button) => button.addEventListener('click', () => {
      activeSide = button.dataset.side; patchSide();
    }));
    document.getElementById('screenTop').addEventListener('click', () => call('SET_SCREEN', { enabled: !state.screenEnabled }).catch(showError));
    document.getElementById('leave').addEventListener('click', async () => {
      if (!confirm('대표 세션을 종료할까요? 참여자의 연결도 종료됩니다.')) return;
      try { await call('STOP'); } catch (error) { showError(error); }
    });
    document.querySelectorAll('[data-tool]').forEach((button) => button.addEventListener('click', () => {
      document.querySelectorAll('[data-tool]').forEach((b) => b.classList.toggle('active', b === button));
      if (viewer) viewer.tool = button.dataset.tool;
    }));
    document.getElementById('zoomIn').addEventListener('click', () => viewer?.setZoom(viewer.zoom * 1.2));
    document.getElementById('zoomOut').addEventListener('click', () => viewer?.setZoom(viewer.zoom / 1.2));
    document.getElementById('fit').addEventListener('click', () => viewer?.fit());
    document.getElementById('clearAnnotations').addEventListener('click', () => viewer?.clearAnnotations());
    document.getElementById('managerLightboxClose').addEventListener('click', closeManagerLightbox);
    document.getElementById('managerLightbox').addEventListener('click', (event) => { if (event.target.id === 'managerLightbox') closeManagerLightbox(); });
  }

  function patchAll() {
    document.getElementById('roomText').textContent = `방 ${state.room || '-'} · 대표 송출 / 코드 관리`;
    document.getElementById('connectionText').textContent = state.connectionStatus === 'online' ? '연결됨' : '연결 중';
    document.getElementById('liveDot').classList.toggle('on', state.connectionStatus === 'online');
    const screenTop = document.getElementById('screenTop');
    screenTop.textContent = state.screenEnabled ? '송출 중' : '송출 시작';
    screenTop.classList.toggle('primary', Boolean(state.screenEnabled));
    patchShareDuration();
    patchPeople(); patchCenterHeader(); patchSide(); loadActiveView(false);
  }

  function patchShareDuration() {
    const node = document.getElementById('shareDurationText');
    if (!node) return;
    if (!state.screenEnabled) { node.textContent = '송출 중지'; return; }
    const startedAt = Number(state.screenShareStartedAt || state.startedAt || Date.now());
    node.textContent = `송출 ${formatDuration(Date.now() - startedAt)}`;
  }

  function openManagerLightbox(dataUrl, title = '이미지') {
    if (!dataUrl) return;
    const box = document.getElementById('managerLightbox');
    const image = document.getElementById('managerLightboxImage');
    const heading = document.getElementById('managerLightboxTitle');
    if (!box || !image) return;
    image.src = dataUrl;
    if (heading) heading.textContent = title || '이미지';
    box.hidden = false;
  }

  function closeManagerLightbox() {
    const box = document.getElementById('managerLightbox');
    if (box) box.hidden = true;
  }

  function patchPeople() {
    const people = state.participants || [];
    const list = document.getElementById('peopleList');
    document.getElementById('peopleCount').textContent = String(people.length);
    list.innerHTML = people.map((person) => `<button class="person ${person.id === selectedUserId ? 'active' : ''}" data-person="${esc(person.id)}"><span class="avatar">${esc((person.name || '?').slice(0, 1))}</span><span class="person-copy"><strong>${esc(person.name || '참여자')}</strong><small>${person.peerState === 'connected' ? '연결됨' : '연결 중'}</small></span><i class="online ${person.peerState === 'connected' ? 'on' : ''}"></i></button>`).join('') || '<div class="placeholder">참여자를 기다리는 중입니다.</div>';
    list.querySelectorAll('[data-person]').forEach((button) => button.addEventListener('click', () => {
      selectedUserId = button.dataset.person; patchPeople(); patchSide();
    }));
    const selected = people.find((p) => p.id === selectedUserId);
    const policy = state.participantPolicies?.[selectedUserId] || {};
    const detail = document.getElementById('participantDetail');
    detail.innerHTML = selected ? `<div class="detail-title"><strong>${esc(selected.name)}</strong><span>${esc(selected.id.slice(0, 8))}</span></div>
      <label class="switch-row"><span><b>참가자 간 대화</b><small>이 참가자가 모두에게 채팅 가능</small></span><input id="peerChatToggle" type="checkbox" ${policy.peerChatAllowed ? 'checked' : ''}></label>
      <button id="downloadEnt" class="btn block">이 참가자 작품을 .ent로 가져오기</button>` : '<div class="placeholder compact">참여자를 선택하세요.</div>';
    document.getElementById('peerChatToggle')?.addEventListener('change', (event) => call('SET_PARTICIPANT_POLICY', { userId: selectedUserId, peerChatAllowed: event.target.checked }).catch(showError));
    document.getElementById('downloadEnt')?.addEventListener('click', requestEnt);
  }

  function patchCenterHeader() {
    document.querySelectorAll('[data-view]').forEach((button) => button.classList.toggle('active', button.dataset.view === activeView));
    document.getElementById('codeCount').textContent = state.codeShares?.length ? `(${state.codeShares.length})` : '';
    const tools = document.getElementById('centerTools');
    if (activeView === 'codes') {
      const shares = state.codeShares || [];
      tools.innerHTML = `<select id="shareSelect" class="select-compact">${shares.map((s) => `<option value="${esc(s.id)}" ${s.id === selectedShareId ? 'selected' : ''}>${esc(s.fromName || '참여자')} · ${esc(s.sourceName || '코드')}</option>`).join('')}</select>${selectedShareId ? '<button id="applyShare" class="btn primary">내 현재 오브젝트에 적용</button>' : ''}`;
      document.getElementById('shareSelect')?.addEventListener('change', (event) => { selectedShareId = event.target.value; loadActiveView(); });
      document.getElementById('applyShare')?.addEventListener('click', async () => {
        try { await call('APPLY_SHARED_CODE', { shareId: selectedShareId, targetMode: 'current' }); showNotice('받은 코드를 현재 오브젝트에 적용했습니다.'); }
        catch (error) { showError(error); }
      });
    } else {
      tools.innerHTML = '<span class="soft-badge">실시간 송출 화면</span>';
    }
  }

  function patchCodeShares() {
    patchCenterHeader();
  }

  function loadActiveView(reset = true) {
    if (!viewer) return;
    const url = activeView === 'leader'
      ? state.latestFrames?.screen
      : (state.codeShares || []).find((s) => s.id === selectedShareId)?.image?.dataUrl;
    if (url) viewer.load(url, !reset); else viewer.clearBase();
  }

  function patchSide() {
    document.querySelectorAll('[data-side]').forEach((button) => button.classList.toggle('active', button.dataset.side === activeSide));
    if (activeSide === 'chat') patchChat();
    else if (activeSide === 'send') patchSend();
    else patchSettings();
  }

  function recipientChecks(prefix = '') {
    const people = state.participants || [];
    return `<label class="recipient-all"><input id="${prefix}All" type="checkbox" checked>모두</label>${people.map((p) => `<label><input type="checkbox" data-${prefix.toLowerCase()}-user="${esc(p.id)}">${esc(p.name)}</label>`).join('')}`;
  }

  function bindRecipientGroup(prefix) {
    const all = document.getElementById(`${prefix}All`);
    const selector = `[data-${prefix.toLowerCase()}-user]`;
    all?.addEventListener('change', () => { if (all.checked) document.querySelectorAll(selector).forEach((el) => el.checked = false); });
    document.querySelectorAll(selector).forEach((el) => el.addEventListener('change', () => { if (el.checked && all) all.checked = false; }));
  }

  function selectedRecipients(prefix) {
    const all = document.getElementById(`${prefix}All`)?.checked;
    if (all) return (state.participants || []).map((p) => p.id);
    return [...document.querySelectorAll(`[data-${prefix.toLowerCase()}-user]:checked`)].map((el) => el.dataset[`${prefix.toLowerCase()}User`]);
  }

  function managerChatRooms() {
    const rooms = [{ id: 'all', label: '전체 채팅방', sub: '모든 참가자', avatar: '전' }];
    for (const person of state.participants || []) {
      rooms.push({ id: leaderRoomKey(person.id), label: person.name || '참여자', sub: '개인 채팅', avatar: (person.name || '?').slice(0, 1), userId: person.id });
    }
    return rooms;
  }

  function patchChat() {
    if (activeSide !== 'chat') return;
    const area = document.getElementById('sideContent');
    const rooms = managerChatRooms();
    if (!rooms.some((room) => room.id === activeChatRoom)) activeChatRoom = rooms[0]?.id || 'all';

    if (!document.getElementById('managerChatShell')) {
      renderedChatRoom = null;
      area.innerHTML = `<div class="chat-app-shell" id="managerChatShell"><nav class="chat-room-list" id="managerChatRooms"></nav><section class="chat-conversation"><div class="chat-room-title" id="managerChatTitle">대화</div><div class="chat-list" id="chatList"></div><div class="chat-compose"><div class="compose-row"><input id="chatInput" maxlength="2000" autocomplete="off" placeholder="메시지 입력"><button id="chatSend" class="btn primary">전송</button></div></div></section></div>`;
      document.getElementById('managerChatRooms').addEventListener('click', (event) => {
        const button = event.target.closest('[data-room]');
        if (!button) return;
        const input = document.getElementById('chatInput');
        if (input) chatDrafts.set(activeChatRoom, input.value);
        activeChatRoom = button.dataset.room;
        renderedChatRoom = null;
        patchChat();
      });
      const input = document.getElementById('chatInput');
      input.addEventListener('input', () => chatDrafts.set(activeChatRoom, input.value));
      const send = async () => {
        const value = document.getElementById('chatInput');
        const text = value.value.trim();
        if (!text) return;
        const room = managerChatRooms().find((item) => item.id === activeChatRoom);
        if (!room) return;
        try {
          await call('SEND_CHAT', room.id === 'all' ? { text, conversationId: 'all' } : { text, conversationId: room.id, userIds: [room.userId] });
          value.value = '';
          chatDrafts.set(activeChatRoom, '');
        } catch (error) { showError(error); }
      };
      document.getElementById('chatSend').addEventListener('click', send);
      input.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' && !event.isComposing) { event.preventDefault(); send(); }
      });
      document.getElementById('chatList').addEventListener('click', (event) => {
        const image = event.target.closest('img[data-chat-image]');
        if (image) openManagerLightbox(image.src, image.alt || '채팅 이미지');
      });
    }

    const nav = document.getElementById('managerChatRooms');
    nav.innerHTML = rooms.map((room) => `<button class="chat-room-button ${room.id === activeChatRoom ? 'active' : ''}" data-room="${esc(room.id)}"><span class="chat-room-avatar">${esc(room.avatar)}</span><span class="chat-room-copy"><b>${esc(room.label)}</b><small>${esc(room.sub)}</small></span></button>`).join('');
    const room = rooms.find((item) => item.id === activeChatRoom) || rooms[0];
    document.getElementById('managerChatTitle').textContent = room?.label || '대화';
    const messages = (state.chat?.messages || []).filter((message) => String(message.conversationId || 'all') === activeChatRoom);
    const list = document.getElementById('chatList');
    list.innerHTML = messages.map((m) => `<article class="chat-msg ${m.from === state.userId ? 'mine' : ''}"><small>${esc(m.fromName || (m.from === state.userId ? '관리자' : '참여자'))}</small>${m.text ? `<div>${esc(m.text)}</div>` : ''}${m.dataUrl ? `<img data-chat-image="1" src="${m.dataUrl}" alt="${esc(m.title || '첨부 이미지')}">` : ''}</article>`).join('') || '<div class="placeholder">이 대화방에는 아직 메시지가 없습니다.</div>';
    list.scrollTop = list.scrollHeight;

    if (renderedChatRoom !== activeChatRoom) {
      const input = document.getElementById('chatInput');
      if (input) input.value = chatDrafts.get(activeChatRoom) || '';
      renderedChatRoom = activeChatRoom;
    }
  }

  function patchSend() {
    if (activeSide !== 'send') return;
    const area = document.getElementById('sideContent');
    const ownObjects = state.ownSummary?.objects || [];
    area.innerHTML = `<div class="form-pane">
      <section><h3>참가자에게 코드 보내기</h3><label>보낼 오브젝트<select id="sourceObject">${ownObjects.map((o) => `<option value="${esc(o.id)}" ${o.selected ? 'selected' : ''}>${esc(o.name)}</option>`).join('')}</select></label><label>범위<select id="scope"><option value="object">오브젝트 전체</option><option value="thread">선택 코드 묶음</option><option value="below">선택 블록 아래</option></select></label><label>받는 위치<select id="targetMode"><option value="current">참가자의 현재 오브젝트</option><option value="new">새 오브젝트 추가</option></select></label><input id="newObjectName" placeholder="새 오브젝트 이름 (새 오브젝트 선택 시)"><div class="recipient-strip wrap">${recipientChecks('Code')}</div><button id="sendCode" class="btn primary block">참가자에게 코드 보내기</button></section>
      <section><h3>현재 표시 이미지 전송</h3><p>관리자가 엔트리에서 현재 선택한 코드 묶음을 이미지로 만들어 전송합니다.</p><label>전송 방식<select id="mediaRoute"><option value="chat">채팅으로 전송</option><option value="focus">대표 화면 위에 크게 표시</option></select></label><div class="recipient-strip wrap">${recipientChecks('Media')}</div><button id="sendMedia" class="btn block">선택 코드 이미지 전송</button></section>
    </div>`;
    bindRecipientGroup('Code'); bindRecipientGroup('Media');
    document.getElementById('sendCode').addEventListener('click', async () => {
      const userIds = selectedRecipients('Code');
      if (!userIds.length) return showError('받을 참여자를 선택하세요.');
      const targetMode = document.getElementById('targetMode').value;
      const newName = document.getElementById('newObjectName').value.trim();
      const targets = userIds.map((userId) => ({ userId, targetMode, newObjectName: newName || undefined }));
      try { await call('SEND_CODE', { objectId: document.getElementById('sourceObject').value, scope: document.getElementById('scope').value, targets }); showNotice(`${userIds.length}명에게 코드를 전송했습니다.`); }
      catch (error) { showError(error); }
    });
    document.getElementById('sendMedia').addEventListener('click', async () => {
      const userIds = selectedRecipients('Media');
      if (!userIds.length) return showError('받을 참여자를 선택하세요.');
      try {
        const result = await call('GET_CURRENT_CODE_IMAGE');
        const source = result.response?.result || result.response;
        const dataUrl = source?.image?.dataUrl;
        if (!dataUrl) throw new Error('엔트리에서 전송할 블록을 먼저 선택하세요.');
        const all = Boolean(document.getElementById('MediaAll')?.checked);
        await call('SEND_MEDIA', { userIds, all, dataUrl, route: document.getElementById('mediaRoute').value, title: `${source.objectName || '선택 코드'} · 코드 이미지` });
        showNotice(`${userIds.length}명에게 코드 이미지를 전송했습니다.`);
      } catch (error) { showError(error); }
    });
  }

  function patchSettings() {
    if (activeSide !== 'settings') return;
    const area = document.getElementById('sideContent');
    area.innerHTML = `<div class="form-pane"><section><h3>상단 공지</h3><textarea id="announcementText" maxlength="500" rows="4" placeholder="모든 참가자의 화면 상단에 표시됩니다.">${esc(state.announcement?.text || '')}</textarea><div class="two-buttons"><button id="clearAnnouncement" class="btn">공지 내리기</button><button id="sendAnnouncement" class="btn primary">공지 띄우기</button></div></section><section><h3>채팅 도배 방지</h3><label>참가자 전송 쿨타임 (초)<input id="cooldown" type="number" min="0" max="60" step="1" value="${Math.round((state.chat?.cooldownMs || 0) / 1000)}"></label><button id="saveCooldown" class="btn block">쿨타임 저장</button><p>참가자별 ‘참가자 간 대화’ 허용은 왼쪽 참가자 설명에서 설정합니다.</p></section><section><h3>송출 옵션</h3><label class="switch-row"><span><b>화면 송출</b><small>참가자에게 대표 화면 표시</small></span><input id="screenSetting" type="checkbox" ${state.screenEnabled ? 'checked' : ''}></label><label class="switch-row"><span><b>작업 박스 포함</b><small>송출 이미지에 Entry Live UI 포함</small></span><input id="shareControls" type="checkbox" ${state.shareControls ? 'checked' : ''}></label></section></div>`;
    document.getElementById('sendAnnouncement').addEventListener('click', () => call('SEND_ANNOUNCEMENT', { text: document.getElementById('announcementText').value }).catch(showError));
    document.getElementById('clearAnnouncement').addEventListener('click', () => call('SEND_ANNOUNCEMENT', { text: '' }).catch(showError));
    document.getElementById('saveCooldown').addEventListener('click', async () => {
      try { await call('SET_CHAT_SETTINGS', { cooldownMs: Math.max(0, Number(document.getElementById('cooldown').value) || 0) * 1000 }); showNotice('채팅 쿨타임을 저장했습니다.'); }
      catch (error) { showError(error); }
    });
    document.getElementById('screenSetting').addEventListener('change', (e) => call('SET_SCREEN', { enabled: e.target.checked }).catch(showError));
    document.getElementById('shareControls').addEventListener('change', (e) => call('SET_SHARE_CONTROLS', { enabled: e.target.checked }).catch(showError));
  }

  async function requestEnt() {
    if (!selectedUserId) return;
    try {
      const result = await call('REQUEST_PARTICIPANT_ENT', { userId: selectedUserId }, 10000);
      const requestId = result.response?.result?.requestId;
      if (requestId) exportRequests.set(requestId, selectedUserId);
      showNotice('참가자 작품 데이터를 요청했습니다.');
    } catch (error) { showError(error); }
  }

  async function handleParticipantProject(event) {
    if (event.error) return showError(event.error);
    if (!event.project) return showError('참가자 작품 데이터를 받지 못했습니다.');
    try {
      showNotice('ENT 파일을 만드는 중입니다…');
      const result = await buildEnt(event.project, event.projectName || event.fromName || 'participant');
      downloadBlob(result.blob, `${safeName(event.projectName || event.fromName || 'participant')}.ent`);
      showNotice(result.missing ? `.ent 다운로드 완료 · 가져오지 못한 에셋 ${result.missing}개` : '.ent 다운로드가 시작되었습니다.');
    } catch (error) { showError(error); }
  }

  function safeName(value) {
    return String(value || 'project').replace(/[\\/:*?"<>|]+/g, '_').trim() || 'project';
  }

  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }

  async function buildEnt(inputProject) {
    const project = JSON.parse(JSON.stringify(inputProject));
    const refs = [];
    const seen = new Set();
    const walk = (node) => {
      if (!node || typeof node !== 'object') return;
      if (Array.isArray(node)) return node.forEach(walk);
      for (const [key, value] of Object.entries(node)) {
        if ((key === 'fileurl' || key === 'thumbUrl') && typeof value === 'string' && value) {
          const normalized = normalizeAsset(value, key);
          if (normalized) {
            node[key] = normalized.projectUrl;
            if (!seen.has(normalized.fetchUrl)) { seen.add(normalized.fetchUrl); refs.push(normalized); }
          }
        } else walk(value);
      }
    };
    walk(project);
    const files = [{ name: 'temp/project.json', bytes: new TextEncoder().encode(JSON.stringify(project)) }];
    let missing = 0;
    for (const ref of refs) {
      try {
        const response = await fetch(ref.fetchUrl, { credentials: 'omit' });
        if (!response.ok) throw new Error(String(response.status));
        files.push({ name: `temp/${ref.archivePath}`, bytes: new Uint8Array(await response.arrayBuffer()) });
      } catch (_) { missing++; }
    }
    const tar = makeTar(files);
    let bytes = tar;
    if ('CompressionStream' in globalThis) {
      const compressed = new Blob([tar]).stream().pipeThrough(new CompressionStream('gzip'));
      bytes = new Uint8Array(await new Response(compressed).arrayBuffer());
    } else {
      throw new Error('이 Chrome 버전에서는 ENT gzip 압축을 지원하지 않습니다.');
    }
    return { blob: new Blob([bytes], { type: 'application/gzip' }), missing };
  }

  function normalizeAsset(raw, key) {
    try {
      const absolute = new URL(raw, 'https://playentry.org');
      if (!/^https?:$/.test(absolute.protocol)) return null;
      let archivePath = '';
      const match = absolute.pathname.match(/\/uploads\/(.+)$/);
      if (match) archivePath = decodeURIComponent(match[1]).replace(/^\/+/, '');
      if (!archivePath) {
        const last = decodeURIComponent(absolute.pathname.split('/').pop() || 'asset.bin');
        const stem = (last.replace(/\.[^.]+$/, '') || randomStem()).replace(/[^a-zA-Z0-9_-]/g, '') || randomStem();
        const id = (stem + randomStem()).slice(0, Math.max(8, stem.length));
        const ext = /\.[a-zA-Z0-9]{1,8}$/.exec(last)?.[0] || '';
        const kind = key === 'thumbUrl' ? 'thumb' : /\.(mp3|wav|ogg|m4a)$/i.test(last) ? 'sound' : 'image';
        const filename = `${id}${ext}`;
        archivePath = `${id.slice(0,2)}/${id.slice(2,4)}/${kind}/${filename}`;
      }
      archivePath = archivePath.split('/').map((part) => part.replace(/[^a-zA-Z0-9._-]/g, '_')).join('/');
      return { fetchUrl: absolute.href, archivePath, projectUrl: match ? absolute.href : `https://playentry.org/uploads/${archivePath}` };
    } catch (_) { return null; }
  }

  function randomStem() { return Math.random().toString(36).slice(2, 12); }

  function writeAscii(buffer, offset, length, value) {
    const bytes = new TextEncoder().encode(String(value));
    buffer.set(bytes.slice(0, length), offset);
  }
  function oct(value, length) { return Math.max(0, Number(value) || 0).toString(8).padStart(length - 1, '0').slice(-(length - 1)) + '\0'; }
  function splitTarPath(path) {
    const bytes = (value) => new TextEncoder().encode(value).length;
    if (bytes(path) <= 100) return { name: path, prefix: '' };
    const parts = path.split('/');
    for (let i = parts.length - 1; i > 0; i--) {
      const prefix = parts.slice(0, i).join('/');
      const name = parts.slice(i).join('/');
      if (bytes(name) <= 100 && bytes(prefix) <= 155) return { name, prefix };
    }
    throw new Error(`ENT 내부 파일 경로가 너무 깁니다: ${path}`);
  }
  function tarHeader(path, size) {
    const h = new Uint8Array(512);
    const { name, prefix } = splitTarPath(path);
    writeAscii(h, 0, 100, name); writeAscii(h, 100, 8, oct(0o644, 8)); writeAscii(h, 108, 8, oct(0, 8)); writeAscii(h, 116, 8, oct(0, 8));
    writeAscii(h, 124, 12, oct(size, 12)); writeAscii(h, 136, 12, oct(Math.floor(Date.now()/1000), 12));
    for (let i = 148; i < 156; i++) h[i] = 32;
    h[156] = '0'.charCodeAt(0); writeAscii(h, 257, 6, 'ustar\0'); writeAscii(h, 263, 2, '00'); writeAscii(h, 265, 32, 'entrylive'); writeAscii(h, 297, 32, 'entrylive'); writeAscii(h, 345, 155, prefix);
    const sum = h.reduce((a, b) => a + b, 0); writeAscii(h, 148, 8, sum.toString(8).padStart(6, '0') + '\0 ');
    return h;
  }
  function makeTar(files) {
    const chunks = [];
    let total = 1024;
    for (const file of files) {
      const bytes = file.bytes instanceof Uint8Array ? file.bytes : new Uint8Array(file.bytes);
      const pad = (512 - (bytes.length % 512)) % 512;
      chunks.push(tarHeader(file.name, bytes.length), bytes, new Uint8Array(pad));
      total += 512 + bytes.length + pad;
    }
    chunks.push(new Uint8Array(1024));
    const out = new Uint8Array(total); let pos = 0;
    for (const chunk of chunks) { out.set(chunk, pos); pos += chunk.length; }
    return out;
  }

  function showNotice(text, isError = false) {
    const box = document.getElementById('managerNotice');
    if (!box) return;
    box.textContent = String(text || ''); box.classList.toggle('error', Boolean(isError)); box.hidden = !text;
    clearTimeout(noticeTimer);
    noticeTimer = setTimeout(() => { box.hidden = true; }, isError ? 5200 : 3400);
  }
  function showError(error) { showNotice(error?.message || String(error), true); }

  class Viewer {
    constructor(viewport) {
      this.viewport = viewport; this.base = viewport.querySelector('.base-canvas'); this.canvas = viewport.querySelector('.annot-canvas'); this.ctx = this.canvas.getContext('2d');
      this.zoom = 1; this.x = 0; this.y = 0; this.tool = 'pan'; this.loadSeq = 0; this.bind();
    }
    load(url, preserve = false) {
      if (!url) return;
      const seq = ++this.loadSeq; const image = new Image();
      image.onload = () => {
        if (seq !== this.loadSeq) return;
        const sizeChanged = this.base.width !== image.naturalWidth || this.base.height !== image.naturalHeight;
        const had = Boolean(this.base.width);
        this.base.width = image.naturalWidth; this.base.height = image.naturalHeight; this.base.getContext('2d').drawImage(image, 0, 0);
        if (sizeChanged || !preserve) { this.canvas.width = image.naturalWidth; this.canvas.height = image.naturalHeight; this.ctx = this.canvas.getContext('2d'); }
        this.viewport.classList.add('has-frame');
        if (!had || sizeChanged || !preserve) this.fit();
      };
      image.src = url;
    }
    clearBase() { this.loadSeq++; this.base.width = this.base.height = this.canvas.width = this.canvas.height = 0; this.viewport.classList.remove('has-frame'); }
    bind() {
      let down = false, prev = null;
      const point = (e) => ({ x: (e.clientX - this.canvas.getBoundingClientRect().left) / this.zoom, y: (e.clientY - this.canvas.getBoundingClientRect().top) / this.zoom });
      this.canvas.onpointerdown = (e) => { if (!this.base.width) return; down = true; prev = this.tool === 'pan' ? {x:e.clientX,y:e.clientY} : point(e); this.canvas.setPointerCapture(e.pointerId); };
      this.canvas.onpointermove = (e) => {
        if (!down) return;
        if (this.tool === 'pan') { this.x += e.clientX - prev.x; this.y += e.clientY - prev.y; prev = {x:e.clientX,y:e.clientY}; return this.apply(); }
        const now = point(e); this.ctx.save(); this.ctx.lineCap='round'; this.ctx.lineJoin='round'; this.ctx.lineWidth=this.tool==='erase'?22:5; this.ctx.globalCompositeOperation=this.tool==='erase'?'destination-out':'source-over'; this.ctx.strokeStyle=document.getElementById('drawColor')?.value||'#ff365b'; this.ctx.beginPath(); this.ctx.moveTo(prev.x,prev.y); this.ctx.lineTo(now.x,now.y); this.ctx.stroke(); this.ctx.restore(); prev=now;
      };
      this.canvas.onpointerup = this.canvas.onpointercancel = this.canvas.onlostpointercapture = () => { down=false; prev=null; };
      this.viewport.onwheel = (e) => { e.preventDefault(); this.setZoom(this.zoom * (e.deltaY < 0 ? 1.1 : .9)); };
    }
    fit() { if (!this.base.width) return; this.zoom=Math.min(this.viewport.clientWidth/this.base.width,this.viewport.clientHeight/this.base.height); this.x=(this.viewport.clientWidth-this.base.width*this.zoom)/2; this.y=(this.viewport.clientHeight-this.base.height*this.zoom)/2; this.apply(); }
    setZoom(v) { this.zoom=Math.max(.1,Math.min(5,v)); this.apply(); }
    apply() { const t=`translate(${this.x}px,${this.y}px) scale(${this.zoom})`; this.base.style.transform=t; this.canvas.style.transform=t; }
    clearAnnotations() { if (this.canvas.width) this.ctx.clearRect(0,0,this.canvas.width,this.canvas.height); }
    toDataUrl() { if (!this.base.width) return null; const out=document.createElement('canvas'); out.width=this.base.width; out.height=this.base.height; const c=out.getContext('2d'); c.drawImage(this.base,0,0); c.drawImage(this.canvas,0,0); return out.toDataURL('image/jpeg',.82); }
  }

  (async () => {
    try {
      const result = await getState();
      state = result.response?.active !== undefined ? result.response : result.response?.result || state;
      ensureSelection(); renderOrPatch();
      if (state.active) call('MARK_CHAT_READ').catch(() => {});
    } catch (error) { state = { active:false, endReason:error.message }; renderOrPatch(); }
  })();
})();
