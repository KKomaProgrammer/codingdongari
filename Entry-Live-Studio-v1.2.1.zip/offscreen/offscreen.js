const captures = new Map();

async function startCapture({ tabId, streamId, interval, quality }) {
  stopCapture(tabId);
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: false,
    video: {
      mandatory: {
        chromeMediaSource: 'tab',
        chromeMediaSourceId: streamId,
      },
    },
  });
  const video = document.createElement('video');
  video.muted = true;
  video.autoplay = true;
  video.srcObject = stream;
  await video.play();
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d', { alpha: false });
  const item = { stream, video, canvas, context, timer: null, busy: false };
  captures.set(tabId, item);
  const frame = async () => {
    if (item.busy || video.readyState < 2 || !video.videoWidth) return;
    item.busy = true;
    try {
      const ratio = Math.min(1, 1280 / video.videoWidth, 720 / video.videoHeight);
      canvas.width = Math.max(1, Math.round(video.videoWidth * ratio));
      canvas.height = Math.max(1, Math.round(video.videoHeight * ratio));
      context.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', Math.max(.25, Math.min(.9, quality / 100)));
      await chrome.runtime.sendMessage({ type: 'ENTRY_LIVE_OFFSCREEN_FRAME', tabId, dataUrl });
    } finally {
      item.busy = false;
    }
  };
  item.timer = setInterval(frame, interval);
  frame();
}

function stopCapture(tabId) {
  const item = captures.get(tabId);
  if (!item) return;
  clearInterval(item.timer);
  for (const track of item.stream.getTracks()) track.stop();
  item.video.srcObject = null;
  captures.delete(tabId);
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'ENTRY_LIVE_OFFSCREEN_START') {
    startCapture(message).then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message.type === 'ENTRY_LIVE_OFFSCREEN_STOP') {
    stopCapture(message.tabId);
    sendResponse({ ok: true });
  }
});
