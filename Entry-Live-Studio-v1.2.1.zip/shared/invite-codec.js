(function (root) {
  const ROOM_CODE_PATTERN = /^[A-Za-z0-9_-]{4,48}$/;
  const INVITE_PATTERN = /^[A-Za-z0-9_-]+$/;

  function clean(value) {
    return String(value || '').replace(/[\s\u200B-\u200D\uFEFF]/g, '');
  }

  function encode(data) {
    const bytes = new TextEncoder().encode(JSON.stringify(data));
    let binary = '';
    bytes.forEach((byte) => { binary += String.fromCharCode(byte); });
    return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  function decode(value, fallback = {}) {
    const code = clean(value);
    if (!code) throw new Error('초대 코드 또는 방 코드를 입력하세요.');

    // A room code is intentionally short and is not JSON encoded.
    if (ROOM_CODE_PATTERN.test(code)) {
      return {
        v: 1,
        room: code,
        mode: fallback.mode === 'mode2' ? 'mode2' : 'mode1',
        serverUrl: fallback.serverUrl || '',
        anonKey: fallback.anonKey || '',
        plainRoom: true,
      };
    }

    try {
      if (!INVITE_PATTERN.test(code)) throw new Error('invalid base64url');
      const normalized = code.replace(/-/g, '+').replace(/_/g, '/');
      const binary = atob(normalized + '='.repeat((4 - normalized.length % 4) % 4));
      const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
      const json = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
      const data = JSON.parse(json);
      if (data?.v !== 1 || typeof data.room !== 'string' || !data.room || !['mode1', 'mode2'].includes(data.mode)) {
        throw new Error('invalid invite payload');
      }
      return {
        ...data,
        serverUrl: fallback.serverUrl || data.serverUrl || '',
        anonKey: fallback.anonKey || data.anonKey || '',
        plainRoom: false,
      };
    } catch (_error) {
      throw new Error('초대 코드 또는 방 코드가 올바르지 않습니다. 다시 복사해 주세요.');
    }
  }

  root.EntryInviteCodec = { encode, decode };
})(globalThis);
