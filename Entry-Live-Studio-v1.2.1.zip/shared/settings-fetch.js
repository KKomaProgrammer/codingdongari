(function (root) {
  const API_URL = 'https://supabase-settings-fetch.pages.dev/api/settings';

  async function fetchSettings(password, { timeout = 12000 } = {}) {
    if (typeof password !== 'string' || !password.length) {
      throw new Error('연결 비밀번호를 입력하세요.');
    }
    if (password.length > 256) {
      throw new Error('연결 비밀번호가 너무 깁니다.');
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    let response;
    try {
      response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
        cache: 'no-store',
        credentials: 'omit',
        signal: controller.signal,
      });
    } catch (error) {
      if (error?.name === 'AbortError') throw new Error('설정 서버 응답 시간이 초과되었습니다.');
      throw new Error('설정 서버에 연결할 수 없습니다. Cloudflare Pages 배포 상태를 확인하세요.');
    } finally {
      clearTimeout(timer);
    }

    let data = null;
    try { data = await response.json(); } catch (_) {}
    if (!response.ok || !data?.ok) {
      throw new Error(data?.error || `설정 서버 오류(HTTP ${response.status})`);
    }

    const serverUrl = typeof data.serverUrl === 'string' ? data.serverUrl.trim() : '';
    const anonKey = typeof data.anonKey === 'string' ? data.anonKey.trim() : '';
    if (!/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(serverUrl)) {
      throw new Error('설정 서버가 올바르지 않은 Supabase URL을 반환했습니다.');
    }
    if (!anonKey || anonKey.startsWith('sb_secret_')) {
      throw new Error('설정 서버가 브라우저용 Supabase 키를 반환하지 않았습니다.');
    }
    return { serverUrl: serverUrl.replace(/\/$/, ''), anonKey };
  }

  root.EntrySettingsFetch = { API_URL, fetchSettings };
})(globalThis);
